package com.crearo.crgooglemap.util;

import android.os.Build;
import android.support.v7.app.AppCompatActivity;
import android.view.View;

public class ScreenUtil {

    /**
     * 隐藏虚拟按键，并且全屏
     * @param appCompatActivity
     */
    public static void hideBottomUIMenu(AppCompatActivity appCompatActivity) {
        //隐藏虚拟按键，并且全屏
        if (Build.VERSION.SDK_INT > 11 && Build.VERSION.SDK_INT < 19) { // lower api
            View v = appCompatActivity.getWindow().getDecorView();
            v.setSystemUiVisibility(View.GONE);
        } else if (Build.VERSION.SDK_INT >= 19) {
            //for new api versions.
            View decorView = appCompatActivity.getWindow().getDecorView();
            int uiOptions = View.SYSTEM_UI_FLAG_HIDE_NAVIGATION
                    | View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY | View.SYSTEM_UI_FLAG_FULLSCREEN;
            decorView.setSystemUiVisibility(uiOptions);
        }
    }
}
