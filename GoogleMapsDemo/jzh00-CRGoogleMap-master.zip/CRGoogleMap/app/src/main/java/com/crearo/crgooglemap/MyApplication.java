package com.crearo.crgooglemap;

import android.app.Application;
import android.view.Window;
import android.view.WindowManager;

public class MyApplication extends Application {

    @Override
    public void onCreate() {
        super.onCreate();
    }
}
