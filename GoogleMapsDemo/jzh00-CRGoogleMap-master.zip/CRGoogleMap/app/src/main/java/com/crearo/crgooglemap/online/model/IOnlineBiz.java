package com.crearo.crgooglemap.online.model;

import com.google.android.gms.maps.model.LatLng;

import java.util.ArrayList;
import java.util.List;

/**
 * 关于地图数据处理的接口
 */
public interface IOnlineBiz {

    String judgeInCircle(ArrayList<MyLatLng> arrayList, LatLng latLng, double pi);

    String judgeInSquare(ArrayList<MyLatLng> arrayList, LatLng A2,LatLng A4);


}
