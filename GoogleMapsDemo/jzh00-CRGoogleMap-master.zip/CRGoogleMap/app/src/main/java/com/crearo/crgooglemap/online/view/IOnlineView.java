package com.crearo.crgooglemap.online.view;

import com.crearo.crgooglemap.online.model.MyLatLng;
import com.google.android.gms.maps.model.LatLng;

import java.util.ArrayList;
import java.util.List;

public interface IOnlineView {

    void drawLine(List<LatLng> latLngs);

    void drawCircle( LatLng latLng,double pi );

    void drawSquare(List<LatLng> latLngs);

}
