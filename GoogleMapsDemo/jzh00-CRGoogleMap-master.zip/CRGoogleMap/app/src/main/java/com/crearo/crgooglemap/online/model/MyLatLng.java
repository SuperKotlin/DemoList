package com.crearo.crgooglemap.online.model;

import com.google.android.gms.maps.model.LatLng;

public class MyLatLng {

    public String name;

    public LatLng latLng;

    public MyLatLng() {
    }

    public MyLatLng(String name, LatLng latLng) {
        this.name = name;
        this.latLng = latLng;
    }
}
