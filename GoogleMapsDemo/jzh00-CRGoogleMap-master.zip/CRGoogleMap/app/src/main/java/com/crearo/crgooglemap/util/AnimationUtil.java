package com.crearo.crgooglemap.util;

import android.content.Context;
import android.view.View;
import android.view.animation.Animation;
import android.view.animation.AnimationUtils;

import com.crearo.crgooglemap.R;

/**
 *
 * 动画工具类
 */
public class AnimationUtil {

    public static final int OUT_FROM_LEFT = 1, OUT_FROM_RIGHT = 2,
            OUT_FROM_TOP = 3, OUT_FROM_BOTTOM = 4,
            IN_FROM_LEFT = 5, IN_FROM_RIGHT = 6,
            IN_FROM_TOP = 7, IN_FROM_BOTTOM = 7;

    /**
     * 平移动画
     *
     * @param context
     * @param view
     * @param type
     */
    public static void Translate(Context context, View view, int type) {
        int x = R.anim.in_to_left;
        switch (type) {
            case IN_FROM_LEFT:
                x = R.anim.in_to_left;
                break;
            case IN_FROM_BOTTOM:
                x=R.anim.in_from_bottom;
                break;
            case OUT_FROM_LEFT:
                x = R.anim.out_to_left;
                break;
            case OUT_FROM_BOTTOM:
                x=R.anim.out_from_bottom;
                break;
        }
        Animation myAnim = AnimationUtils.loadAnimation(context, x);
        myAnim.setFillAfter(true);//android动画结束后停在结束位置
        view.startAnimation(myAnim);
    }
}
