package com.crearo.crgooglemap.online.present;

import android.util.Log;

import com.crearo.crgooglemap.online.model.IOnlineBiz;
import com.crearo.crgooglemap.online.model.MyLatLng;
import com.crearo.crgooglemap.online.model.OnlineBiz;
import com.crearo.crgooglemap.online.view.IOnlineView;
import com.google.android.gms.maps.model.LatLng;
import com.google.android.gms.maps.model.MarkerOptions;

import java.util.ArrayList;
import java.util.LinkedList;
import java.util.List;

public class OnlinePresent {

    private MarkerOptions markerOptionScale = new MarkerOptions().title("");
    public List<LatLng> latLngs = new LinkedList<LatLng>();

    public float zoom;
    public double radius = 2344;
    public LatLng default_point = new LatLng(29.31993, 47.44446);
    public LatLng point1 = new LatLng(29.31293, 47.43446);
    public LatLng point2 = new LatLng(29.32293, 47.44946);
    public LatLng point3 = new LatLng(29.31993, 47.43046);
    public LatLng point4 = new LatLng(29.35093, 47.42006);
    public LatLng point5 = new LatLng(29.35493, 47.47446);
    public ArrayList<MyLatLng> point_list = new ArrayList<MyLatLng>();
    public LatLng A1, A2, A3, A4,temp_position1,temp_position2,temp_position3,temp_position4;

    private IOnlineView iOnlineView;
    private IOnlineBiz iOnlineBiz;

    public OnlinePresent(IOnlineView iOnlineView) {
        this.iOnlineView = iOnlineView;
        this.iOnlineBiz = new OnlineBiz();
        initData();
    }

    private void initData() {
        MyLatLng myLatLng = new MyLatLng();
        myLatLng.name = "单兵1";
        myLatLng.latLng = point1;
        point_list.add(myLatLng);
        MyLatLng myLatLng2 = new MyLatLng();
        myLatLng2.name = "单兵2";
        myLatLng2.latLng = point2;
        point_list.add(myLatLng2);
        MyLatLng myLatLng3 = new MyLatLng();
        myLatLng3.name = "单兵3";
        myLatLng3.latLng = point3;
        point_list.add(myLatLng3);
        MyLatLng myLatLng4 = new MyLatLng();
        myLatLng4.name = "单兵4";
        myLatLng4.latLng = point4;
        point_list.add(myLatLng4);
        MyLatLng myLatLng5 = new MyLatLng();
        myLatLng5.name = "单兵5";
        myLatLng5.latLng = point5;
        point_list.add(myLatLng5);
    }

    public void initSquareDate() {
        latLngs.clear();
        double DEFAULT_WIDTH=getCurrentSideLenght()*1.1;
        double DEFAULT_HEIGHT=getCurrentSideLenght();
        A1 = new LatLng(default_point.latitude + DEFAULT_WIDTH / 2, default_point.longitude + DEFAULT_HEIGHT / 2);
        A2 = new LatLng(default_point.latitude - DEFAULT_WIDTH / 2, default_point.longitude + DEFAULT_HEIGHT / 2);
        A3 = new LatLng(default_point.latitude - DEFAULT_WIDTH / 2, default_point.longitude - DEFAULT_HEIGHT / 2);
        A4 = new LatLng(default_point.latitude + DEFAULT_WIDTH / 2, default_point.longitude - DEFAULT_HEIGHT / 2);
        latLngs.add(A1);
        latLngs.add(A2);
        latLngs.add(A3);
        latLngs.add(A4);
    }

    public String judgeOnClircle() {
        return iOnlineBiz.judgeInCircle(point_list, default_point, radius);
    }

    public String judgeInSquare() {
        return iOnlineBiz.judgeInSquare(point_list, A2, A4);
    }

    public void testA(List<LatLng> latLngs) {
        for (LatLng latLng : latLngs)
            Log.i("AAAAAA", latLng.latitude + "long:" + latLng.longitude);
    }

    public long getCurrentPI(){
        return (long) (Math.pow(2,20-(int)zoom)*15);
    }

    public double getCurrentSideLenght(){
        return  (Math.pow(2,20-(int)zoom)*0.02/128);
    }

}
