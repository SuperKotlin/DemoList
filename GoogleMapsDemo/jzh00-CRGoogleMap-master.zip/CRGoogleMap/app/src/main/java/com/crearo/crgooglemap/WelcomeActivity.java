package com.crearo.crgooglemap;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;

import com.crearo.crgooglemap.online.view.OnlineActivity;

public class WelcomeActivity extends BaseActivity {


    @Override
    protected void initDate(Bundle savedInstanceState) {

    }

    @Override
    protected void initView() {
       startActivity(new Intent(this, OnlineActivity.class));
    }

    @Override
    protected int initLayout() {
        return R.layout.activity_welcome;
    }
}
