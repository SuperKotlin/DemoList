package com.crearo.crgooglemap.online.model;

import com.crearo.crgooglemap.util.MapUtil;
import com.google.android.gms.maps.model.LatLng;

import java.util.ArrayList;
import java.util.List;

public class OnlineBiz implements IOnlineBiz {

    /**
     * 判断点集合是不是在圆内
     *
     * @param arrayList
     * @param latLng
     * @return
     */
    @Override
    public String judgeInCircle(ArrayList<MyLatLng> arrayList, LatLng latLng, double pi) {
        if (arrayList == null || latLng == null) {
            return null;
        }
        double x;
        StringBuilder sb = new StringBuilder();
        for (MyLatLng myLatLng : arrayList) {
            x = MapUtil.getDistance(myLatLng.latLng, latLng);
            if (x <= pi) {
                sb.append(myLatLng.name);
            }
        }
        return sb.toString();
    }

    @Override
    public String judgeInSquare(ArrayList<MyLatLng> arrayList, LatLng A2,LatLng A4) {
        if (arrayList == null || A2 == null || A4==null) {
            return "点集合为空 或者 多边形端点集合为空";
        }
        if (arrayList.size() == 0 ) {
            return "点集合无参数";
        }
        StringBuilder sb = new StringBuilder();
        for (MyLatLng myLatLng : arrayList) {
            if (MapUtil.judgeRectangle(A2,A4,myLatLng.latLng)) {
                sb.append(myLatLng.name);
            }
        }
        return sb.toString().equals("")?"范围内无设备":sb.toString();
    }
}
