package com.amqr.gmap;

import com.google.android.gms.maps.model.LatLng;

/**
 * User: LJM
 * Date&Time: 2017-07-18 & 21:51
 * Describe: Describe Text
 */
public class NamedLocation {

    public final String name;

    public final LatLng location;

    NamedLocation(String name, LatLng location) {
        this.name = name;
        this.location = location;
    }
}
