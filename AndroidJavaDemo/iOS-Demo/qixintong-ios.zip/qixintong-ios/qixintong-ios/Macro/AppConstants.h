//
//  AppHeader.h
//  ios-template
//  常量调用
//
//  Created by dmo on 15/11/19.
//  Copyright © 2015年 dmo. All rights reserved.
//

#ifndef AppHeader_h
#define AppHeader_h

#import "AppVariable.h"
#import "AppURL.h"

#endif /* AppHeader_h */

