//
//  AppVariable.h
//  ios-template
//  全局调用值
//
//  Created by dmo on 15/11/19.
//  Copyright © 2015年 dmo. All rights reserved.
//

#ifndef AppVariable_h
#define AppVariable_h


/**
 * @brief 常用参数
 */
// 当前屏幕宽度
#define kScreenWidth    [UIScreen mainScreen].bounds.size.width

// 当前屏幕高度
#define kScreenHeight   [UIScreen mainScreen].bounds.size.height

//当前屏幕宽度和320的比例
#define kScreenWidthProportion  kScreenWidth / 320.0

//当前屏幕高度和568的比例
//#define kScreenHeightProportion kScreenHeight / 568.0
#define kScreenHeightProportion  ([[UIApplication sharedApplication] statusBarFrame].size.height>20.0 ? (kScreenHeight / 667.0) : (kScreenHeight / 568.0) )


// 状态栏
//#define kStatusHeight   [[UIApplication sharedApplication] statusBarFrame].size.height
#define kStatusHeight  ([[UIApplication sharedApplication] statusBarFrame].size.height>20.0?44.0: 20.0)

// 导航栏高度
#define kNavigationBarHeight self.navigationController.navigationBar.frame.size.height

// 界面头部高度
#define kHeaderHeight (kStatusHeight + kNavigationBarHeight)

//　底部标签栏高度
//#define kTabBarHeight   self.tabBarController.tabBar.frame.size.height
#define kTabBarHeight  ([[UIApplication sharedApplication] statusBarFrame].size.height>20.0?83.0:49.0)


/**
 *	@brief 设置字体
 */
#define FONT(size) [UIFont systemFontOfSize:size]
#define FONT_BOLD(size) [UIFont boldSystemFontOfSize:size]
#define kFontProportion kScreenHeightProportion

/**
 * @brief tag初始值
 */
#define kTagStart 100

#define kImage(imageName) [UIImage imageNamed:imageName]
#define kString(id) [NSString stringWithFormat:@"%@",id]

/**
 * @brief 封装颜色
 */
#define RGB(r, g, b) [UIColor colorWithRed:r/255.0f green:g/255.0f blue:b/255.0f alpha:1]
#define RGBA(r, g, b, a) [UIColor colorWithRed:r/255.0f green:g/255.0f blue:b/255.0f alpha:a]


/**
 * @brief 设置默认颜色
 */
#define kDefaultColor  RGB(245,33,45)  //(蓝色) App整体风格基色
#define kGrayLineColor  RGB(235,235,235) //(灰色)  线的颜色
#define kGrayBackgroundColor  RGB(244,244,244) //(灰色) 页面灰色背景
#define kGrayLabelColor  RGB(165,165,165) //(灰色) 淡灰色的文字，比黑色的浅一点
#define kGrayColor  RGB(51,51,51) //个人信息右边文字的颜色
#define kBlackLabelColor  RGB(90,90,90) //(浅黑色) 黑色文字的颜色
#define kLightRedColor  RGB(246,105,94) //淡红色
#define kOrangeColor RGB(251, 107, 7) //橙色



#endif /* AppVariable_h */


