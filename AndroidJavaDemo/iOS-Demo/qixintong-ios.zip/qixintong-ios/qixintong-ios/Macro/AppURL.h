//
//  AppURL.h
//  ios-template
//  数据接口地址
//
//  Created by dmo on 15/11/19.
//  Copyright © 2015年 dmo. All rights reserved.
//

#ifndef AppURL_h
#define AppURL_h

//post
#define kPOST @"POST"
//get
#define kGET @"GET"
//token值
#define kToken @"token"
//响应代码
#define kError @"error"
//响应信息
#define kMessage @"msg"
//errorCode
#define kErrorCode @"errorCode"

#define kData @"data"

#define kBuild @"1.0.1.200"
//不传token
#define kVersion @"?platform=IOS&version=" kBuild
//不传token，且不是直接拼在网址后面，而是拼在其他参数后面
#define kVersions @"&platform=IOS&version=" kBuild
//传token
#define kTokenVersion @"?platform=IOS&version=" kBuild @"&token="
//传token，且不是直接拼在网址后面，而是拼在其他参数后面
#define kTokenVersions @"&platform=IOS&version=" kBuild @"&token="


#pragma mark - URL
//线上
//#define kBaseURL @"http://www.haoxunwanglukeji.com/"
//#define kImageURL @""

//线下b站
#define kBaseURL @"http://8.future666.com/"
#define kImageURL @""


//判断手机号码是否注册
#define kIsRegisterURL kBaseURL @"app.php?c=UserAccount&a=is_register"

//发送用户注册验证码
#define kSendUserRegisterURL kBaseURL @"app.php?c=Sms&a=sendUserRegister"

//验证短信验证码是否正确
#define kCheckCodeURL kBaseURL @"app.php?c=Sms&a=checkCode"

//注册
#define kRegisterURL kBaseURL @"app.php?c=UserAccount&a=register"

//登录
#define kLoginURL kBaseURL @"app.php?c=UserAccount&a=login"

//发送用户找回密码验证码
#define kSendUserFindpwdURL kBaseURL @"app.php?c=Sms&a=sendUserFindpwd"

//发送用户找回密码验证码
#define kSendUserFindpwdURL kBaseURL @"app.php?c=Sms&a=sendUserFindpwd"

//使用手机找回密码
#define kFindPwdByPhoneURL kBaseURL @"app.php?c=UserAccount&a=findPwdByPhone"

//获取用户信息
#define kUserCenterURL kBaseURL @"app.php?c=User&a=getUserMsg"

//编辑用户信息
#define kEditUserMsgURL kBaseURL @"app.php?c=User&a=editUserMsg"

//获取文章列表
#define kGetArticleListURL kBaseURL @"app.php?c=Article&a=getArticleList"

//获取文章内容
#define kGetArticleMsgURL kBaseURL @"app.php?c=Article&a=getArticleMsg"

//修改密码
#define kChangePwdURL kBaseURL @"app.php?c=User&a=changePwd"

//退出登录
#define kExitURL kBaseURL @"app.php?c=User&a=loginout"

//留言
#define kFeedbackURL kBaseURL @"app.php?c=Message&a=online"

//获取用户申请列表
#define kGetApplyListURL kBaseURL @"app.php?c=ProductApply&a=getApplyList"

//获取产品列表
#define kGetProductListURL kBaseURL @"app.php?c=Product&a=getProductList"

//发起申请
#define kProductApplyURL kBaseURL @"app.php?c=ProductApply&a=apply"

//再次申请
#define kProductReApplyURL kBaseURL @"app.php?c=ProductApply&a=reapply"

//获取申请信息
#define kGetApplyMsgURL kBaseURL @"app.php?c=ProductApply&a=getApplyMsg"

//获取Banner/广告图列表
#define kGetBannerListURL kBaseURL @"app.php?c=Banner&a=getBannerList"

//编辑用户头像
#define kEditUserAvatarURL kBaseURL @"app.php?c=User&a=editUserAvatar"

//第三方社交平台账号注册
#define kLoginOauthURL kBaseURL @"app.php?c=UserAccount&a=loginOauth"




#endif /* AppURL_h */
