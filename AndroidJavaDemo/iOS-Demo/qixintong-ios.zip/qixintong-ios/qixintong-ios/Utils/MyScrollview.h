//
//  MyScrollview.h
//  pd384-ios
//
//  Created by dmo on 16/9/13.
//  Copyright © 2016年 dmo. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface MyScrollview : UIScrollView
-(BOOL)gestureRecognizer:(UIGestureRecognizer *)gestureRecognizer shouldRecognizeSimultaneouslyWithGestureRecognizer:(UIGestureRecognizer *)otherGestureRecognizer;

@end
