//
//  如遇到问题或有更好方案，请通过以下方式进行联系
//      QQ：1357127436
//      Email：kingsic@126.com
//      GitHub：https://github.com/kingsic
//
//  SGQRCode.h
//  Version 2.1.4
//
//  Created by kingsic on 2016/8/16.
//  Copyright © 2016年 kingsic. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "SGQRCodeGenerateManager.h"
#import "SGQRCodeScanManager.h"
#import "SGQRCodeAlbumManager.h"
#import "SGQRCodeScanningView.h"
