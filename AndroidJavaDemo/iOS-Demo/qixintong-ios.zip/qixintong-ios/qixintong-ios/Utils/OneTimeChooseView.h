//
//  OneTimeChooseView.h
//  pf435-company-ios
//
//  Created by dmo on 2017/4/18.
//  Copyright © 2017年 dmo. All rights reserved.
//  单个的时间选择器页面

#import <UIKit/UIKit.h>
typedef void(^ChooseTimeBlock)(NSString *selectTime);
@interface OneTimeChooseView : UIView <UIPickerViewDelegate,UIPickerViewDataSource>

//回调方法
@property (nonatomic, strong) ChooseTimeBlock chooseTimeBlock;

@property (nonatomic, strong) UIViewController *viewVontroller;

@property (nonatomic, copy) NSString *titleStr;
//选择器
@property (nonatomic, strong) UIPickerView *chooseJoinTimePickerView;

//小时数组
@property (nonatomic ,strong) NSArray *hourArray;

//分钟数组
@property (nonatomic, strong) NSArray *minArray;

//小时
@property (nonatomic, copy) NSString *gatherHourString;

//分钟
@property (nonatomic, copy) NSString *gatherMinuteString;

+ (void)initWithBlock:(ChooseTimeBlock)block andSuperView:(UIViewController *)viewVC;

@end
