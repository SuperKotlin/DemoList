//
//  MyScrollview.m
//  pd384-ios
//
//  Created by dmo on 16/9/13.
//  Copyright © 2016年 dmo. All rights reserved.
//

#import "MyScrollview.h"

@implementation MyScrollview
-(BOOL)gestureRecognizer:(UIGestureRecognizer *)gestureRecognizer shouldRecognizeSimultaneouslyWithGestureRecognizer:(UIGestureRecognizer *)otherGestureRecognizer {
    if (gestureRecognizer.state != 0) {
        return YES;
    } else {
        return NO;
    }
}

/*
// Only override drawRect: if you perform custom drawing.
// An empty implementation adversely affects performance during animation.
- (void)drawRect:(CGRect)rect {
    // Drawing code
}
*/

@end
