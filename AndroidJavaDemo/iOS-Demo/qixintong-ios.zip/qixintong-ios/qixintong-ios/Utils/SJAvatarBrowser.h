//
//  SJAvatarBrowser.h
//  图片查看
//
//  Created by mac on 15/8/15.
//  Copyright (c) 2015年 mac. All rights reserved.
//

#import <Foundation/Foundation.h>
#import <UIKit/UIKit.h>

@interface SJAvatarBrowser : NSObject

+(void)showImage:(UIImageView*)avatarImageView;

@end
