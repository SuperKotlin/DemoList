//
//  DataChoosePopView.m
//  DM-IOS
//
//  Created by wsy on 2017/6/16.
//  Copyright © 2017年 yayuanzi. All rights reserved.
//  日期选择器弹窗

#import "DataChoosePopView.h"

@implementation DataChoosePopView
//@synthesize datePicker;
+(id)initWithBlock:(DataChooseBlock)block {
    DataChoosePopView *popView = [[DataChoosePopView alloc] initWithFrame:CGRectMake(0, 0, kScreenWidth, kScreenHeight)];
    popView.backgroundColor = RGBA(0, 0, 0, 0);
    popView.block = block;
    [[UIApplication sharedApplication].keyWindow addSubview:popView];
    
    UIButton *backButton = [[UIButton alloc] initWithFrame:CGRectMake(0, 0, kScreenWidth, kScreenHeight)];
    backButton.backgroundColor = RGBA(0, 0, 0, 0.6);
    [backButton addTarget:popView action:@selector(backButtonAction) forControlEvents:UIControlEventTouchUpInside];
    [popView addSubview:backButton];
    
    UIView *centerView = [UIView viewWithFrame:CGRectMake(0, kScreenHeight - 230 * kScreenHeightProportion, kScreenWidth, 230  * kScreenHeightProportion) backgroundColor:[UIColor whiteColor]];
    [centerView setCornerRadius:6.f];
    [popView addSubview:centerView];
    
    UIView *topView = [UIView viewWithFrame:CGRectMake(0, 0, kScreenWidth, 44 * kScreenHeightProportion) backgroundColor:kDefaultColor];
    [centerView addSubview:topView];
    
    UIButton *leftBtn = [UIButton buttonWithFrame:CGRectMake(0, 0, 60 * kScreenWidthProportion, topView.height) type:UIButtonTypeCustom title:@"取消" titleColor:[UIColor whiteColor] imageName:nil action:@selector(backButtonAction) target:popView];
    leftBtn.titleLabel.font = FONT(kFontProportion * 14);
    [topView addSubview:leftBtn];
    
    UIButton *rightBtn = [UIButton buttonWithFrame:CGRectMake(kScreenWidth - 60 * kScreenWidthProportion, 0, 60 * kScreenWidthProportion, topView.height) type:UIButtonTypeCustom title:@"确定" titleColor:[UIColor whiteColor] imageName:nil action:@selector(enterAction) target:popView];
    rightBtn.titleLabel.font = FONT(kFontProportion * 14);
    [topView addSubview:rightBtn];

    UIView *lineView = [UIView viewWithFrame:CGRectMake(0, topView.height - 1, kScreenWidth, 1) backgroundColor:kDefaultColor];
    [topView addSubview:lineView];
    
    popView.datePicker = [[UIDatePicker alloc]initWithFrame:CGRectMake(0, topView.maxY, kScreenWidth, centerView.height - topView.height)];
    //中文
    popView.datePicker.locale = [NSLocale localeWithLocaleIdentifier:@"zh"];
    //年月日
    popView.datePicker.datePickerMode = UIDatePickerModeDate;
    
//    NSDate *minDate = [[NSDate alloc]initWithString:@"1900-01-01 00:00:00 -0500"];
//    NSDate *maxDate = [[NSDate alloc]initWithString:@"2099-01-01 00:00:00 -0500"];
//    
//    datePicker.minimumDate = minDate;
//    datePicker.maximumDate = maxDate;
    
    [centerView addSubview:popView.datePicker];
    
    return popView;
}

- (void)backButtonAction {
    [self removeFromSuperview];
}

- (void)enterAction {
    NSDate *date = self.datePicker.date;
    NSDateFormatter *formatter = [[NSDateFormatter alloc] init];
    [formatter setDateFormat:@"yyyy-MM-dd"];
    NSLog(@"%@",[formatter stringFromDate:date]);
    
    if (self.block != nil) {
        self.block([formatter stringFromDate:date]);
    }
    
    [self removeFromSuperview];
}

@end
