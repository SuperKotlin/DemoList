//
//  Identify.h
//  transport-vendor
//
//  Created by dmo on 15/8/25.
//  Copyright (c)2015年 dmo. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface Identify : NSObject

//验证手机号码
+ (BOOL)validateMobile:(NSString *)mobileNum;

//银行卡
+ (BOOL)validateCardNumber:(NSString *)cardNumber;

//身份证
+ (BOOL)validateIdentityCard:(NSString *)identityCard;

//用户名
+ (BOOL)validateUserName:(NSString *)name;

//姓名
+ (BOOL)validateName:(NSString *)name;

//车牌号码
+ (BOOL)validateCarNo:(NSString*)carNo;

//密码
+ (BOOL)validatePassword:(NSString*)password;

//判断整形
+ (BOOL)validateInt:(NSString *)string;

// 判断为空
+ (BOOL)isBlankString:(NSString *)string;

//邮箱
+ (BOOL)validateEmail:(NSString *)email;

+ (NSString *)deviceModelName;

@end
