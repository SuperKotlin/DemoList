//
//  TwoTimeChooseView.h
//  pf435-company-ios
//
//  Created by dmo on 2017/4/18.
//  Copyright © 2017年 dmo. All rights reserved.
//  两个时间选择器页面

#import <UIKit/UIKit.h>
typedef void(^ChooseTimeBlock2)(NSString *selectTime1,NSString *selectTime2);
@interface TwoTimeChooseView : UIView<UIPickerViewDelegate,UIPickerViewDataSource>

//回调方法
@property (nonatomic, strong) ChooseTimeBlock2 chooseTimeBlock;

@property (nonatomic, strong) UIViewController *viewVontroller;
//标题
@property (nonatomic, copy) NSString *titleStr;

//选择器1
@property (nonatomic, strong) UIPickerView *chooseStrtusTimePickerView;

//选择器2
@property (nonatomic, strong) UIPickerView *chooseEndTimePickerView;

//小时数组
@property (nonatomic ,strong) NSArray *hourArray;

//分钟数组
@property (nonatomic, strong) NSArray *minArray;

//选择器1 小时
@property (nonatomic, copy) NSString *gatherHourString;

//选择器1 分钟
@property (nonatomic, copy) NSString *gatherMinuteString;

//选择器2 小时
@property (nonatomic, copy) NSString *endHourString;
//选择器2 分钟
@property (nonatomic, copy) NSString *endMinuteString;

+ (void)initWithBlock:(ChooseTimeBlock2)block andSuperView:(UIViewController *)viewVC;

@end
