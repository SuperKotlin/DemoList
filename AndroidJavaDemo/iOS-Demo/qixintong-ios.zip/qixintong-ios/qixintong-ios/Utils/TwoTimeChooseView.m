//
//  TwoTimeChooseView.m
//  pf435-company-ios
//
//  Created by dmo on 2017/4/18.
//  Copyright © 2017年 dmo. All rights reserved.
//  两个时间选择器页面

#import "TwoTimeChooseView.h"

@implementation TwoTimeChooseView

+ (void)initWithBlock:(ChooseTimeBlock2)block andSuperView:(UIViewController *)viewVC {
    
    TwoTimeChooseView *timeView = [[TwoTimeChooseView alloc] initWithFrame:CGRectMake(0, 0, kScreenWidth, kScreenHeight)];
    timeView.backgroundColor = RGBA(0, 0, 0, 0.6);
    timeView.viewVontroller = viewVC;
    timeView.chooseTimeBlock = block;
    [viewVC.view addSubview:timeView];
    //初始化数据
    [timeView initData];
    
    UIView *chooseJoinTimeView = [[UIView alloc] initWithFrame:CGRectMake(0, kScreenHeight - 360 * kScreenHeightProportion, kScreenWidth, 360 * kScreenHeightProportion)];
    //    chooseJoinTimeView.hidden = YES;
    chooseJoinTimeView.backgroundColor = [UIColor whiteColor];
    [timeView addSubview:chooseJoinTimeView];
    
    UIView *chooseJoinTimeTitleView = [[UIView alloc] initWithFrame:CGRectMake(0, 0, kScreenWidth, 36 * kScreenHeightProportion)];
    chooseJoinTimeTitleView.backgroundColor = RGB(241, 150, 37);
    [chooseJoinTimeView addSubview:chooseJoinTimeTitleView];
    
    UIButton *chooseJoinTimeCancelBtn = [UIButton buttonWithType:UIButtonTypeCustom];
    chooseJoinTimeCancelBtn.frame = CGRectMake(0, 0, 60 * kScreenWidthProportion, 36 * kScreenHeightProportion);
    chooseJoinTimeCancelBtn.titleLabel.font = FONT(11.5 * kFontProportion);
    [chooseJoinTimeCancelBtn setTitle:@"取消" forState:(UIControlStateNormal)];
    [chooseJoinTimeCancelBtn setTitleColor:[UIColor whiteColor] forState:(UIControlStateNormal)];
    [chooseJoinTimeCancelBtn addTarget:timeView action:@selector(chooseJoinTimeCancelBtnClick) forControlEvents:(UIControlEventTouchUpInside)];
    [chooseJoinTimeTitleView addSubview:chooseJoinTimeCancelBtn];
    
    UILabel *chooseJoinTimeTitleLabel = [[UILabel alloc] initWithFrame:CGRectMake((kScreenWidth - 150) / 2, 0, 150, 36)];
    chooseJoinTimeTitleLabel.text = @"选择工作时间";
    chooseJoinTimeTitleLabel.textColor = [UIColor whiteColor];
    chooseJoinTimeTitleLabel.textAlignment = NSTextAlignmentCenter;
    chooseJoinTimeTitleLabel.font = FONT(12.0 * kFontProportion);
    [chooseJoinTimeTitleView addSubview:chooseJoinTimeTitleLabel];
    
    UIButton *chooseJoinTimeSureBtn = [UIButton buttonWithType:UIButtonTypeCustom];
    chooseJoinTimeSureBtn.frame = CGRectMake(kScreenWidth - 60 * kScreenWidthProportion, 0, 60 * kScreenWidthProportion, 36 * kScreenHeightProportion);
    chooseJoinTimeSureBtn.titleLabel.font = FONT(11.5 * kFontProportion);
    [chooseJoinTimeSureBtn setTitle:@"确定" forState:(UIControlStateNormal)];
    [chooseJoinTimeSureBtn setTitleColor:[UIColor whiteColor] forState:(UIControlStateNormal)];
    [chooseJoinTimeSureBtn addTarget:timeView action:@selector(chooseJoinTimeSureBtnClick) forControlEvents:(UIControlEventTouchUpInside)];
    [chooseJoinTimeTitleView addSubview:chooseJoinTimeSureBtn];
    
    timeView.chooseStrtusTimePickerView = [[UIPickerView alloc] initWithFrame:CGRectMake((kScreenWidth - 150 * kScreenHeightProportion) / 2, chooseJoinTimeTitleView.maxY, 150 * kScreenWidthProportion, 162 * kScreenHeightProportion)];
    timeView.chooseStrtusTimePickerView.delegate = timeView;
    timeView.chooseStrtusTimePickerView.dataSource = timeView;
    
    
    //    lineView1.centerY = timeView.chooseJoinTimePickerView.centerY - 20 / 2.0;
    //    lineView2.centerY = lineView1.maxY + 20 / 1.0;
    
    {
    UILabel *hourLabel = [[UILabel alloc] initWithFrame:CGRectMake(65 * kScreenWidthProportion, 71 * kScreenHeightProportion, 20 * kScreenWidthProportion, 20 * kScreenHeightProportion)];
    hourLabel.text = @"时";
    hourLabel.textColor = [UIColor blackColor];
    hourLabel.font = FONT(14 * kFontProportion);
    [timeView.chooseStrtusTimePickerView addSubview:hourLabel];
    
    UILabel *minLabel  = [[UILabel alloc] initWithFrame:CGRectMake(135 * kScreenWidthProportion, 71 * kScreenHeightProportion, 20 * kScreenWidthProportion, 20 * kScreenHeightProportion)];
    minLabel.text = @"分";
    minLabel.textColor = [UIColor blackColor];
    minLabel.font = FONT(14 * kFontProportion);
    [timeView.chooseStrtusTimePickerView addSubview:minLabel];
    
    [chooseJoinTimeView addSubview:timeView.chooseStrtusTimePickerView];
    
    //    UIView
    
    UIView *lineView1 = [[UIView alloc] initWithFrame:CGRectMake(10, 62 * kScreenHeightProportion , 150 * kScreenWidthProportion - 10, 1)];
    lineView1.backgroundColor = RGB(240, 240, 240);
    [timeView.chooseStrtusTimePickerView addSubview:lineView1];
    
    UIView *lineView2 = [[UIView alloc] initWithFrame:CGRectMake(10, 100* kScreenHeightProportion, 150 * kScreenWidthProportion - 10, 1)];
    lineView2.backgroundColor = RGB(240, 240, 240);
    [timeView.chooseStrtusTimePickerView addSubview:lineView2];
    }
    UILabel *statusLabel = [[UILabel alloc] initWithFrame:CGRectMake(20 * kScreenWidthProportion, 107 * kScreenHeightProportion, 80 * kScreenWidthProportion, 20 * kScreenHeightProportion)];
    statusLabel.text = @"开始：";
    statusLabel.textColor = [UIColor blackColor];
    statusLabel.font = FONT(14 * kFontProportion);
    [chooseJoinTimeView addSubview:statusLabel];
    
    [chooseJoinTimeView addSubview:timeView.chooseStrtusTimePickerView];
    
    UIView *lineView = [[UIView alloc] initWithFrame:CGRectMake(0, 197 * kScreenWidthProportion, kScreenWidth, 1)];
    lineView.backgroundColor = RGB(240, 240, 240);
    [chooseJoinTimeView addSubview:lineView];
    
#pragma mark - 第二个时间选择器
    timeView.chooseEndTimePickerView = [[UIPickerView alloc] initWithFrame:CGRectMake((kScreenWidth - 150 * kScreenHeightProportion) / 2, timeView.chooseStrtusTimePickerView.maxY, 150 * kScreenWidthProportion, 162 * kScreenHeightProportion)];
    timeView.chooseEndTimePickerView.delegate = timeView;
    timeView.chooseEndTimePickerView.dataSource = timeView;
    [chooseJoinTimeView addSubview:timeView.chooseEndTimePickerView];
    {
        UILabel *hourLabel = [[UILabel alloc] initWithFrame:CGRectMake(65 * kScreenWidthProportion, 71 * kScreenHeightProportion, 20 * kScreenWidthProportion, 20 * kScreenHeightProportion)];
        hourLabel.text = @"时";
        hourLabel.textColor = [UIColor blackColor];
        hourLabel.font = FONT(14 * kFontProportion);
        [timeView.chooseEndTimePickerView addSubview:hourLabel];
        
        UILabel *minLabel  = [[UILabel alloc] initWithFrame:CGRectMake(135 * kScreenWidthProportion, 71 * kScreenHeightProportion, 20 * kScreenWidthProportion, 20 * kScreenHeightProportion)];
        minLabel.text = @"分";
        minLabel.textColor = [UIColor blackColor];
        minLabel.font = FONT(14 * kFontProportion);
        [timeView.chooseEndTimePickerView addSubview:minLabel];
        
        
        //    UIView
        
        UIView *lineView1 = [[UIView alloc] initWithFrame:CGRectMake(10, 62 * kScreenHeightProportion , 150 * kScreenWidthProportion - 10, 1)];
        lineView1.backgroundColor = RGB(240, 240, 240);
        [timeView.chooseEndTimePickerView addSubview:lineView1];
        
        UIView *lineView2 = [[UIView alloc] initWithFrame:CGRectMake(10, 100* kScreenHeightProportion, 150 * kScreenWidthProportion - 10, 1)];
        lineView2.backgroundColor = RGB(240, 240, 240);
        [timeView.chooseEndTimePickerView addSubview:lineView2];
    }
    
    UILabel *endLabel = [[UILabel alloc] initWithFrame:CGRectMake(20 * kScreenWidthProportion, 269 * kScreenHeightProportion, 80 * kScreenWidthProportion, 20 * kScreenHeightProportion)];
    endLabel.text = @"结束：";
    endLabel.textColor = [UIColor blackColor];
    endLabel.font = FONT(14 * kFontProportion);
    [chooseJoinTimeView addSubview:endLabel];
    
}

- (void) initData {
    self.hourArray = @[@"00",@"01",@"02",@"03",@"04",@"05",@"06",@"07",@"08",@"09",@"10",@"11",@"12",@"13",@"14",@"15",@"16",@"17",@"18",@"19",@"20",@"21",@"22",@"23"];
    self.minArray = @[@"00",@"05",@"10",@"15",@"20",@"25",@"30",@"35",@"40",@"45",@"50",@"55"];
    self.gatherHourString = self.hourArray[0];
    self.gatherMinuteString = self.minArray[0];
    
    self.endHourString = self.hourArray[0];
    self.endMinuteString = self.minArray[0];
}
//取消按钮
- (void)chooseJoinTimeCancelBtnClick{
    [self removeFromSuperview];
}

//确定按钮
- (void)chooseJoinTimeSureBtnClick {
    NSString *timer1 = [NSString stringWithFormat:@"%@:%@",self.gatherHourString,self.gatherMinuteString];
    NSString *timer2 = [NSString stringWithFormat:@"%@:%@",self.endHourString,self.endMinuteString];
    if (self.chooseTimeBlock != nil) {
        self.chooseTimeBlock(timer1,timer2);
    }
    [self removeFromSuperview];
}
#pragma mark -- PickerView代理方法 --
-(NSInteger)numberOfComponentsInPickerView:(UIPickerView *)pickerView
{
    return 2;
}

-(NSInteger)pickerView:(UIPickerView *)pickerView numberOfRowsInComponent:(NSInteger)component
{
    if (pickerView == self.chooseStrtusTimePickerView) {
        if (component == 0) {
            return self.hourArray.count;
        }else
        {
            return self.minArray.count;
        }
    }
    if (component == 0) {
        return self.hourArray.count;
    }else
    {
        return self.minArray.count;
    }
}

-(CGFloat)pickerView:(UIPickerView *)pickerView rowHeightForComponent:(NSInteger)component
{
    return 40 * kScreenHeightProportion;
}

// 每列宽度
- (CGFloat)pickerView:(UIPickerView *)pickerView widthForComponent:(NSInteger)component {
    return 70 * kScreenWidthProportion;
}

-(UIView *)pickerView:(UIPickerView *)pickerView viewForRow:(NSInteger)row forComponent:(NSInteger)component reusingView:(UIView *)view
{
    if (pickerView == self.chooseStrtusTimePickerView) {
        UIView *pView = [[UIView alloc] initWithFrame:CGRectMake(0, 0, 75 * kScreenWidthProportion, 40 * kScreenHeightProportion)];
        UILabel *pLabel = [[UILabel alloc] initWithFrame:CGRectMake(0, 0, 75 * kScreenHeightProportion, 40 * kScreenHeightProportion)];
        if (component == 0) {
            pLabel.text = self.hourArray[row];
        }else
        {
            pLabel.text = self.minArray[row];
        }
        pLabel.textColor = [UIColor blackColor];
        pLabel.textAlignment = NSTextAlignmentCenter;
        pLabel.font = FONT(16 * kFontProportion);
        [pView addSubview:pLabel];
        [[self.chooseStrtusTimePickerView.subviews objectAtIndex:3] setHidden:YES];
        [[self.chooseStrtusTimePickerView.subviews objectAtIndex:4] setHidden:YES];
        return pView;
    } else {
        UIView *pView = [[UIView alloc] initWithFrame:CGRectMake(0, 0, 75 * kScreenWidthProportion, 40 * kScreenHeightProportion)];
        UILabel *pLabel = [[UILabel alloc] initWithFrame:CGRectMake(0, 0, 75 * kScreenHeightProportion, 40 * kScreenHeightProportion)];
        if (component == 0) {
            pLabel.text = self.hourArray[row];
        }else
        {
            pLabel.text = self.minArray[row];
        }
        pLabel.textColor = [UIColor blackColor];
        pLabel.textAlignment = NSTextAlignmentCenter;
        pLabel.font = FONT(16 * kFontProportion);
        [pView addSubview:pLabel];
        [[self.chooseEndTimePickerView.subviews objectAtIndex:1] setHidden:YES];
        [[self.chooseEndTimePickerView.subviews objectAtIndex:2] setHidden:YES];
        return pView;
    }
    
}

- (void)pickerView:(UIPickerView *)pickerView didSelectRow:(NSInteger)row inComponent:(NSInteger)component
{
    if (pickerView == self.chooseStrtusTimePickerView) {
        if (component == 0) {
            self.gatherHourString = self.hourArray[row];
        }else{
            self.gatherMinuteString = self.minArray[row];
        }
    }
    if (component == 0) {
        self.endHourString = self.hourArray[row];
    }else{
        self.endMinuteString = self.minArray[row];
    }
}


@end
