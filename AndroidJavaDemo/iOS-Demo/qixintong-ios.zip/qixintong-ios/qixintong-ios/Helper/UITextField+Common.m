//
//  UITextField+Common.m
//
//  Created by dmo on 15/6/29.
//  Copyright (c) 2015年 dmo. All rights reserved.
//

#import "UITextField+Common.h"

@implementation UITextField (Extensions)

- (void)setPaddingView:(CGRect)rect
{
    UIView *paddingView = [[UIView alloc] initWithFrame:rect];
    self.leftView = paddingView;
    self.leftViewMode  = UITextFieldViewModeAlways;
}

@end
