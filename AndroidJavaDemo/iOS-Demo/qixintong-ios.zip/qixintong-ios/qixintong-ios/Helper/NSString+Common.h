//
//  NSString+Common.h
//
//  Created by dmo on 15/8/8.
//  Copyright (c) 2015年 dmo. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface NSString (Common)

- (NSString *)trim;

//手机号码校验
- (BOOL)valiMobile;

@end
