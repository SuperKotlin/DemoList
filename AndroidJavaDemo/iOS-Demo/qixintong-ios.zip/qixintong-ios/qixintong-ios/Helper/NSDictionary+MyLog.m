//
//  NSDictionary+MyLog.m
//  pc436
//
//  Created by dmo on 16/7/28.
//  Copyright © 2016年 dmo. All rights reserved.
//

#import "NSDictionary+MyLog.h"

@implementation NSDictionary (MyLog)

#if 0

- (NSString *)descriptionWithLocale:(id)locale
{
    NSArray *allKeys = [self allKeys];
    
    NSMutableString *str = [[NSMutableString alloc] initWithFormat:@"\n\t{\t\n "];
    
    for (NSString *key in allKeys) {
        
        id value= self[key];
        
        [str appendFormat:@"\t \"%@\" = %@,\n",key, value];
        
    }
    
    [str appendString:@"\t}"];
    
    return str;
}

#endif

@end
