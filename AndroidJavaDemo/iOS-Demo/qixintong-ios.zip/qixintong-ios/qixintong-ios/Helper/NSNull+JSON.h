//
//  NSNull+JSON.h
//  SujiaMart-iOS
//
//  Created by dmo on 15/5/8.
//  Copyright (c) 2015年 dmo. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface NSNull (JSON)

@end
