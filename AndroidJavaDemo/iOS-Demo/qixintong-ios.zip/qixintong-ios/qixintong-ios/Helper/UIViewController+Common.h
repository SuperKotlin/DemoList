//
//  UIViewController+Common.h
//
//  Created by dmo on 15/5/13.
//  Copyright (c) 2015年 dmo. All rights reserved.
//

#import <UIKit/UIKit.h>
#import <MBProgressHUD/MBProgressHUD.h>


@interface UIViewController (Common)

@property (nonatomic, retain) MBProgressHUD *progressHUD;


#pragma mark - Naviagtion

- (void)customNavigationBar:(NSString *)title;

- (void)customNavigationBarTitle:(NSString *)title;

#pragma mark - MBProgressHUD

- (void)showHUDTextOnly: (NSString *)message;

- (void)showHUDTextBig:(NSString *)message andFont:(CGFloat)font andHeight:(CGFloat)height;

- (void)showHUDSimple;

- (void)hideHUD;

- (void)shouKeyboard;

#pragma mark -- 缓用按钮
- (void)timeFire:(UIButton *)button;
- (void)showTabBarView:(BOOL)show;

#pragma mark - Request Common

- (NSURLSessionDataTask *)defaultRequestwithURL: (NSString *)URL withParameters: (NSDictionary *)parameters withMethod: (NSString *)method withBlock:(void (^)(NSDictionary *dict, NSError *error))block;

#pragma mark - 实现多图片上传
-(void)startMultiPartUploadTaskWithURL:(NSString *)url
                           imagesArray:(NSArray *)images
                     parameterOfimages:(NSString *)parameter
                        parametersDict:(NSDictionary *)parameters
                      compressionRatio:(float)ratio
                          succeedBlock:(void (^)(NSDictionary *dict))succeedBlock
                           failedBlock:(void (^)(NSError *))failedBlock;

#pragma mark - NSArray或NSDictionary转成JSON各式
- (NSString*)ObjectToJson:(id)dic;

//#pragma mark - 角标设置
//-(void)cornerNumber;
#pragma mark - 绘制虚线
- (void)drawDashLine:(UIView *)lineView lineLength:(int)lineLength lineSpacing:(int)lineSpacing lineColor:(UIColor *)lineColor;

#pragma mark -uicolor转uiimage
- (UIImage *)createImageWithColor:(UIColor *)color;

//给View设置渐变色
-(void)setCAGradientLayerForView:(UIView *)view cornerRadius:(CGFloat)cornerRadius;


@end
