//
//  NSArray+MyLog.m
//  pc436
//
//  Created by dmo on 16/7/28.
//  Copyright © 2016年 dmo. All rights reserved.
//

#import "NSArray+MyLog.h"

@implementation NSArray (MyLog)

#if 0

- (NSString *)descriptionWithLocale:(id)locale
{
    NSMutableString *str = [NSMutableString stringWithFormat:@"%lu 个 \n(", (unsigned long)self.count];
    
    for (id obj in self) {
        [str appendFormat:@"\t%@,", obj];
    }
    
    [str appendString:@"\n)"];
    
    return str;
}

#endif

@end
