//
//  ApplicationForLoanViewController.m
//  qixintong-ios
//
//  Created by buwen zhou on 2018/4/24.
//  Copyright © 2018年 dmooo. All rights reserved.
//

#import "ApplicationForLoanViewController.h"
#import "ApplicationForLoanTableViewCell.h"
#import "ApplicationForLoanDetailsViewController.h"
#import "LoanApplyTwoViewController.h"

@interface ApplicationForLoanViewController ()<UITableViewDelegate,UITableViewDataSource>{
    //列表
    UITableView *loanTableView;
    //列表数据
    NSMutableArray *listMutArray;
}

@end

@implementation ApplicationForLoanViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    [self initUI];
    
}
- (void)viewWillAppear:(BOOL)animated{
    [super viewWillAppear:YES];
    [self initData];
}
- (void)initData{
    __block int page = 1;
    listMutArray = [NSMutableArray array];
    [MBProgressHUD showHUDAddedTo:self.view animated:YES];
    NSDictionary *parameters = @{
                                 @"token":[[NSUserDefaults standardUserDefaults] objectForKey:kToken],
                                 @"status":@"",
                                 @"p":[NSString stringWithFormat:@"%d",page],
                                 @"per":@"10"
                                 };
    [self defaultRequestwithURL:kGetApplyListURL withParameters:parameters withMethod:kPOST withBlock:^(NSDictionary *dict, NSError *error) {
        [MBProgressHUD hideHUDForView:self.view animated:YES];
        if ([[NSString stringWithFormat:@"%@",[dict objectForKey:@"code"]] isEqualToString:@"0"]) {
            [listMutArray addObjectsFromArray:[[dict objectForKey:@"data"] objectForKey:@"list"]];
            [loanTableView reloadData];
            
            page ++;
        }else if ([[NSString stringWithFormat:@"%@",[dict objectForKey:@"code"]] isEqualToString:@"104"]){
            [self.navigationController pushViewController:[LoginOrRegisterViewController new] animated:YES];
        }else{
            [self showHUDTextOnly:dict[kMessage]];
        }
    }];
    
    loanTableView.mj_header = [MJRefreshNormalHeader headerWithRefreshingBlock:^{
        page = 1;
        listMutArray = [NSMutableArray array];
        [MBProgressHUD showHUDAddedTo:self.view animated:YES];
        NSDictionary *parameters = @{
                                     @"token":[[NSUserDefaults standardUserDefaults] objectForKey:kToken],
                                     @"status":@"",
                                     @"p":[NSString stringWithFormat:@"%d",page],
                                     @"per":@"10"
                                     };
        [self defaultRequestwithURL:kGetApplyListURL withParameters:parameters withMethod:kPOST withBlock:^(NSDictionary *dict, NSError *error) {
            [MBProgressHUD hideHUDForView:self.view animated:YES];
            if ([[NSString stringWithFormat:@"%@",[dict objectForKey:@"code"]] isEqualToString:@"0"]) {
                [listMutArray addObjectsFromArray:[[dict objectForKey:@"data"] objectForKey:@"list"]];
                [loanTableView reloadData];
                page ++;
            }else if ([[NSString stringWithFormat:@"%@",[dict objectForKey:@"code"]] isEqualToString:@"104"]){
                [self.navigationController pushViewController:[LoginOrRegisterViewController new] animated:YES];
            }else{
                [self showHUDTextOnly:dict[kMessage]];
            }
            [loanTableView.mj_header endRefreshing];
        }];
    }];
    
    loanTableView.mj_footer = [MJRefreshBackNormalFooter footerWithRefreshingBlock:^{
        [MBProgressHUD showHUDAddedTo:self.view animated:YES];
        NSDictionary *parameters = @{
                                     @"token":[[NSUserDefaults standardUserDefaults] objectForKey:kToken],
                                     @"status":@"",
                                     @"p":[NSString stringWithFormat:@"%d",page],
                                     @"per":@"10"
                                     };
        [self defaultRequestwithURL:kGetApplyListURL withParameters:parameters withMethod:kPOST withBlock:^(NSDictionary *dict, NSError *error) {
            [MBProgressHUD hideHUDForView:self.view animated:YES];
            if ([[NSString stringWithFormat:@"%@",[dict objectForKey:@"code"]] isEqualToString:@"0"]) {
                [listMutArray addObjectsFromArray:[[dict objectForKey:@"data"] objectForKey:@"list"]];
                [loanTableView reloadData];
                page ++;
            }else if ([[NSString stringWithFormat:@"%@",[dict objectForKey:@"code"]] isEqualToString:@"104"]){
                [self.navigationController pushViewController:[LoginOrRegisterViewController new] animated:YES];
            }else{
                [self showHUDTextOnly:dict[kMessage]];
            }
            [loanTableView.mj_footer endRefreshing];
        }];
    }];
    
}
- (void)initUI
{
    self.view.backgroundColor = kGrayBackgroundColor;
    [self customNavigationBar:@"申请中借款"];
    
    loanTableView = [[UITableView alloc] initWithFrame:CGRectMake(0, kHeaderHeight, kScreenWidth, kScreenHeight - kHeaderHeight)];
    loanTableView.separatorStyle = UITableViewCellSeparatorStyleNone;
    loanTableView.backgroundColor = kGrayBackgroundColor;
    loanTableView.delegate = self;
    loanTableView.dataSource = self;
    [self.view addSubview:loanTableView];
}
#pragma mark - tableView代理方法
- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section{
    return listMutArray.count;
}
- (CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath{
    return 114 * kScreenHeightProportion;
}
- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath{
    static NSString *indefier = @"Cell";
    ApplicationForLoanTableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:indefier];
    if (!cell) {
        cell = [[ApplicationForLoanTableViewCell alloc] initWithStyle:UITableViewCellStyleDefault reuseIdentifier:indefier];
    }
    cell.selectionStyle = UITableViewCellSelectionStyleNone;
    
    NSDictionary *dict = listMutArray[indexPath.row];
    cell.typeLabel.text = [NSString stringWithFormat:@"类型：%@",dict[@"type"]];
    cell.timeLabel.text = [NSString stringWithFormat:@"申请时间:%@",[[NSString stringWithFormat:@"%@",dict[@"apply_time"]] substringWithRange:NSMakeRange(0, 10)]];
    cell.moneyLabel.text = [NSString stringWithFormat:@"金额：%@万",dict[@"money"]];
    NSMutableAttributedString *str = [[NSMutableAttributedString alloc] initWithString:cell.moneyLabel.text];
    [str addAttribute:NSForegroundColorAttributeName value:kGrayLabelColor range:NSMakeRange(0, 3)];
    [str addAttribute:NSFontAttributeName value:FONT(11 * kFontProportion) range:NSMakeRange(0, 3)];
    cell.moneyLabel.attributedText = str;
    cell.rateLabel.text = [NSString stringWithFormat:@"日费率：%@",dict[@"product_rate"]];
    
    [cell.statusButton addTarget:self action:@selector(statusButtonAction:) forControlEvents:UIControlEventTouchUpInside];
    cell.statusButton.tag = indexPath.row + kTagStart;
    
    //1发起申请，等待初审  2初审通过  3初审不通过  4再次申请，等待复审  5复审通过  6复审不通过
    NSString *statusStr = [NSString stringWithFormat:@"%@",dict[@"status"]];
    if ([statusStr isEqualToString:@"1"]) {
        cell.statusImgView.image = [UIImage imageNamed:@"apply_trial"];
        cell.statusLabel.text = @"初审中";
        cell.statusLabel.textColor = RGB(247, 157, 38);
        cell.statusButton.userInteractionEnabled = NO;
    }else if ([statusStr isEqualToString:@"2"]){
        cell.statusImgView.image = [UIImage imageNamed:@"apply_upload"];
        cell.statusLabel.text = @"上传证件";
        cell.statusLabel.textColor = RGB(247, 157, 38);
        cell.statusButton.userInteractionEnabled = YES;
    }else if ([statusStr isEqualToString:@"3"]){
        cell.statusImgView.image = [UIImage imageNamed:@"apply_notthrough"];
        cell.statusLabel.text = @"初审未通过";
        cell.statusLabel.textColor = [UIColor redColor];
        cell.statusButton.userInteractionEnabled = NO;
    }else if ([statusStr isEqualToString:@"4"]){
        cell.statusImgView.image = [UIImage imageNamed:@"apply_trial"];
        cell.statusLabel.text = @"复审中";
        cell.statusLabel.textColor = RGB(247, 157, 38);
        cell.statusButton.userInteractionEnabled = NO;
    }else if ([statusStr isEqualToString:@"5"]){
        cell.statusImgView.image = [UIImage imageNamed:@"apply_money"];
        cell.statusLabel.text = @"到账成功";
        cell.statusLabel.textColor = RGB(59, 149, 255);
        cell.statusButton.userInteractionEnabled = NO;
    }else if ([statusStr isEqualToString:@"6"]){
        cell.statusImgView.image = [UIImage imageNamed:@"apply_notthrough"];
        cell.statusLabel.text = @"审核未通过";
        cell.statusLabel.textColor = [UIColor redColor];
        cell.statusButton.userInteractionEnabled = NO;
    }
    
    return cell;
}
- (void)statusButtonAction:(UIButton *)sender{
    NSDictionary *dict = listMutArray[sender.tag - kTagStart];
    LoanApplyTwoViewController *loanVC = [[LoanApplyTwoViewController alloc] init];
    loanVC.productApplyIdStr = [NSString stringWithFormat:@"%@",dict[@"product_apply_id"]];
    [self.navigationController pushViewController:loanVC animated:YES];
}
- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath{
    NSDictionary *dict = listMutArray[indexPath.row];
    NSString *statusStr = [NSString stringWithFormat:@"%@",dict[@"status"]];
    ApplicationForLoanDetailsViewController *detailsVC = [[ApplicationForLoanDetailsViewController alloc] init];
    detailsVC.productApplyIdStr = [NSString stringWithFormat:@"%@",dict[@"product_apply_id"]];
    if ([statusStr isEqualToString:@"1"]) {
        //初审中
        detailsVC.typeStr = @"1";
        [self.navigationController pushViewController:detailsVC animated:YES];
    }else if ([statusStr isEqualToString:@"2"]){
        //上传证件
        LoanApplyTwoViewController *loanVC = [[LoanApplyTwoViewController alloc] init];
        [self.navigationController pushViewController:loanVC animated:YES];
    }else if ([statusStr isEqualToString:@"3"]){
        //初审未通过
        [self showHUDTextOnly:[NSString stringWithFormat:@"%@",dict[@"check_reason"]]];
    }else if ([statusStr isEqualToString:@"4"]){
        //复审中
        detailsVC.typeStr = @"4";
        [self.navigationController pushViewController:detailsVC animated:YES];
    }else if ([statusStr isEqualToString:@"5"]){
        //到账成功
        detailsVC.typeStr = @"5";
        [self.navigationController pushViewController:detailsVC animated:YES];
    }else if ([statusStr isEqualToString:@"6"]){
        //审核未通过
        [self showHUDTextOnly:[NSString stringWithFormat:@"%@",dict[@"check_reason2"]]];
    }
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

@end
