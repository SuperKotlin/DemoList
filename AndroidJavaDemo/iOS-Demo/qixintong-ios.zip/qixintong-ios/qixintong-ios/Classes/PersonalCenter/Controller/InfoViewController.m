//
//  InfoViewController.m
//  qixintong-ios
//
//  Created by buwen zhou on 2018/4/24.
//  Copyright © 2018年 dmooo. All rights reserved.
//

#import "InfoViewController.h"

@interface InfoViewController (){
    UITextField *companyTextField;
    UITextField *nameTextField;
    UITextField *phoneTextField;
    UITextField *addressTextField;
}

@end

@implementation InfoViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    [self initUI];
    [self initData];
}
- (void)initData{
    NSDictionary *parameters = @{
                                 @"token":[[NSUserDefaults standardUserDefaults] objectForKey:kToken]
                                 };
    [self defaultRequestwithURL:kUserCenterURL withParameters:parameters withMethod:kPOST withBlock:^(NSDictionary *dict, NSError *error) {
        if ([[NSString stringWithFormat:@"%@",[dict objectForKey:@"code"]] isEqualToString:@"0"]) {
            NSDictionary *userDetailDict = [[dict objectForKey:@"data"] objectForKey:@"userDetail"];
            companyTextField.text = [NSString stringWithFormat:@"%@",userDetailDict[@"company"]];
            nameTextField.text = [NSString stringWithFormat:@"%@",userDetailDict[@"linkman"]];
            phoneTextField.text = [NSString stringWithFormat:@"%@",userDetailDict[@"contact"]];
            addressTextField.text = [NSString stringWithFormat:@"%@",userDetailDict[@"detail_address"]];
            
        }else if ([[NSString stringWithFormat:@"%@",[dict objectForKey:@"code"]] isEqualToString:@"104"] || [[NSString stringWithFormat:@"%@",[dict objectForKey:@"code"]] isEqualToString:@"105"]){
            [self.navigationController pushViewController:[LoginOrRegisterViewController new] animated:YES];
        }else{
            [self showHUDTextOnly:dict[kMessage]];
        }
    }];
}
- (void)initUI
{
    self.view.backgroundColor = kGrayBackgroundColor;
    [self customNavigationBar:@"我的资料"];
    
    UIView *setView = [[UIView alloc] initWithFrame:CGRectMake(6 * kScreenWidthProportion, kHeaderHeight + 13 * kScreenHeightProportion, kScreenWidth - 12 * kScreenHeightProportion, 48 * 4 * kScreenHeightProportion)];
    [setView setCornerRadius:8.f * kScreenHeightProportion];
    setView.backgroundColor = [UIColor whiteColor];
    [setView setBorder:1.f color:RGB(224, 224, 224)];
    [self.view addSubview:setView];
    
    NSArray *titleArray = @[@"企业全称",@"法人姓名",@"公司座机",@"公司地址"];
    for (int i = 0; i < 4; i ++) {
        UILabel *titleLabel = [[UILabel alloc] initWithFrame:CGRectMake(8 * kScreenWidthProportion,48 * kScreenHeightProportion * i, 100 * kScreenWidthProportion, 48 * kScreenHeightProportion)];
        titleLabel.font = FONT(12 * kFontProportion);
        titleLabel.text = titleArray[i];
        [setView addSubview:titleLabel];
        
        UIView *lineView = [[UIView alloc] initWithFrame:CGRectMake(8 * kScreenWidthProportion, titleLabel.maxY - 1 * kScreenHeightProportion, setView.width - 16 * kScreenWidthProportion, 1 * kScreenHeightProportion)];
        lineView.backgroundColor = kGrayBackgroundColor;
        [setView addSubview:lineView];
    }
    
    companyTextField = [[UITextField alloc] initWithFrame:CGRectMake(108 * kScreenWidthProportion, 0, setView.width - 116 * kScreenWidthProportion, 48 * kScreenHeightProportion)];
    companyTextField.font = FONT(13 * kFontProportion);
    companyTextField.placeholder = @"请输入企业全称";
    companyTextField.textAlignment = NSTextAlignmentRight;
    [setView addSubview:companyTextField];
    
    nameTextField = [[UITextField alloc] initWithFrame:CGRectMake(companyTextField.minX, companyTextField.maxY, companyTextField.width, companyTextField.height)];
    nameTextField.font = FONT(13 * kFontProportion);
    nameTextField.placeholder = @"请输入法人姓名";
    nameTextField.textAlignment = NSTextAlignmentRight;
    [setView addSubview:nameTextField];
    
    phoneTextField = [[UITextField alloc] initWithFrame:CGRectMake(nameTextField.minX, nameTextField.maxY, companyTextField.width, companyTextField.height)];
    phoneTextField.font = FONT(13 * kFontProportion);
    phoneTextField.placeholder = @"请输入公司座机";
    phoneTextField.textAlignment = NSTextAlignmentRight;
    [setView addSubview:phoneTextField];
    
    addressTextField = [[UITextField alloc] initWithFrame:CGRectMake(phoneTextField.minX, phoneTextField.maxY, companyTextField.width, companyTextField.height)];
    addressTextField.font = FONT(13 * kFontProportion);
    addressTextField.placeholder = @"请输入公司地址";
    addressTextField.textAlignment = NSTextAlignmentRight;
    [setView addSubview:addressTextField];
    
    UIButton *loginButton = [[UIButton alloc] initWithFrame:CGRectMake(50 * kScreenWidthProportion, setView.maxY + 35 * kScreenHeightProportion, kScreenWidth - 100 * kScreenWidthProportion, 34 * kScreenHeightProportion)];
    [loginButton setTitle:@"确定" forState:UIControlStateNormal];
    [loginButton setTitleColor:[UIColor whiteColor] forState:UIControlStateNormal];
    loginButton.titleLabel.font = FONT(16 * kFontProportion);
    loginButton.backgroundColor = kDefaultColor;
    [loginButton setCornerRadius:15.f * kScreenHeightProportion];
    [loginButton addTarget:self action:@selector(loginButtonAction) forControlEvents:UIControlEventTouchUpInside];
    [self.view addSubview:loginButton];
    
}
#pragma mark - 确认
- (void)loginButtonAction{
    [self.view endEditing:YES];
    
    NSDictionary *parameters = @{
                                 @"token":[[NSUserDefaults standardUserDefaults] objectForKey:kToken],
                                 @"company":companyTextField.text,
                                 @"linkman":nameTextField.text,
                                 @"contact":phoneTextField.text,
                                 @"detail_address":addressTextField.text
                                 };
    [self defaultRequestwithURL:kEditUserMsgURL withParameters:parameters withMethod:kPOST withBlock:^(NSDictionary *dict, NSError *error) {
        if ([[NSString stringWithFormat:@"%@",[dict objectForKey:@"code"]] isEqualToString:@"0"]) {
            [self showHUDTextOnly:dict[kMessage]];
            [self.navigationController popViewControllerAnimated:YES];
        }else if ([[NSString stringWithFormat:@"%@",[dict objectForKey:@"code"]] isEqualToString:@"104"]){
            [self.navigationController pushViewController:[LoginOrRegisterViewController new] animated:YES];
        }else{
            [self showHUDTextOnly:dict[kMessage]];
        }
    }];
}
    
- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

@end
