//
//  FeedBackViewController.m
//  qixintong-ios
//
//  Created by buwen zhou on 2018/4/24.
//  Copyright © 2018年 dmooo. All rights reserved.
//

#import "FeedBackViewController.h"

@interface FeedBackViewController (){
    UITextField *nameTextField;
    UITextField *phoneTextField;
    UITextField *markTextField;
}

@end

@implementation FeedBackViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    [self initUI];
}
- (void)initUI
{
    self.view.backgroundColor = kGrayBackgroundColor;
    [self customNavigationBar:@"意见反馈"];
    
    UIView *setView = [[UIView alloc] initWithFrame:CGRectMake(6 * kScreenWidthProportion, kHeaderHeight + 13 * kScreenHeightProportion, kScreenWidth - 12 * kScreenHeightProportion, 48 * 3 * kScreenHeightProportion)];
    [setView setCornerRadius:8.f * kScreenHeightProportion];
    setView.backgroundColor = [UIColor whiteColor];
    [self.view addSubview:setView];
    
    NSArray *titleArray = @[@"联系人",@"联系方式",@"留言"];
    for (int i = 0; i < 3; i ++) {
        UILabel *titleLabel = [[UILabel alloc] initWithFrame:CGRectMake(8 * kScreenWidthProportion,48 * kScreenHeightProportion * i, 100 * kScreenWidthProportion, 48 * kScreenHeightProportion)];
        titleLabel.font = FONT(12 * kFontProportion);
        titleLabel.text = titleArray[i];
        [setView addSubview:titleLabel];
        
        UIView *lineView = [[UIView alloc] initWithFrame:CGRectMake(8 * kScreenWidthProportion, titleLabel.maxY - 1 * kScreenHeightProportion, setView.width - 16 * kScreenWidthProportion, 1 * kScreenHeightProportion)];
        lineView.backgroundColor = kGrayBackgroundColor;
        [setView addSubview:lineView];
    }
    
    nameTextField = [[UITextField alloc] initWithFrame:CGRectMake(108 * kScreenWidthProportion, 0, setView.width - 116 * kScreenWidthProportion, 48 * kScreenHeightProportion)];
    nameTextField.font = FONT(13 * kFontProportion);
    nameTextField.placeholder = @"请输入联系人";
    nameTextField.textAlignment = NSTextAlignmentRight;
    [setView addSubview:nameTextField];
    
    phoneTextField = [[UITextField alloc] initWithFrame:CGRectMake(nameTextField.minX, nameTextField.maxY, nameTextField.width, nameTextField.height)];
    phoneTextField.font = FONT(13 * kFontProportion);
    phoneTextField.placeholder = @"请输入联系方式";
    phoneTextField.textAlignment = NSTextAlignmentRight;
    [setView addSubview:phoneTextField];
    
    markTextField = [[UITextField alloc] initWithFrame:CGRectMake(phoneTextField.minX, phoneTextField.maxY, phoneTextField.width, phoneTextField.height)];
    markTextField.font = FONT(13 * kFontProportion);
    markTextField.placeholder = @"请输入留言";
    markTextField.textAlignment = NSTextAlignmentRight;
    [setView addSubview:markTextField];
    
    UIButton *loginButton = [[UIButton alloc] initWithFrame:CGRectMake(50 * kScreenWidthProportion, setView.maxY + 35 * kScreenHeightProportion, kScreenWidth - 100 * kScreenWidthProportion, 34 * kScreenHeightProportion)];
    [loginButton setTitle:@"提交" forState:UIControlStateNormal];
    [loginButton setTitleColor:[UIColor whiteColor] forState:UIControlStateNormal];
    loginButton.titleLabel.font = FONT(16 * kFontProportion);
    loginButton.backgroundColor = kDefaultColor;
    [loginButton setCornerRadius:15.f * kScreenHeightProportion];
    [loginButton addTarget:self action:@selector(loginButtonAction) forControlEvents:UIControlEventTouchUpInside];
    [self.view addSubview:loginButton];
    
}
- (BOOL)VerificationPassWord:(NSString*)carNo
{
    NSString *carRegex = @"[A-Za-z_0-9]{6,12}";
    NSPredicate *carTest = [NSPredicate predicateWithFormat:@"SELF MATCHES %@",carRegex];
    NSLog(@"carTest is %@",carTest);
    return [carTest evaluateWithObject:carNo];
}
#pragma mark - 确认
- (void)loginButtonAction{
    [self.view endEditing:YES];
    
    if ([nameTextField.text isEqualToString:@""]) {
        [self showHUDTextOnly:@"请输入联系人"];
        return;
    }
    
    if ([phoneTextField.text isEqualToString:@""]) {
        [self showHUDTextOnly:@"请输入联系方式"];
        return;
    }
    
    if ([markTextField.text isEqualToString:@""]) {
        [self showHUDTextOnly:@"请输入留言"];
        return;
    }
    
    NSDictionary *parameters = @{
                                 @"linkman":nameTextField.text,
                                 @"phone":phoneTextField.text,
                                 @"content":markTextField.text,
                                 @"cat_id":@""
                                 };
    [self defaultRequestwithURL:kFeedbackURL withParameters:parameters withMethod:kPOST withBlock:^(NSDictionary *dict, NSError *error) {
        if ([[NSString stringWithFormat:@"%@",[dict objectForKey:@"code"]] isEqualToString:@"0"]) {
            [self showHUDTextOnly:dict[kMessage]];
            [self.navigationController popViewControllerAnimated:YES];
        }else if ([[NSString stringWithFormat:@"%@",[dict objectForKey:@"code"]] isEqualToString:@"104"]){
            [self.navigationController pushViewController:[LoginOrRegisterViewController new] animated:YES];
        }else{
            [self showHUDTextOnly:dict[kMessage]];
        }
    }];
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

@end
