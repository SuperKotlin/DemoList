//
//  MessageViewController.m
//  qixintong-ios
//
//  Created by buwen zhou on 2018/4/24.
//  Copyright © 2018年 dmooo. All rights reserved.
//

#import "MessageViewController.h"
#import "MessageTableViewCell.h"
#import "ArticleViewController.h"

@interface MessageViewController ()<UITableViewDelegate,UITableViewDataSource>{
    //列表
    UITableView *messageTableView;
    //列表数据
    NSMutableArray *listMutArray;
}

@end

@implementation MessageViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    [self initUI];
    [self initData];
}
- (void)initData{
    __block int page = 1;
    listMutArray = [NSMutableArray array];
    [MBProgressHUD showHUDAddedTo:self.view animated:YES];
    NSDictionary *parameters = @{
                                 @"cat_id":@"2",
                                 @"p":[NSString stringWithFormat:@"%d",page],
                                 @"per":@"10"
                                 };
    [self defaultRequestwithURL:kGetArticleListURL withParameters:parameters withMethod:kPOST withBlock:^(NSDictionary *dict, NSError *error) {
        [MBProgressHUD hideHUDForView:self.view animated:YES];
        if ([[NSString stringWithFormat:@"%@",[dict objectForKey:@"code"]] isEqualToString:@"0"]) {
            [listMutArray addObjectsFromArray:[[dict objectForKey:@"data"] objectForKey:@"list"]];
            [messageTableView reloadData];
            
            page ++;
        }else if ([[NSString stringWithFormat:@"%@",[dict objectForKey:@"code"]] isEqualToString:@"104"]){
            [self.navigationController pushViewController:[LoginOrRegisterViewController new] animated:YES];
        }else{
            [self showHUDTextOnly:dict[kMessage]];
        }
    }];
    
    messageTableView.mj_header = [MJRefreshNormalHeader headerWithRefreshingBlock:^{
        page = 1;
        listMutArray = [NSMutableArray array];
        [MBProgressHUD showHUDAddedTo:self.view animated:YES];
        NSDictionary *parameters = @{
                                     @"cat_id":@"2",
                                     @"p":[NSString stringWithFormat:@"%d",page],
                                     @"per":@"10"
                                     };
        [self defaultRequestwithURL:kGetArticleListURL withParameters:parameters withMethod:kPOST withBlock:^(NSDictionary *dict, NSError *error) {
            [MBProgressHUD hideHUDForView:self.view animated:YES];
            if ([[NSString stringWithFormat:@"%@",[dict objectForKey:@"code"]] isEqualToString:@"0"]) {
                [listMutArray addObjectsFromArray:[[dict objectForKey:@"data"] objectForKey:@"list"]];
                [messageTableView reloadData];
                page ++;
            }else if ([[NSString stringWithFormat:@"%@",[dict objectForKey:@"code"]] isEqualToString:@"104"]){
                [self.navigationController pushViewController:[LoginOrRegisterViewController new] animated:YES];
            }else{
                [self showHUDTextOnly:dict[kMessage]];
            }
            [messageTableView.mj_header endRefreshing];
        }];
    }];
    
    messageTableView.mj_footer = [MJRefreshBackNormalFooter footerWithRefreshingBlock:^{
        [MBProgressHUD showHUDAddedTo:self.view animated:YES];
        NSDictionary *parameters = @{
                                     @"cat_id":@"2",
                                     @"p":[NSString stringWithFormat:@"%d",page],
                                     @"per":@"10"
                                     };
        [self defaultRequestwithURL:kGetArticleListURL withParameters:parameters withMethod:kPOST withBlock:^(NSDictionary *dict, NSError *error) {
            [MBProgressHUD hideHUDForView:self.view animated:YES];
            if ([[NSString stringWithFormat:@"%@",[dict objectForKey:@"code"]] isEqualToString:@"0"]) {
                [listMutArray addObjectsFromArray:[[dict objectForKey:@"data"] objectForKey:@"list"]];
                [messageTableView reloadData];
                page ++;
            }else if ([[NSString stringWithFormat:@"%@",[dict objectForKey:@"code"]] isEqualToString:@"104"]){
                [self.navigationController pushViewController:[LoginOrRegisterViewController new] animated:YES];
            }else{
                [self showHUDTextOnly:dict[kMessage]];
            }
            [messageTableView.mj_footer endRefreshing];
        }];
    }];
    
}
- (void)initUI
{
    self.view.backgroundColor = kGrayBackgroundColor;
    [self customNavigationBar:@"我的消息"];
    
    messageTableView = [[UITableView alloc] initWithFrame:CGRectMake(0, kHeaderHeight, kScreenWidth, kScreenHeight - kHeaderHeight)];
    messageTableView.separatorStyle = UITableViewCellSeparatorStyleNone;
    messageTableView.backgroundColor = kGrayLineColor;
    messageTableView.delegate = self;
    messageTableView.dataSource = self;
    [self.view addSubview:messageTableView];
}
#pragma mark - tableView代理方法
- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section{
    return listMutArray.count;
}
- (CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath{
    return 58 * kScreenHeightProportion;
}
- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath{
    static NSString *indefier = @"Cell";
    MessageTableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:indefier];
    if (!cell) {
        cell = [[MessageTableViewCell alloc] initWithStyle:UITableViewCellStyleDefault reuseIdentifier:indefier];
    }
    cell.selectionStyle = UITableViewCellSelectionStyleNone;
    
    NSDictionary *dict = listMutArray[indexPath.row];
    cell.titleLabel.text = [NSString stringWithFormat:@"%@",dict[@"title"]];
    
    NSString *contentStr = [NSString stringWithFormat:@"%@",dict[@"description"]];
    NSAttributedString *attrStr = [[NSAttributedString alloc] initWithData:[contentStr dataUsingEncoding:NSUnicodeStringEncoding] options:@{ NSDocumentTypeDocumentAttribute: NSHTMLTextDocumentType } documentAttributes:nil error:nil];
    cell.contentLabel.attributedText = attrStr;
    cell.timeLabel.text = [[NSString stringWithFormat:@"%@",dict[@"pubtime"]] substringWithRange:NSMakeRange(0, 10)];
    
    
    return cell;
}
- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath{
    NSDictionary *dict = listMutArray[indexPath.row];
    ArticleViewController *arVC = [[ArticleViewController alloc] init];
    arVC.articleIdStr = [NSString stringWithFormat:@"%@",dict[@"article_id"]];
    arVC.titleStr = @"我的消息";
    [self.navigationController pushViewController:arVC animated:YES];
}
- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

@end
