//
//  ArticleViewController.m
//  qixintong-ios
//
//  Created by buwen zhou on 2018/4/24.
//  Copyright © 2018年 dmooo. All rights reserved.
//

#import "ArticleViewController.h"

@interface ArticleViewController (){
    UITextView *contentTextView;
    UIScrollView *mainScrollView;
}


@end

@implementation ArticleViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    [self initUI];
    [self initData];
}
- (void)initData{
    NSDictionary *parameters = @{
                                 @"article_id":self.articleIdStr
                                 };
    [self defaultRequestwithURL:kGetArticleMsgURL withParameters:parameters withMethod:kPOST withBlock:^(NSDictionary *dict, NSError *error) {
        if ([[NSString stringWithFormat:@"%@",[dict objectForKey:@"code"]] isEqualToString:@"0"]) {
            NSDictionary *article_msg = [[dict objectForKey:@"data"] objectForKey:@"article_msg"];
            NSString *dataStr = [NSString stringWithFormat:@"%@",article_msg[@"content"]];
            NSLog(@"dataStr===%@",dataStr);
            NSString *htmlString = [NSString stringWithFormat:@"%@%@%@",@"<head><style>img{max-width:",[NSString stringWithFormat:@"%f%@",kScreenWidth - 8 * kScreenWidthProportion * 2,@"!important;}</style></head>"],dataStr];
            
            NSAttributedString *attributedString = [[NSAttributedString alloc] initWithData:[htmlString dataUsingEncoding:NSUnicodeStringEncoding] options:@{ NSDocumentTypeDocumentAttribute: NSHTMLTextDocumentType } documentAttributes:nil error:nil];
            contentTextView.attributedText = attributedString;
            contentTextView.height = [self heightForString:contentTextView andWidth:(kScreenWidth - 8 * kScreenWidthProportion * 2)];
            contentTextView.contentSize = CGSizeMake(kScreenWidth - 8 * kScreenWidthProportion * 2, contentTextView.height);
            
            if (contentTextView.height < (kScreenHeight - kHeaderHeight)) {
                mainScrollView.contentSize = CGSizeMake(kScreenWidth, kScreenHeight - kHeaderHeight);
            }else{
                mainScrollView.contentSize = CGSizeMake(kScreenWidth, contentTextView.maxY);
            }
            
        }else{
            [self showHUDTextOnly:[NSString stringWithFormat:@"%@",dict[kMessage]]];
        }
    }];
}
- (void)initUI
{
    self.view.backgroundColor = [UIColor whiteColor];
    [self customNavigationBar:self.titleStr];
    
    mainScrollView = [[UIScrollView alloc] initWithFrame:CGRectMake(0, kHeaderHeight, kScreenWidth, kScreenHeight - kHeaderHeight)];
    [self.view addSubview:mainScrollView];
    
    contentTextView = [[UITextView alloc] initWithFrame:CGRectMake(8 * kScreenWidthProportion, 0, kScreenWidth - 8 * kScreenWidthProportion * 2, 200)];
    contentTextView.backgroundColor = [UIColor whiteColor];
    contentTextView.font = FONT(12 * kFontProportion);
    [mainScrollView addSubview:contentTextView];
}
- (float) heightForString:(UITextView *)textView andWidth:(float)Width{
    CGSize sizeToFit = [textView sizeThatFits:CGSizeMake(Width, MAXFLOAT)];
    return sizeToFit.height;
}
- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

@end
