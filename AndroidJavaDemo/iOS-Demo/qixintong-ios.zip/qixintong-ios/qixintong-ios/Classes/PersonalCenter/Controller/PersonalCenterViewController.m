//
//  PersonalCenterViewController.m
//  qixintong-ios
//
//  Created by buwen zhou on 2018/4/10.
//  Copyright © 2018年 dmooo. All rights reserved.
//

#import "PersonalCenterViewController.h"
#import "MessageViewController.h"
#import "InfoViewController.h"
#import "SetViewController.h"
#import "FeedBackViewController.h"
#import "ArticleViewController.h"
#import "ApplicationForLoanViewController.h"
#import <AVFoundation/AVCaptureDevice.h>
#import <AVFoundation/AVMediaFormat.h>
#import <Photos/Photos.h>

@interface PersonalCenterViewController ()<UINavigationControllerDelegate, UIImagePickerControllerDelegate>{
    UIButton *avatorButton;
    UILabel *nameLabel;
}

@end

@implementation PersonalCenterViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    [self initUI];
}
- (void)viewWillAppear:(BOOL)animated{
    [super viewWillAppear:YES];
    [self showTabBarView:YES];
    [self initData];
}
- (void)initData{
    if ([[NSUserDefaults standardUserDefaults] objectForKey:kToken] == nil || [[[NSUserDefaults standardUserDefaults] objectForKey:kToken] isKindOfClass:[NSNull class]] || [[NSString stringWithFormat:@"%@",[[NSUserDefaults standardUserDefaults] objectForKey:kToken]] isEqualToString:@""]) {
        [self showHUDTextOnly:@"登录失效，请重新登录"];
        [self.navigationController pushViewController:[LoginOrRegisterViewController new] animated:YES];
    }else{
        NSDictionary *parameters = @{
                                     @"token":[[NSUserDefaults standardUserDefaults] objectForKey:kToken]
                                     };
        [self defaultRequestwithURL:kUserCenterURL withParameters:parameters withMethod:kPOST withBlock:^(NSDictionary *dict, NSError *error) {
            if ([[NSString stringWithFormat:@"%@",[dict objectForKey:@"code"]] isEqualToString:@"0"]) {
                NSDictionary *userDetailDict = [[dict objectForKey:@"data"] objectForKey:@"userDetail"];
//                [avatorButton setImageWithURL:[NSURL URLWithString:[NSString stringWithFormat:@"%@%@",kBaseURL,userDetailDict[@"avatar"]]] placeholderImage:[UIImage imageNamed:@"Head_portrait"]];
                
                [avatorButton setImageForState:UIControlStateNormal withURL:[NSURL URLWithString:[NSString stringWithFormat:@"%@%@",kBaseURL,userDetailDict[@"avatar"]]] placeholderImage:[UIImage imageNamed:@"Head_portrait"]];
                if (userDetailDict[@"company"] == nil || [userDetailDict[@"company"] isKindOfClass:[NSNull class]] || [[NSString stringWithFormat:@"%@",userDetailDict[@"company"]] isEqualToString:@""]) {
                    nameLabel.text = [NSString stringWithFormat:@"%@",[[[dict objectForKey:@"data"] objectForKey:@"userMsg"] objectForKey:@"phone"]];
                }else{
                    nameLabel.text = [NSString stringWithFormat:@"%@",userDetailDict[@"company"]];
                }
                
            }else if ([[NSString stringWithFormat:@"%@",[dict objectForKey:@"code"]] isEqualToString:@"104"] || [[NSString stringWithFormat:@"%@",[dict objectForKey:@"code"]] isEqualToString:@"105"]){
                [self.navigationController pushViewController:[LoginOrRegisterViewController new] animated:YES];
            }else{
                [self showHUDTextOnly:dict[kMessage]];
            }
        }];
    }
}
- (void)initUI
{
    self.view.backgroundColor = RGB(239, 239, 239);
    [self customNavigationBarTitle:@"我的主页"];
    
    avatorButton = [[UIButton alloc] initWithFrame:CGRectMake(0, kHeaderHeight + 16 * kScreenHeightProportion, 50 * kScreenWidthProportion, 50 * kScreenWidthProportion)];
    [avatorButton setCornerRadius:25.f * kScreenWidthProportion];
    avatorButton.centerX = self.view.centerX;
    [avatorButton addTarget:self action:@selector(avatorButtonAction) forControlEvents:UIControlEventTouchUpInside];
    [self.view addSubview:avatorButton];
    
    nameLabel = [[UILabel alloc] initWithFrame:CGRectMake(0, avatorButton.maxY + 12 * kScreenHeightProportion, kScreenWidth, 14 * kScreenHeightProportion)];
    nameLabel.font = FONT(14 * kFontProportion);
    nameLabel.textAlignment = NSTextAlignmentCenter;
    [self.view addSubview:nameLabel];
    
    UIView *infoView = [[UIView alloc] initWithFrame:CGRectMake(6 * kScreenWidthProportion, nameLabel.maxY + 14 * kScreenHeightProportion, kScreenWidth - 12 * kScreenHeightProportion, 86 * kScreenHeightProportion)];
    [infoView setCornerRadius:8.f * kScreenHeightProportion];
    infoView.backgroundColor = [UIColor whiteColor];
    [infoView setBorder:1.f color:RGB(224, 224, 224)];
    [self.view addSubview:infoView];
    
    CGFloat width = (kScreenWidth - 30 * kScreenWidthProportion) / 3.0;
    
    UIButton *borrowButton = [[UIButton alloc] initWithFrame:CGRectMake(15 * kScreenWidthProportion, 0, width, infoView.height)];
    [borrowButton addTarget:self action:@selector(borrowButtonAction) forControlEvents:UIControlEventTouchUpInside];
    [infoView addSubview:borrowButton];
    
    UIImageView *borrowImgView = [[UIImageView alloc] initWithFrame:CGRectMake(0, 19 * kScreenHeightProportion, 24 * kScreenWidthProportion, 24 * kScreenHeightProportion)];
    borrowImgView.image = [UIImage imageNamed:@"mine_apply"];
    borrowImgView.centerX = borrowButton.width / 2.0;
    [borrowButton addSubview:borrowImgView];
    
    UILabel *borrowLabel = [[UILabel alloc] initWithFrame:CGRectMake(0, borrowImgView.maxY + 7 * kScreenHeightProportion, borrowButton.width, 12 * kScreenHeightProportion)];
    borrowLabel.font = FONT(11 * kFontProportion);
    borrowLabel.textAlignment = NSTextAlignmentCenter;
    borrowLabel.text = @"申请中借款";
    [borrowButton addSubview:borrowLabel];
    
    UIButton *msgButton = [[UIButton alloc] initWithFrame:CGRectMake(borrowButton.maxX, 0, width, infoView.height)];
    [msgButton addTarget:self action:@selector(msgButtonAction) forControlEvents:UIControlEventTouchUpInside];
    [infoView addSubview:msgButton];
    
    UIImageView *msgImgView = [[UIImageView alloc] initWithFrame:CGRectMake(0, 20 * kScreenHeightProportion, 20 * kScreenWidthProportion, 22 * kScreenHeightProportion)];
    msgImgView.image = [UIImage imageNamed:@"mine_clock"];
    msgImgView.centerX = msgButton.width / 2.0;
    [msgButton addSubview:msgImgView];
    
    UILabel *msgLabel = [[UILabel alloc] initWithFrame:CGRectMake(0, msgImgView.maxY + 8 * kScreenHeightProportion, msgButton.width, 12 * kScreenHeightProportion)];
    msgLabel.font = FONT(11 * kFontProportion);
    msgLabel.textAlignment = NSTextAlignmentCenter;
    msgLabel.text = @"我的消息";
    [msgButton addSubview:msgLabel];
    
    UIButton *myButton = [[UIButton alloc] initWithFrame:CGRectMake(msgButton.maxX, 0, width, infoView.height)];
    [myButton addTarget:self action:@selector(myButtonAction) forControlEvents:UIControlEventTouchUpInside];
    [infoView addSubview:myButton];
    
    UIImageView *myImgView = [[UIImageView alloc] initWithFrame:CGRectMake(0, 19 * kScreenHeightProportion, 28 * kScreenWidthProportion, 20 * kScreenHeightProportion)];
    myImgView.image = [UIImage imageNamed:@"mine_data"];
    myImgView.centerX = myButton.width / 2.0;
    [myButton addSubview:myImgView];
    
    UILabel *myLabel = [[UILabel alloc] initWithFrame:CGRectMake(0, myImgView.maxY + 9 * kScreenHeightProportion, myButton.width, 12 * kScreenHeightProportion)];
    myLabel.font = FONT(11 * kFontProportion);
    myLabel.textAlignment = NSTextAlignmentCenter;
    myLabel.text = @"我的资料";
    [myButton addSubview:myLabel];
    
    UIView *setView = [[UIView alloc] initWithFrame:CGRectMake(6 * kScreenWidthProportion, infoView.maxY + 8 * kScreenHeightProportion, kScreenWidth - 12 * kScreenHeightProportion, 48 * 3 * kScreenHeightProportion)];
    [setView setCornerRadius:8.f * kScreenHeightProportion];
    setView.backgroundColor = [UIColor whiteColor];
    [setView setBorder:1.f color:RGB(224, 224, 224)];
    [self.view addSubview:setView];
    
    NSArray *leftArray = @[@"mine_set",@"mine_feedback",@"mine_about"];
    NSArray *titleArray = @[@"设置",@"意见反馈",@"关于我们"];
    for (int i = 0; i < 3; i ++) {
        UIButton *funButton = [[UIButton alloc] initWithFrame:CGRectMake(0, 48 * kScreenHeightProportion * i, setView.width, 48 * kScreenHeightProportion)];
        [funButton addTarget:self action:@selector(funButtonAction:) forControlEvents:UIControlEventTouchUpInside];
        [setView addSubview:funButton];
        funButton.tag = kTagStart + i;
        
        UIImageView *leftImgView = [[UIImageView alloc] initWithFrame:CGRectMake(15 * kScreenWidthProportion, 0, 25 * kScreenWidthProportion, 22 * kScreenHeightProportion)];
        leftImgView.image = [UIImage imageNamed:leftArray[i]];
        [funButton addSubview:leftImgView];
        
        if (i == 0 || i == 2) {
            leftImgView.width = 24 * kScreenWidthProportion;
            leftImgView.height = 24 * kScreenWidthProportion;
        }
        
        UILabel *titleLabel = [[UILabel alloc] initWithFrame:CGRectMake(leftImgView.maxX + 6 * kScreenWidthProportion, 0, 120 * kScreenWidthProportion, 48 * kScreenHeightProportion)];
        titleLabel.font = FONT(12 * kFontProportion);
        titleLabel.text = titleArray[i];
        [funButton addSubview:titleLabel];
        leftImgView.centerY = titleLabel.centerY;
        
        UIImageView *rightImgView = [[UIImageView alloc] initWithFrame:CGRectMake(0, 0, 7 * kScreenWidthProportion, 13 * kScreenHeightProportion)];
        rightImgView.image = [UIImage imageNamed:@"gray_back"];
        rightImgView.maxX = funButton.width - 14 * kScreenWidthProportion;
        rightImgView.centerY = titleLabel.centerY;
        [funButton addSubview:rightImgView];
        
        UIView *lineView = [[UIView alloc] initWithFrame:CGRectMake(8 * kScreenWidthProportion, titleLabel.maxY - 1 * kScreenHeightProportion, setView.width - 16 * kScreenWidthProportion, 1 * kScreenHeightProportion)];
        lineView.backgroundColor = kGrayBackgroundColor;
        [funButton addSubview:lineView];
    }
}
- (void)funButtonAction:(UIButton *)sender{
    switch (sender.tag - kTagStart) {
        case 0:
        {
            [self showTabBarView:NO];
            [self.navigationController pushViewController:[SetViewController new] animated:YES];
        }
            break;
        case 1:
        {
            [self showTabBarView:NO];
            [self.navigationController pushViewController:[FeedBackViewController new] animated:YES];
        }
            break;
        case 2:
        {
            [self showTabBarView:NO];
            ArticleViewController *arVC = [[ArticleViewController alloc] init];
            arVC.articleIdStr = @"1";
            arVC.titleStr = @"关于我们";
            [self.navigationController pushViewController:arVC animated:YES];
        }
            break;
            
        default:
            break;
    }
}
#pragma mark - 申请中借款
- (void)borrowButtonAction{
    [self showTabBarView:NO];
    [self.navigationController pushViewController:[ApplicationForLoanViewController new] animated:YES];
}
#pragma mark - 我的消息
- (void)msgButtonAction{
    [self showTabBarView:NO];
    [self.navigationController pushViewController:[MessageViewController new] animated:YES];
}
#pragma mark - 我的资料
- (void)myButtonAction{
    [self showTabBarView:NO];
    InfoViewController *infoVC = [[InfoViewController alloc] init];
    [self.navigationController pushViewController:infoVC animated:YES];
}

#pragma mark - 头像
- (void)avatorButtonAction{
    UIAlertController *alert = [UIAlertController
                                alertControllerWithTitle:nil
                                message:nil
                                preferredStyle:UIAlertControllerStyleActionSheet];
    
    [alert addAction:[UIAlertAction actionWithTitle:@"拍照" style:UIAlertActionStyleDefault handler:^(UIAlertAction *action) {
        AVAuthorizationStatus status = [AVCaptureDevice authorizationStatusForMediaType:AVMediaTypeVideo];
        if (status == AVAuthorizationStatusRestricted || status == AVAuthorizationStatusDenied){
            // 无权限
            UIAlertView * alart = [[UIAlertView alloc]initWithTitle:@"温馨提示" message:@"请您设置允许该应用访问您的相机\n设置>隐私>相机" delegate:self cancelButtonTitle:@"确定" otherButtonTitles:nil, nil];
            [alart show];
            return;
        }
        
        [AVCaptureDevice requestAccessForMediaType:AVMediaTypeVideo completionHandler:^(BOOL granted) {//相机权限
            if (granted) {
                NSLog(@"Authorized");
                // Hide the keyboard
                [self takePhoto];
            }else{
                NSLog(@"Denied or Restricted");
            }
        }];
        
    }]];
    
    [alert addAction:[UIAlertAction actionWithTitle:@"取消" style:UIAlertActionStyleCancel handler:^(UIAlertAction *action) {}]];
    
    [alert addAction:[UIAlertAction actionWithTitle:@"从相册中选择" style:UIAlertActionStyleDefault handler:^(UIAlertAction *action) {
        //----第一次不会进来
        PHAuthorizationStatus status = [PHPhotoLibrary authorizationStatus];
        if (status == PHAuthorizationStatusRestricted || status == PHAuthorizationStatusDenied){
            // 无权限 做一个友好的提示
            UIAlertView * alart = [[UIAlertView alloc]initWithTitle:@"温馨提示" message:@"请您设置允许该应用访问您的相册\n设置>隐私>照片" delegate:self cancelButtonTitle:@"确定" otherButtonTitles:nil, nil];
            [alart show];
            return;
        }
        
        //----每次都会走进来
        [PHPhotoLibrary requestAuthorization:^(PHAuthorizationStatus status) {
            if (status == PHAuthorizationStatusAuthorized) {
                NSLog(@"Authorized");
                [self LocalPhoto];
            }else if (status == PHAuthorizationStatusDenied) {
                NSLog(@"用户拒绝当前应用访问相册,我们需要提醒用户打开访问开关");
            }else{
                NSLog(@"其他原因");
            }
        }];
        
    }]];
    
    [self presentViewController:alert animated:YES completion:nil];
}
//从相册选择
-(void)LocalPhoto{
    UIImagePickerController *picker = [[UIImagePickerController alloc] init];
    //资源类型为图片库
    picker.sourceType = UIImagePickerControllerSourceTypePhotoLibrary;
    picker.delegate = self;
    //设置选择后的图片可被编辑
    //    picker.allowsEditing = YES;
    //    [[XGetCurrentInfo getCurrentVC] presentViewController:picker animated:YES completion:nil];
    [[[[UIApplication sharedApplication]delegate]window].rootViewController presentViewController:picker animated:YES completion:nil];
}

//拍照
-(void)takePhoto{
    //资源类型为照相机
    UIImagePickerControllerSourceType sourceType = UIImagePickerControllerSourceTypeCamera;
    //判断是否有相机
    if ([UIImagePickerController isSourceTypeAvailable: UIImagePickerControllerSourceTypeCamera]){
        UIImagePickerController *picker = [[UIImagePickerController alloc] init];
        picker.delegate = self;
        //设置拍照后的图片可被编辑
        //        picker.allowsEditing = YES;
        //资源类型为照相机
        picker.sourceType = sourceType;
        //        [[XGetCurrentInfo getCurrentVC] presentViewController:picker animated:YES completion:^{}];
        [[[[UIApplication sharedApplication]delegate]window].rootViewController presentViewController:picker animated:YES completion:nil];
    }else {
        //        NSLog(@"该设备无摄像头");
    }
}
#pragma Delegate method UIImagePickerControllerDelegate
//图像选取器的委托方法，选完图片后回调该方法
- (void)imagePickerController:(UIImagePickerController *)picker didFinishPickingImage:(UIImage *)image editingInfo:(NSDictionary *)editingInfo{
    NSDictionary *parameters = @{
                                 @"token":[[NSUserDefaults standardUserDefaults] objectForKey:kToken]
                                 };
    [self startMultiPartUploadTaskWithURL:kEditUserAvatarURL imagesArray:@[image] parameterOfimages:@"user_avatar" parametersDict:parameters compressionRatio:0.5 succeedBlock:^(NSDictionary *dict) {
        NSLog(@"qwer %@",dict);
        if ([[NSString stringWithFormat:@"%@",[dict objectForKey:@"code"]] isEqualToString:@"0"])  {
            [avatorButton setImage:image forState:UIControlStateNormal];
            [self showHUDTextOnly:dict[kMessage]];
        }else if ([[NSString stringWithFormat:@"%@",[dict objectForKey:@"code"]] isEqualToString:@"104"]){
            [self.navigationController pushViewController:[LoginOrRegisterViewController new] animated:YES];
        }else{
            [self showHUDTextOnly:dict[kMessage]];
        }
        
    } failedBlock:^(NSError *error) {
        
    }];
    
    //关闭相册界面
    [picker dismissViewControllerAnimated:YES completion:nil];
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

@end
