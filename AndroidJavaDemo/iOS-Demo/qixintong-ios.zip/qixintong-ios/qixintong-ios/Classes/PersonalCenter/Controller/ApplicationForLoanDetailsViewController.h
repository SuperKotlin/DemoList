//
//  ApplicationForLoanDetailsViewController.h
//  qixintong-ios
//
//  Created by buwen zhou on 2018/4/25.
//  Copyright © 2018年 dmooo. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface ApplicationForLoanDetailsViewController : UIViewController
@property (nonatomic,strong) NSString *productApplyIdStr;
//1初审中  4复审中  5到账成功
@property (nonatomic,strong) NSString *typeStr;

@end
