//
//  EditPwdViewController.m
//  qixintong-ios
//
//  Created by buwen zhou on 2018/4/24.
//  Copyright © 2018年 dmooo. All rights reserved.
//

#import "EditPwdViewController.h"

@interface EditPwdViewController (){
    UITextField *oldTextField;
    UITextField *newTextField;
    UITextField *newTextField2;
}

@end

@implementation EditPwdViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    [self initUI];
}
- (void)initUI
{
    self.view.backgroundColor = kGrayBackgroundColor;
    [self customNavigationBar:@"修改密码"];
 
    UIView *setView = [[UIView alloc] initWithFrame:CGRectMake(6 * kScreenWidthProportion, kHeaderHeight + 13 * kScreenHeightProportion, kScreenWidth - 12 * kScreenHeightProportion, 48 * 3 * kScreenHeightProportion)];
    [setView setCornerRadius:8.f * kScreenHeightProportion];
    setView.backgroundColor = [UIColor whiteColor];
    [self.view addSubview:setView];
    
    NSArray *titleArray = @[@"原密码",@"新密码",@"重复新密码"];
    for (int i = 0; i < 3; i ++) {
        UILabel *titleLabel = [[UILabel alloc] initWithFrame:CGRectMake(8 * kScreenWidthProportion,48 * kScreenHeightProportion * i, 100 * kScreenWidthProportion, 48 * kScreenHeightProportion)];
        titleLabel.font = FONT(12 * kFontProportion);
        titleLabel.text = titleArray[i];
        [setView addSubview:titleLabel];
        
        UIView *lineView = [[UIView alloc] initWithFrame:CGRectMake(8 * kScreenWidthProportion, titleLabel.maxY - 1 * kScreenHeightProportion, setView.width - 16 * kScreenWidthProportion, 1 * kScreenHeightProportion)];
        lineView.backgroundColor = kGrayBackgroundColor;
        [setView addSubview:lineView];
    }
    
    oldTextField = [[UITextField alloc] initWithFrame:CGRectMake(108 * kScreenWidthProportion, 0, setView.width - 116 * kScreenWidthProportion, 48 * kScreenHeightProportion)];
    oldTextField.font = FONT(13 * kFontProportion);
    oldTextField.placeholder = @"请输入原密码";
    oldTextField.textAlignment = NSTextAlignmentRight;
    [oldTextField setSecureTextEntry:YES];
    [setView addSubview:oldTextField];
    
    newTextField = [[UITextField alloc] initWithFrame:CGRectMake(oldTextField.minX, oldTextField.maxY, oldTextField.width, oldTextField.height)];
    newTextField.font = FONT(13 * kFontProportion);
    newTextField.placeholder = @"请输入新密码";
    newTextField.textAlignment = NSTextAlignmentRight;
    [newTextField setSecureTextEntry:YES];
    [setView addSubview:newTextField];
    
    newTextField2 = [[UITextField alloc] initWithFrame:CGRectMake(oldTextField.minX, newTextField.maxY, oldTextField.width, oldTextField.height)];
    newTextField2.font = FONT(13 * kFontProportion);
    newTextField2.placeholder = @"请输入确认密码";
    newTextField2.textAlignment = NSTextAlignmentRight;
    [newTextField2 setSecureTextEntry:YES];
    [setView addSubview:newTextField2];
    
    UIButton *loginButton = [[UIButton alloc] initWithFrame:CGRectMake(50 * kScreenWidthProportion, setView.maxY + 35 * kScreenHeightProportion, kScreenWidth - 100 * kScreenWidthProportion, 34 * kScreenHeightProportion)];
    [loginButton setTitle:@"确认" forState:UIControlStateNormal];
    [loginButton setTitleColor:[UIColor whiteColor] forState:UIControlStateNormal];
    loginButton.titleLabel.font = FONT(16 * kFontProportion);
    loginButton.backgroundColor = kDefaultColor;
    [loginButton setCornerRadius:15.f * kScreenHeightProportion];
    [loginButton addTarget:self action:@selector(loginButtonAction) forControlEvents:UIControlEventTouchUpInside];
    [self.view addSubview:loginButton];
    
}
- (BOOL)VerificationPassWord:(NSString*)carNo
{
    NSString *carRegex = @"[A-Za-z_0-9]{6,12}";
    NSPredicate *carTest = [NSPredicate predicateWithFormat:@"SELF MATCHES %@",carRegex];
    NSLog(@"carTest is %@",carTest);
    return [carTest evaluateWithObject:carNo];
}
#pragma mark - 确认
- (void)loginButtonAction{
    [self.view endEditing:YES];
    
    if ([oldTextField.text isEqualToString:@""]) {
        [self showHUDTextOnly:@"请输入原密码"];
        return;
    }
    
    if ([newTextField.text isEqualToString:@""]) {
        [self showHUDTextOnly:@"请输入新密码"];
        return;
    }
    
    if ([newTextField2.text isEqualToString:@""]) {
        [self showHUDTextOnly:@"请输入确认密码"];
        return;
    }
    
    if (![newTextField2.text isEqualToString:newTextField.text]) {
        [self showHUDTextOnly:@"两次密码不一致"];
        return;
    }
    
    NSDictionary *parameters = @{
                                 @"token":[[NSUserDefaults standardUserDefaults] objectForKey:kToken],
                                 @"oldpwd":oldTextField.text,
                                 @"pwd1":newTextField.text,
                                 @"pwd2":newTextField2.text
                                 };
    [self defaultRequestwithURL:kChangePwdURL withParameters:parameters withMethod:kPOST withBlock:^(NSDictionary *dict, NSError *error) {
        if ([[NSString stringWithFormat:@"%@",[dict objectForKey:@"code"]] isEqualToString:@"0"]) {
            [self showHUDTextOnly:dict[kMessage]];
            LoginOrRegisterViewController *loginVC = [[LoginOrRegisterViewController alloc] init];
            loginVC.typeStr = @"1";
            [self.navigationController pushViewController:loginVC animated:YES];
        }else if ([[NSString stringWithFormat:@"%@",[dict objectForKey:@"code"]] isEqualToString:@"104"]){
            [self.navigationController pushViewController:[LoginOrRegisterViewController new] animated:YES];
        }else{
            [self showHUDTextOnly:dict[kMessage]];
        }
    }];
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

@end
