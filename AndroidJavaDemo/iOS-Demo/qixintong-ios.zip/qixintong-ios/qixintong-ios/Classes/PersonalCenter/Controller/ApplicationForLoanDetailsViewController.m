//
//  ApplicationForLoanDetailsViewController.m
//  qixintong-ios
//
//  Created by buwen zhou on 2018/4/25.
//  Copyright © 2018年 dmooo. All rights reserved.
//

#import "ApplicationForLoanDetailsViewController.h"

@interface ApplicationForLoanDetailsViewController (){
    UILabel *priceLabel;
    UILabel *timeLabel1,*timeLabel2,*timeLabel3,*timeLabel4,*timeLabel5;
}

@end

@implementation ApplicationForLoanDetailsViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    [self initUI];
    [self initData];
}
- (void)initData{
    NSDictionary *parameters = @{
                                 @"token":[[NSUserDefaults standardUserDefaults] objectForKey:kToken],
                                 @"product_apply_id":self.productApplyIdStr
                                 };
    [self defaultRequestwithURL:kGetApplyMsgURL withParameters:parameters withMethod:kPOST withBlock:^(NSDictionary *dict, NSError *error) {
        if ([[NSString stringWithFormat:@"%@",[dict objectForKey:@"code"]] isEqualToString:@"0"]) {
            NSDictionary *applyMegDict = [[dict objectForKey:@"data"] objectForKey:@"applyMsg"];
            priceLabel.text = [NSString stringWithFormat:@"%@万",applyMegDict[@"money"]];
            if ([[NSString stringWithFormat:@"%@",applyMegDict[@"apply_time"]] isEqualToString:@""]) {
                timeLabel1.text = @"";
                timeLabel2.text = @"";
            }else{
                timeLabel1.text = [NSString stringWithFormat:@"%@",[[NSString stringWithFormat:@"%@",applyMegDict[@"apply_time"]] substringWithRange:NSMakeRange(0, 10)]];
                timeLabel2.text = [NSString stringWithFormat:@"%@",[[NSString stringWithFormat:@"%@",applyMegDict[@"apply_time"]] substringWithRange:NSMakeRange(0, 10)]];
            }
            
            if ([[NSString stringWithFormat:@"%@",applyMegDict[@"check_time"]] isEqualToString:@""]) {
                timeLabel3.text = @"";
            }else{
                timeLabel3.text = [NSString stringWithFormat:@"%@",[[NSString stringWithFormat:@"%@",applyMegDict[@"check_time"]] substringWithRange:NSMakeRange(0, 10)]];
            }
            
            if ([[NSString stringWithFormat:@"%@",applyMegDict[@"reapply_time"]] isEqualToString:@""]) {
                timeLabel4.text = @"";
            }else{
                timeLabel4.text = [NSString stringWithFormat:@"%@",[[NSString stringWithFormat:@"%@",applyMegDict[@"reapply_time"]] substringWithRange:NSMakeRange(0, 10)]];
            }
            
            if ([[NSString stringWithFormat:@"%@",applyMegDict[@"check_time2"]] isEqualToString:@""]) {
                timeLabel5.text = @"";
            }else{
                timeLabel5.text = [NSString stringWithFormat:@"%@",[[NSString stringWithFormat:@"%@",applyMegDict[@"check_time2"]] substringWithRange:NSMakeRange(0, 10)]];
            }
            
        }else if ([[NSString stringWithFormat:@"%@",[dict objectForKey:@"code"]] isEqualToString:@"104"]){
            [self.navigationController pushViewController:[LoginOrRegisterViewController new] animated:YES];
        }else{
            [self showHUDTextOnly:dict[kMessage]];
        }
    }];
}
- (void)initUI
{
    self.view.backgroundColor = [UIColor whiteColor];
    [self customNavigationBar:@"借款详情"];
 
    UILabel *titleLabel = [[UILabel alloc] initWithFrame:CGRectMake(0, kHeaderHeight + 24 * kScreenHeightProportion, kScreenWidth, 16 * kScreenHeightProportion)];
    titleLabel.font = FONT(15 * kFontProportion);
    titleLabel.textAlignment = NSTextAlignmentCenter;
    titleLabel.text = @"金额(元)";
    [self.view addSubview:titleLabel];
    
    priceLabel = [[UILabel alloc] initWithFrame:CGRectMake(0,titleLabel.maxY + 24 * kScreenHeightProportion, kScreenWidth, 24 * kScreenHeightProportion)];
    priceLabel.font = FONT(24 * kFontProportion);
    priceLabel.textAlignment = NSTextAlignmentCenter;
    priceLabel.textColor = [UIColor redColor];
    [self.view addSubview:priceLabel];
    
    UILabel *loginLabel = [[UILabel alloc] initWithFrame:CGRectMake(0, priceLabel.maxY + 14 * kScreenHeightProportion, 130 * kScreenWidthProportion, 13 * kScreenHeightProportion)];
    loginLabel.text = @"处理中";
    loginLabel.textColor = kGrayLabelColor;
    loginLabel.font = FONT(12 * kFontProportion);
    loginLabel.textAlignment = NSTextAlignmentCenter;
    [self.view addSubview:loginLabel];
    
    CGFloat agreeGrayWidth = [loginLabel getTitleTextWidth:loginLabel.text font:FONT(12 * kFontProportion)];
    loginLabel.width = agreeGrayWidth + 4;
    loginLabel.centerX = self.view.centerX;
    
    UIView *lineViewq = [[UIView alloc] initWithFrame:CGRectMake(0, 0, 28 * kScreenWidthProportion, 1 * kScreenHeightProportion)];
    lineViewq.backgroundColor = RGB(232, 233, 232);
    lineViewq.centerY = loginLabel.centerY;
    lineViewq.maxX = loginLabel.minX - 5 * kScreenWidthProportion;
    [self.view addSubview:lineViewq];
    
    UIView *lineVieww = [[UIView alloc] initWithFrame:CGRectMake(loginLabel.maxX + 5 * kScreenWidthProportion, 0, lineViewq.width, 1 * kScreenHeightProportion)];
    lineVieww.backgroundColor = RGB(232, 233, 232);
    lineVieww.centerY = loginLabel.centerY;
    [self.view addSubview:lineVieww];
    
    UILabel *jinduLabel = [[UILabel alloc] initWithFrame:CGRectMake(30 * kScreenWidthProportion, loginLabel.maxY + 33 * kScreenHeightProportion, 60 * kScreenWidthProportion, 22 * kScreenHeightProportion)];
    jinduLabel.font = FONT(13 * kFontProportion);
    jinduLabel.text = @"目前进度";
    [self.view addSubview:jinduLabel];
    
    UIImageView *oneImgView = [[UIImageView alloc] initWithFrame:CGRectMake(jinduLabel.maxX, jinduLabel.minY, 16 * kScreenWidthProportion, 16 * kScreenWidthProportion)];
    oneImgView.image = [UIImage imageNamed:@"borrow_through"];
    [self.view addSubview:oneImgView];
    
    UILabel *oneLabel = [[UILabel alloc] initWithFrame:CGRectMake(oneImgView.maxX + 4 * kScreenWidthProportion, 0, 100 * kScreenWidthProportion, 11 * kScreenHeightProportion)];
    oneLabel.font = FONT(11 * kFontProportion);
    oneLabel.textColor = [UIColor redColor];
    oneLabel.centerY = oneImgView.centerY;
    oneLabel.text = @"提交申请";
    [self.view addSubview:oneLabel];
    
    timeLabel1 = [[UILabel alloc] initWithFrame:CGRectMake(0, 0, 100 * kScreenWidthProportion, 11 * kScreenHeightProportion)];
    timeLabel1.font = FONT(11 * kFontProportion);
    timeLabel1.centerY = oneLabel.centerY;
    timeLabel1.textColor = kGrayLabelColor;
    timeLabel1.maxX = kScreenWidth - 15 * kScreenWidthProportion;
    timeLabel1.textAlignment = NSTextAlignmentRight;
    [self.view addSubview:timeLabel1];
    
    UILabel *oneGrayLabel = [[UILabel alloc] initWithFrame:CGRectMake(oneLabel.minX, oneLabel.maxY + 8 * kScreenHeightProportion, kScreenWidth - oneImgView.maxX, 11 * kScreenHeightProportion)];
    oneGrayLabel.textColor = kGrayLabelColor;
    oneGrayLabel.font = FONT(10 * kFontProportion);
    oneGrayLabel.text = @"您申请已经提交，等待工作人员初审";
    [self.view addSubview:oneGrayLabel];
    
    UIView *lineView1 = [[UIView alloc] initWithFrame:CGRectMake(0, oneImgView.maxY, 1 * kScreenWidthProportion, 40 * kScreenHeightProportion)];
    lineView1.backgroundColor = [UIColor redColor];
    lineView1.centerX = oneImgView.centerX;
    [self.view addSubview:lineView1];
    
    //2
    UIImageView *twoImgView = [[UIImageView alloc] initWithFrame:CGRectMake(jinduLabel.maxX, lineView1.maxY, 16 * kScreenWidthProportion, 16 * kScreenWidthProportion)];
    twoImgView.image = [UIImage imageNamed:@"borrow_wait"];
    [self.view addSubview:twoImgView];
    
    UILabel *twoLabel = [[UILabel alloc] initWithFrame:CGRectMake(twoImgView.maxX + 4 * kScreenWidthProportion, 0, 100 * kScreenWidthProportion, 11 * kScreenHeightProportion)];
    twoLabel.font = FONT(11 * kFontProportion);
    twoLabel.textColor = [UIColor redColor];
    twoLabel.centerY = twoImgView.centerY;
    twoLabel.text = @"初审中";
    [self.view addSubview:twoLabel];
    
    timeLabel2 = [[UILabel alloc] initWithFrame:CGRectMake(0, 0, 100 * kScreenWidthProportion, 11 * kScreenHeightProportion)];
    timeLabel2.font = FONT(11 * kFontProportion);
    timeLabel2.centerY = twoLabel.centerY;
    timeLabel2.textColor = kGrayLabelColor;
    timeLabel2.maxX = kScreenWidth - 15 * kScreenWidthProportion;
    timeLabel2.textAlignment = NSTextAlignmentRight;
    [self.view addSubview:timeLabel2];
    
    UILabel *twoGrayLabel = [[UILabel alloc] initWithFrame:CGRectMake(twoLabel.minX, twoLabel.maxY + 8 * kScreenHeightProportion, kScreenWidth - oneImgView.maxX, 11 * kScreenHeightProportion)];
    twoGrayLabel.textColor = kGrayLabelColor;
    twoGrayLabel.font = FONT(10 * kFontProportion);
    twoGrayLabel.text = @"您的申请正在审核中，请及时关注";
    [self.view addSubview:twoGrayLabel];
    
    UIView *lineView2 = [[UIView alloc] initWithFrame:CGRectMake(0, twoImgView.maxY, 1 * kScreenWidthProportion, 40 * kScreenHeightProportion)];
    lineView2.backgroundColor = [UIColor redColor];
    lineView2.centerX = twoImgView.centerX;
    [self.view addSubview:lineView2];
    
    //3
    UIImageView *threeImgView = [[UIImageView alloc] initWithFrame:CGRectMake(jinduLabel.maxX, lineView2.maxY, 16 * kScreenWidthProportion, 16 * kScreenWidthProportion)];
    threeImgView.image = [UIImage imageNamed:@"borrow_through"];
    [self.view addSubview:threeImgView];
    
    UILabel *threeLabel = [[UILabel alloc] initWithFrame:CGRectMake(threeImgView.maxX + 4 * kScreenWidthProportion, 0, 100 * kScreenWidthProportion, 11 * kScreenHeightProportion)];
    threeLabel.font = FONT(11 * kFontProportion);
    threeLabel.textColor = [UIColor redColor];
    threeLabel.centerY = threeImgView.centerY;
    threeLabel.text = @"初审通过";
    [self.view addSubview:threeLabel];
    
    timeLabel3 = [[UILabel alloc] initWithFrame:CGRectMake(0, 0, 100 * kScreenWidthProportion, 11 * kScreenHeightProportion)];
    timeLabel3.font = FONT(11 * kFontProportion);
    timeLabel3.centerY = threeLabel.centerY;
    timeLabel3.textColor = kGrayLabelColor;
    timeLabel3.maxX = kScreenWidth - 15 * kScreenWidthProportion;
    timeLabel3.textAlignment = NSTextAlignmentRight;
    [self.view addSubview:timeLabel3];
    
    UIView *lineView3 = [[UIView alloc] initWithFrame:CGRectMake(0, threeImgView.maxY, 1 * kScreenWidthProportion, 37 * kScreenHeightProportion)];
    lineView3.backgroundColor = [UIColor redColor];
    lineView3.centerX = threeImgView.centerX;
    [self.view addSubview:lineView3];
    
    //4
    UIImageView *fourImgView = [[UIImageView alloc] initWithFrame:CGRectMake(jinduLabel.maxX, lineView3.maxY, 16 * kScreenWidthProportion, 16 * kScreenWidthProportion)];
    fourImgView.image = [UIImage imageNamed:@"borrow_upload"];
    [self.view addSubview:fourImgView];
    
    UILabel *fourLabel = [[UILabel alloc] initWithFrame:CGRectMake(fourImgView.maxX + 4 * kScreenWidthProportion, 0, 100 * kScreenWidthProportion, 11 * kScreenHeightProportion)];
    fourLabel.font = FONT(11 * kFontProportion);
    fourLabel.textColor = [UIColor redColor];
    fourLabel.centerY = fourImgView.centerY;
    fourLabel.text = @"上传证件";
    [self.view addSubview:fourLabel];
    
    timeLabel4 = [[UILabel alloc] initWithFrame:CGRectMake(0, 0, 100 * kScreenWidthProportion, 11 * kScreenHeightProportion)];
    timeLabel4.font = FONT(11 * kFontProportion);
    timeLabel4.centerY = fourLabel.centerY;
    timeLabel4.textColor = kGrayLabelColor;
    timeLabel4.maxX = kScreenWidth - 15 * kScreenWidthProportion;
    timeLabel4.textAlignment = NSTextAlignmentRight;
    [self.view addSubview:timeLabel4];
    
    UILabel *fourGrayLabel = [[UILabel alloc] initWithFrame:CGRectMake(fourLabel.minX, fourLabel.maxY + 8 * kScreenHeightProportion, kScreenWidth - oneImgView.maxX, 30 * kScreenHeightProportion)];
    fourGrayLabel.textColor = kGrayLabelColor;
    fourGrayLabel.font = FONT(10 * kFontProportion);
    fourGrayLabel.numberOfLines = 0;
    fourGrayLabel.text = @"您的借贷证件已经上传，经查验工\n作人员会与您取得联系";
    [self.view addSubview:fourGrayLabel];
    
    UIView *lineView4 = [[UIView alloc] initWithFrame:CGRectMake(0, fourImgView.maxY, 1 * kScreenWidthProportion, 54 * kScreenHeightProportion)];
    lineView4.backgroundColor = [UIColor redColor];
    lineView4.centerX = twoImgView.centerX;
    [self.view addSubview:lineView4];
    
    //5
    UIImageView *fiveImgView = [[UIImageView alloc] initWithFrame:CGRectMake(jinduLabel.maxX, lineView4.maxY, 16 * kScreenWidthProportion, 16 * kScreenWidthProportion)];
    fiveImgView.image = [UIImage imageNamed:@"borrow_redmoney"];
    [self.view addSubview:fiveImgView];
    
    UILabel *fiveLabel = [[UILabel alloc] initWithFrame:CGRectMake(fiveImgView.maxX + 4 * kScreenWidthProportion, 0, 100 * kScreenWidthProportion, 11 * kScreenHeightProportion)];
    fiveLabel.font = FONT(11 * kFontProportion);
    fiveLabel.textColor = [UIColor redColor];
    fiveLabel.centerY = fiveImgView.centerY;
    fiveLabel.text = @"到账成功";
    [self.view addSubview:fiveLabel];
    
    timeLabel5 = [[UILabel alloc] initWithFrame:CGRectMake(0, 0, 100 * kScreenWidthProportion, 11 * kScreenHeightProportion)];
    timeLabel5.font = FONT(11 * kFontProportion);
    timeLabel5.centerY = fiveLabel.centerY;
    timeLabel5.textColor = kGrayLabelColor;
    timeLabel5.maxX = kScreenWidth - 15 * kScreenWidthProportion;
    timeLabel5.textAlignment = NSTextAlignmentRight;
    [self.view addSubview:timeLabel5];
    
    //1初审中  4复审中  5到账成功
    if ([self.typeStr isEqualToString:@"1"]) {
        threeLabel.textColor = kGrayLabelColor;
        fourLabel.textColor = kGrayLabelColor;
        fiveLabel.textColor = kGrayLabelColor;
        
        threeImgView.image = [UIImage imageNamed:@"gary_apply"];
        fourImgView.image = [UIImage imageNamed:@"gary_upload"];
        fiveImgView.image = [UIImage imageNamed:@"gary_through"];
        
        lineView3.backgroundColor = kGrayLabelColor;
        lineView4.backgroundColor = kGrayLabelColor;
        
        fourGrayLabel.text = @"";
        
    }else if ([self.typeStr isEqualToString:@"4"]){
        fiveLabel.textColor = kGrayLabelColor;
        fiveImgView.image = [UIImage imageNamed:@"gary_through"];
    }else{
        
    }
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

@end
