//
//  SetViewController.m
//  qixintong-ios
//
//  Created by buwen zhou on 2018/4/24.
//  Copyright © 2018年 dmooo. All rights reserved.
//

#import "SetViewController.h"
#import "EditPwdViewController.h"

@interface SetViewController ()

@end

@implementation SetViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    [self initUI];
}
- (void)initUI
{
    self.view.backgroundColor = kGrayBackgroundColor;
    [self customNavigationBar:@"设置"];
    
    UIView *setView = [[UIView alloc] initWithFrame:CGRectMake(6 * kScreenWidthProportion, kHeaderHeight + 12 * kScreenHeightProportion, kScreenWidth - 12 * kScreenHeightProportion, 48 * 2 * kScreenHeightProportion)];
    [setView setCornerRadius:8.f * kScreenHeightProportion];
    setView.backgroundColor = [UIColor whiteColor];
    [setView setBorder:1.f color:RGB(224, 224, 224)];
    [self.view addSubview:setView];
    
    NSArray *leftArray = @[@"mine_password",@"mine_cancellation"];
    NSArray *titleArray = @[@"修改密码",@"退出登录"];
    for (int i = 0; i < 2; i ++) {
        UIButton *funButton = [[UIButton alloc] initWithFrame:CGRectMake(0, 48 * kScreenHeightProportion * i, setView.width, 48 * kScreenHeightProportion)];
        [funButton addTarget:self action:@selector(funButtonAction:) forControlEvents:UIControlEventTouchUpInside];
        [setView addSubview:funButton];
        funButton.tag = kTagStart + i;
        
        UIImageView *leftImgView = [[UIImageView alloc] initWithFrame:CGRectMake(15 * kScreenWidthProportion, 0, 18 * kScreenWidthProportion, 20 * kScreenHeightProportion)];
        leftImgView.image = [UIImage imageNamed:leftArray[i]];
        [funButton addSubview:leftImgView];
        
        if (i == 1) {
            leftImgView.width = 16 * kScreenWidthProportion;
            leftImgView.height = 16 * kScreenWidthProportion;
        }
        
        UILabel *titleLabel = [[UILabel alloc] initWithFrame:CGRectMake(leftImgView.maxX + 6 * kScreenWidthProportion, 0, 120 * kScreenWidthProportion, 48 * kScreenHeightProportion)];
        titleLabel.font = FONT(12 * kFontProportion);
        titleLabel.text = titleArray[i];
        [funButton addSubview:titleLabel];
        leftImgView.centerY = titleLabel.centerY;
        
        UIView *lineView = [[UIView alloc] initWithFrame:CGRectMake(8 * kScreenWidthProportion, titleLabel.maxY - 1 * kScreenHeightProportion, setView.width - 16 * kScreenWidthProportion, 1 * kScreenHeightProportion)];
        lineView.backgroundColor = kGrayBackgroundColor;
        [funButton addSubview:lineView];
    }
}
- (void)funButtonAction:(UIButton *)sender{
    switch (sender.tag - kTagStart) {
        case 0:
        {
            [self.navigationController pushViewController:[EditPwdViewController new] animated:YES];
        }
            break;
        case 1:
        {
            NSDictionary *parameters = @{
                                         @"token":[[NSUserDefaults standardUserDefaults] objectForKey:kToken]
                                         };
            [self defaultRequestwithURL:kExitURL withParameters:parameters withMethod:kPOST withBlock:^(NSDictionary *dict, NSError *error) {
                if ([[NSString stringWithFormat:@"%@",[dict objectForKey:@"code"]] isEqualToString:@"0"]) {
                    [self showHUDTextOnly:dict[kMessage]];
                    [[NSUserDefaults standardUserDefaults] removeObjectForKey:kToken];
                    LoginOrRegisterViewController *loginVC = [[LoginOrRegisterViewController alloc] init];
                    loginVC.typeStr = @"1";
                    [self.navigationController pushViewController:loginVC animated:YES];
                }else{
                    [self showHUDTextOnly:dict[kMessage]];
                }
            }];
        }
            break;
            
        default:
            break;
    }
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

@end
