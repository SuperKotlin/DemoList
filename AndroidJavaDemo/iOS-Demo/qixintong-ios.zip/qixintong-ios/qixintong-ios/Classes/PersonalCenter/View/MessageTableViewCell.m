//
//  MessageTableViewCell.m
//  qixintong-ios
//
//  Created by buwen zhou on 2018/4/24.
//  Copyright © 2018年 dmooo. All rights reserved.
//

#import "MessageTableViewCell.h"

@implementation MessageTableViewCell

- (void)awakeFromNib {
    [super awakeFromNib];
    // Initialization code
}

- (instancetype)initWithStyle:(UITableViewCellStyle)style reuseIdentifier:(NSString *)reuseIdentifier{
    self = [super initWithStyle:style reuseIdentifier:reuseIdentifier];
    if (self) {
        self.titleLabel = [[UILabel alloc] initWithFrame:CGRectMake(11 * kScreenWidthProportion, 11 * kScreenHeightProportion, kScreenWidth - 110 * kScreenWidthProportion, 13 * kScreenHeightProportion)];
        self.titleLabel.font = FONT_BOLD(13 * kFontProportion);
        [self.contentView addSubview:self.titleLabel];
        
        self.timeLabel = [[UILabel alloc] initWithFrame:CGRectMake(0, 0, 74 * kScreenWidthProportion, 13 * kScreenHeightProportion)];
        self.timeLabel.maxX = kScreenWidth - 15 * kScreenWidthProportion;
        self.timeLabel.font = FONT(12 * kFontProportion);
        self.timeLabel.textColor = kGrayLabelColor;
        self.timeLabel.centerY = self.titleLabel.centerY;
        [self.contentView addSubview:self.timeLabel];
        
        self.contentLabel = [[UILabel alloc] initWithFrame:CGRectMake(self.titleLabel.minX, self.titleLabel.maxY + 9 * kScreenHeightProportion, kScreenWidth - 24 * kScreenWidthProportion, 11 * kScreenHeightProportion)];
        self.contentLabel.font = FONT(11 * kFontProportion);
        [self.contentView addSubview:self.contentLabel];
        
        UIView *lineView = [[UIView alloc] initWithFrame:CGRectMake(0, 57 * kScreenHeightProportion, kScreenWidth, 1 * kScreenHeightProportion)];
        lineView.backgroundColor = kGrayBackgroundColor;
        [self.contentView addSubview:lineView];
    }
    return self;
    
}

- (void)setSelected:(BOOL)selected animated:(BOOL)animated {
    [super setSelected:selected animated:animated];

    // Configure the view for the selected state
}

@end
