//
//  ApplicationForLoanTableViewCell.h
//  qixintong-ios
//
//  Created by buwen zhou on 2018/4/24.
//  Copyright © 2018年 dmooo. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface ApplicationForLoanTableViewCell : UITableViewCell
@property (nonatomic,strong) UILabel *typeLabel;
@property (nonatomic,strong) UILabel *timeLabel;
@property (nonatomic,strong) UILabel *moneyLabel;
@property (nonatomic,strong) UILabel *rateLabel;
@property (nonatomic,strong) UIImageView *statusImgView;
@property (nonatomic,strong) UILabel *statusLabel;
@property (nonatomic,strong) UIButton *statusButton;

@end
