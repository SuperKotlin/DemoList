//
//  NewbieRaidersViewController.m
//  qixintong-ios
//
//  Created by buwen zhou on 2018/4/24.
//  Copyright © 2018年 dmooo. All rights reserved.
//

#import "NewbieRaidersViewController.h"
#import "NewbieRaidersTableViewCell.h"
#import "ArticleViewController.h"

@interface NewbieRaidersViewController ()<UITableViewDelegate,UITableViewDataSource>{
    //列表
    UITableView *messageTableView;
    //列表数据
    NSMutableArray *listMutArray;
}

@end

@implementation NewbieRaidersViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    [self initUI];
    [self initData];
}
- (void)initData{
    __block int page = 1;
    listMutArray = [NSMutableArray array];
    [MBProgressHUD showHUDAddedTo:self.view animated:YES];
    NSDictionary *parameters = @{
                                 @"cat_id":@"1",
                                 @"p":[NSString stringWithFormat:@"%d",page],
                                 @"per":@"10"
                                 };
    [self defaultRequestwithURL:kGetArticleListURL withParameters:parameters withMethod:kPOST withBlock:^(NSDictionary *dict, NSError *error) {
        [MBProgressHUD hideHUDForView:self.view animated:YES];
        if ([[NSString stringWithFormat:@"%@",[dict objectForKey:@"code"]] isEqualToString:@"0"]) {
            [listMutArray addObjectsFromArray:[[dict objectForKey:@"data"] objectForKey:@"list"]];
            [messageTableView reloadData];
            
            page ++;
        }else if ([[NSString stringWithFormat:@"%@",[dict objectForKey:@"code"]] isEqualToString:@"104"]){
            [self.navigationController pushViewController:[LoginOrRegisterViewController new] animated:YES];
        }else{
            [self showHUDTextOnly:dict[kMessage]];
        }
    }];
    
    messageTableView.mj_header = [MJRefreshNormalHeader headerWithRefreshingBlock:^{
        page = 1;
        listMutArray = [NSMutableArray array];
        [MBProgressHUD showHUDAddedTo:self.view animated:YES];
        NSDictionary *parameters = @{
                                     @"cat_id":@"1",
                                     @"p":[NSString stringWithFormat:@"%d",page],
                                     @"per":@"10"
                                     };
        [self defaultRequestwithURL:kGetArticleListURL withParameters:parameters withMethod:kPOST withBlock:^(NSDictionary *dict, NSError *error) {
            [MBProgressHUD hideHUDForView:self.view animated:YES];
            if ([[NSString stringWithFormat:@"%@",[dict objectForKey:@"code"]] isEqualToString:@"0"]) {
                [listMutArray addObjectsFromArray:[[dict objectForKey:@"data"] objectForKey:@"list"]];
                [messageTableView reloadData];
                page ++;
            }else if ([[NSString stringWithFormat:@"%@",[dict objectForKey:@"code"]] isEqualToString:@"104"]){
                [self.navigationController pushViewController:[LoginOrRegisterViewController new] animated:YES];
            }else{
                [self showHUDTextOnly:dict[kMessage]];
            }
            [messageTableView.mj_header endRefreshing];
        }];
    }];
    
    messageTableView.mj_footer = [MJRefreshBackNormalFooter footerWithRefreshingBlock:^{
        [MBProgressHUD showHUDAddedTo:self.view animated:YES];
        NSDictionary *parameters = @{
                                     @"cat_id":@"1",
                                     @"p":[NSString stringWithFormat:@"%d",page],
                                     @"per":@"10"
                                     };
        [self defaultRequestwithURL:kGetArticleListURL withParameters:parameters withMethod:kPOST withBlock:^(NSDictionary *dict, NSError *error) {
            [MBProgressHUD hideHUDForView:self.view animated:YES];
            if ([[NSString stringWithFormat:@"%@",[dict objectForKey:@"code"]] isEqualToString:@"0"]) {
                [listMutArray addObjectsFromArray:[[dict objectForKey:@"data"] objectForKey:@"list"]];
                [messageTableView reloadData];
                page ++;
            }else if ([[NSString stringWithFormat:@"%@",[dict objectForKey:@"code"]] isEqualToString:@"104"]){
                [self.navigationController pushViewController:[LoginOrRegisterViewController new] animated:YES];
            }else{
                [self showHUDTextOnly:dict[kMessage]];
            }
            [messageTableView.mj_footer endRefreshing];
        }];
    }];
    
}
- (void)initUI
{
    self.view.backgroundColor = kGrayBackgroundColor;
    [self customNavigationBar:@"新手攻略"];
    
    messageTableView = [[UITableView alloc] initWithFrame:CGRectMake(0, kHeaderHeight, kScreenWidth, kScreenHeight - kHeaderHeight)];
    messageTableView.separatorStyle = UITableViewCellSeparatorStyleNone;
    messageTableView.backgroundColor = kGrayLineColor;
    messageTableView.delegate = self;
    messageTableView.dataSource = self;
    [self.view addSubview:messageTableView];
}
#pragma mark - tableView代理方法
- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section{
    return listMutArray.count;
}
- (CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath{
    return 86 * kScreenHeightProportion;
}
- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath{
    static NSString *indefier = @"Cell";
    NewbieRaidersTableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:indefier];
    if (!cell) {
        cell = [[NewbieRaidersTableViewCell alloc] initWithStyle:UITableViewCellStyleDefault reuseIdentifier:indefier];
    }
    cell.selectionStyle = UITableViewCellSelectionStyleNone;
    
    NSDictionary *dict = listMutArray[indexPath.row];
    cell.titleLabel.text = [NSString stringWithFormat:@"%@",dict[@"title"]];
    cell.timeLabel.text = [[NSString stringWithFormat:@"%@",dict[@"pubtime"]] substringWithRange:NSMakeRange(0, 10)];
    [cell.picImgView setImageWithURL:[NSURL URLWithString:[NSString stringWithFormat:@"%@%@",kBaseURL,dict[@"img"]]] placeholderImage:[UIImage imageNamed:@"borrow_banner"]];
    
    return cell;
}
- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath{
    NSDictionary *dict = listMutArray[indexPath.row];
    ArticleViewController *arVC = [[ArticleViewController alloc] init];
    arVC.articleIdStr = [NSString stringWithFormat:@"%@",dict[@"article_id"]];
    arVC.titleStr = @"新手攻略";
    [self.navigationController pushViewController:arVC animated:YES];
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

@end
