//
//  LoanViewController.m
//  qixintong-ios
//
//  Created by buwen zhou on 2018/4/10.
//  Copyright © 2018年 dmooo. All rights reserved.
//

#import "LoanViewController.h"
#import "SDCycleScrollView.h"
#import "NewRecoCollectionViewCell.h"
#import "RecommendTableViewCell.h"
#import "LoanApplyOneViewController.h"
#import "NewbieRaidersViewController.h"
#import "NewbieRaidersTableViewCell.h"
#import "ArticleViewController.h"
#import "AutoScrollLabel.h" //跑马灯label

@interface LoanViewController ()<SDCycleScrollViewDelegate,UICollectionViewDelegate,UICollectionViewDataSource,UITableViewDelegate,UITableViewDataSource>{
    UIScrollView *mainScrollView;
    //轮播图
    SDCycleScrollView *picScrollView;
    //banner图数据
    NSMutableArray *bannerMutArray;
    //新手推荐
    UICollectionView *newCollectionView;
    //
    NSMutableArray *newMutArray;
    //列表
    UITableView *recommendTableView;
    //列表数据
    NSMutableArray *listMutArray;
    //新手攻略
    UILabel *raidersLabel;
    UIButton *raidersButton;
    UITableView *messageTableView;
    NSMutableArray *mesMutArray;
    //公告
    NSMutableArray *announceMutArray;
    //公告文本
    AutoScrollLabel *announcementLabel;
    UIImageView *processImgView;
}

@end

@implementation LoanViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    [self initUI];
}
- (void)viewWillAppear:(BOOL)animated{
    [super viewWillAppear:YES];
    [self showTabBarView:YES];
    
    [self getBannerData];
    [self initAnnounceData];
    [self initNewData];
    [self initHotData];
    [self initMesData];
}
#pragma mark - 获取banner图
- (void)getBannerData{
    bannerMutArray = [NSMutableArray array];
    NSDictionary *parameters = @{
                                 @"cat_id":@"1"
                                 };
    [self defaultRequestwithURL:kGetBannerListURL withParameters:parameters withMethod:kPOST withBlock:^(NSDictionary *dict, NSError *error) {
        if ([[NSString stringWithFormat:@"%@",[dict objectForKey:@"code"]] isEqualToString:@"0"]) {
            [bannerMutArray addObjectsFromArray:[[dict objectForKey:@"data"] objectForKey:@"list"]];
            
            NSMutableArray *tempMutArray = [NSMutableArray array];
            for (NSDictionary *bannerDic in bannerMutArray) {
                [tempMutArray addObject:[NSString stringWithFormat:@"%@%@",kBaseURL,bannerDic[@"img"]]];
            }
            
            picScrollView.imageURLStringsGroup = tempMutArray;
            
        }else if ([[NSString stringWithFormat:@"%@",[dict objectForKey:@"code"]] isEqualToString:@"104"]){
            [self.navigationController pushViewController:[LoginOrRegisterViewController new] animated:YES];
        }else{
            [self showHUDTextOnly:dict[kMessage]];
        }
    }];
}
//公告
- (void)initAnnounceData{
    announceMutArray = [NSMutableArray array];
    NSDictionary *parameters = @{
                                 @"cat_id":@"4",
                                 @"p":@"1",
                                 @"per":@""
                                 };
    [self defaultRequestwithURL:kGetArticleListURL withParameters:parameters withMethod:kPOST withBlock:^(NSDictionary *dict, NSError *error) {
        [MBProgressHUD hideHUDForView:self.view animated:YES];
        if ([[NSString stringWithFormat:@"%@",[dict objectForKey:@"code"]] isEqualToString:@"0"]) {
            [announceMutArray addObjectsFromArray:[[[dict objectForKey:@"data"] objectForKey:@"list"] valueForKey:@"content"]];
            
            NSString *annStr = @"";
            for (NSString *str in announceMutArray) {
                annStr = [NSString stringWithFormat:@"%@               %@",annStr,str];
            }
            announcementLabel.text = annStr;
            
        }else if ([[NSString stringWithFormat:@"%@",[dict objectForKey:@"code"]] isEqualToString:@"104"]){
            [self.navigationController pushViewController:[LoginOrRegisterViewController new] animated:YES];
        }else{
            [self showHUDTextOnly:dict[kMessage]];
        }
    }];
}
- (void)initNewData{
    __block int page = 1;
    newMutArray = [NSMutableArray array];
    [MBProgressHUD showHUDAddedTo:self.view animated:YES];
    NSDictionary *parameters = @{
                                 @"is_top":@"",
                                 @"is_new":@"Y",
                                 @"p":[NSString stringWithFormat:@"%d",page],
                                 @"per":@""
                                 };
    [self defaultRequestwithURL:kGetProductListURL withParameters:parameters withMethod:kPOST withBlock:^(NSDictionary *dict, NSError *error) {
        [MBProgressHUD hideHUDForView:self.view animated:YES];
        if ([[NSString stringWithFormat:@"%@",[dict objectForKey:@"code"]] isEqualToString:@"0"]) {
            [newMutArray addObjectsFromArray:[[dict objectForKey:@"data"] objectForKey:@"list"]];
            [newCollectionView reloadData];
            
            page ++;
        }else if ([[NSString stringWithFormat:@"%@",[dict objectForKey:@"code"]] isEqualToString:@"104"]){
            [self.navigationController pushViewController:[LoginOrRegisterViewController new] animated:YES];
        }else{
            [self showHUDTextOnly:dict[kMessage]];
        }
    }];
}
- (void)initHotData{
    __block int page = 1;
    listMutArray = [NSMutableArray array];
    [MBProgressHUD showHUDAddedTo:self.view animated:YES];
    NSDictionary *parameters = @{
                                 @"is_top":@"Y",
                                 @"is_new":@"",
                                 @"p":[NSString stringWithFormat:@"%d",page],
                                 @"per":@"4"
                                 };
    [self defaultRequestwithURL:kGetProductListURL withParameters:parameters withMethod:kPOST withBlock:^(NSDictionary *dict, NSError *error) {
        [MBProgressHUD hideHUDForView:self.view animated:YES];
        if ([[NSString stringWithFormat:@"%@",[dict objectForKey:@"code"]] isEqualToString:@"0"]) {
            [listMutArray addObjectsFromArray:[[dict objectForKey:@"data"] objectForKey:@"list"]];
            [recommendTableView reloadData];
            
            if (listMutArray.count == 0) {
                recommendTableView.height = 0;
            }else{
                recommendTableView.height = listMutArray.count * 122 * kScreenHeightProportion;
            }
            
            raidersLabel.minY = recommendTableView.maxY + 18 * kScreenHeightProportion;
            processImgView.minY = recommendTableView.maxY;
            raidersLabel.minY = processImgView.maxY + 18 * kScreenHeightProportion;
            raidersButton.centerY = raidersLabel.centerY;
            messageTableView.minY = raidersLabel.maxY + 16 * kScreenHeightProportion;
            mainScrollView.contentSize = CGSizeMake(kScreenWidth, messageTableView.maxY);
            
            page ++;
        }else if ([[NSString stringWithFormat:@"%@",[dict objectForKey:@"code"]] isEqualToString:@"104"]){
            [self.navigationController pushViewController:[LoginOrRegisterViewController new] animated:YES];
        }else{
            [self showHUDTextOnly:dict[kMessage]];
        }
    }];
    
    mainScrollView.mj_header = [MJRefreshNormalHeader headerWithRefreshingBlock:^{
        page = 1;
        listMutArray = [NSMutableArray array];
        [MBProgressHUD showHUDAddedTo:self.view animated:YES];
        NSDictionary *parameters = @{
                                     @"is_top":@"Y",
                                     @"is_new":@"",
                                     @"p":[NSString stringWithFormat:@"%d",page],
                                     @"per":@"4"
                                     };
        [self defaultRequestwithURL:kGetProductListURL withParameters:parameters withMethod:kPOST withBlock:^(NSDictionary *dict, NSError *error) {
            [MBProgressHUD hideHUDForView:self.view animated:YES];
            if ([[NSString stringWithFormat:@"%@",[dict objectForKey:@"code"]] isEqualToString:@"0"]) {
                [listMutArray addObjectsFromArray:[[dict objectForKey:@"data"] objectForKey:@"list"]];
                [recommendTableView reloadData];
                
                if (listMutArray.count == 0) {
                    recommendTableView.height = 0;
                }else{
                    recommendTableView.height = listMutArray.count * 122 * kScreenHeightProportion;
                }
                
                raidersLabel.minY = recommendTableView.maxY + 18 * kScreenHeightProportion;
                processImgView.minY = recommendTableView.maxY;
                raidersLabel.minY = processImgView.maxY + 18 * kScreenHeightProportion;
                raidersButton.centerY = raidersLabel.centerY;
                messageTableView.minY = raidersLabel.maxY + 16 * kScreenHeightProportion;
                mainScrollView.contentSize = CGSizeMake(kScreenWidth, messageTableView.maxY);
                
                //下拉的时候，也刷新下其他的数据
                [self getBannerData];
                [self initNewData];
                [self initMesData];
                
                page ++;
            }else if ([[NSString stringWithFormat:@"%@",[dict objectForKey:@"code"]] isEqualToString:@"104"]){
                [self.navigationController pushViewController:[LoginOrRegisterViewController new] animated:YES];
            }else{
                [self showHUDTextOnly:dict[kMessage]];
            }
            [mainScrollView.mj_header endRefreshing];
        }];
    }];
    
    mainScrollView.mj_footer = [MJRefreshBackNormalFooter footerWithRefreshingBlock:^{
        [MBProgressHUD showHUDAddedTo:self.view animated:YES];
        NSDictionary *parameters = @{
                                     @"is_top":@"Y",
                                     @"is_new":@"",
                                     @"p":[NSString stringWithFormat:@"%d",page],
                                     @"per":@"4"
                                     };
        [self defaultRequestwithURL:kGetProductListURL withParameters:parameters withMethod:kPOST withBlock:^(NSDictionary *dict, NSError *error) {
            [MBProgressHUD hideHUDForView:self.view animated:YES];
            if ([[NSString stringWithFormat:@"%@",[dict objectForKey:@"code"]] isEqualToString:@"0"]) {
                [listMutArray addObjectsFromArray:[[dict objectForKey:@"data"] objectForKey:@"list"]];
                [recommendTableView reloadData];
                
                if (listMutArray.count == 0) {
                    recommendTableView.height = 0;
                }else{
                    recommendTableView.height = listMutArray.count * 122 * kScreenHeightProportion;
                }
                
                raidersLabel.minY = recommendTableView.maxY + 18 * kScreenHeightProportion;
                processImgView.minY = recommendTableView.maxY;
                raidersLabel.minY = processImgView.maxY + 18 * kScreenHeightProportion;
                raidersButton.centerY = raidersLabel.centerY;
                messageTableView.minY = raidersLabel.maxY + 16 * kScreenHeightProportion;
                mainScrollView.contentSize = CGSizeMake(kScreenWidth, messageTableView.maxY);
                
                page ++;
            }else if ([[NSString stringWithFormat:@"%@",[dict objectForKey:@"code"]] isEqualToString:@"104"]){
                [self.navigationController pushViewController:[LoginOrRegisterViewController new] animated:YES];
            }else{
                [self showHUDTextOnly:dict[kMessage]];
            }
            [mainScrollView.mj_footer endRefreshing];
        }];
    }];
}
//新手攻略
- (void)initMesData{
    __block int page = 1;
    mesMutArray = [NSMutableArray array];
    [MBProgressHUD showHUDAddedTo:self.view animated:YES];
    NSDictionary *parameters = @{
                                 @"cat_id":@"1",
                                 @"p":[NSString stringWithFormat:@"%d",page],
                                 @"per":@"2"
                                 };
    [self defaultRequestwithURL:kGetArticleListURL withParameters:parameters withMethod:kPOST withBlock:^(NSDictionary *dict, NSError *error) {
        [MBProgressHUD hideHUDForView:self.view animated:YES];
        if ([[NSString stringWithFormat:@"%@",[dict objectForKey:@"code"]] isEqualToString:@"0"]) {
            [mesMutArray addObjectsFromArray:[[dict objectForKey:@"data"] objectForKey:@"list"]];
            [messageTableView reloadData];
            
            if (mesMutArray.count == 0) {
                messageTableView.height = 0;
            }else{
                messageTableView.height = mesMutArray.count * 86 * kScreenHeightProportion;
            }
            mainScrollView.contentSize = CGSizeMake(kScreenWidth, messageTableView.maxY);
            
            page ++;
        }else if ([[NSString stringWithFormat:@"%@",[dict objectForKey:@"code"]] isEqualToString:@"104"]){
            [self.navigationController pushViewController:[LoginOrRegisterViewController new] animated:YES];
        }else{
            [self showHUDTextOnly:dict[kMessage]];
        }
    }];
}
- (void)initUI
{
    self.navigationController.navigationBarHidden = YES;
    
    UIView *statusView = [[UIView alloc] initWithFrame:CGRectMake(0, 0, kScreenWidth, kStatusHeight)];
    statusView.backgroundColor = kDefaultColor;
    [self.view addSubview:statusView];
    
    mainScrollView = [[UIScrollView alloc] initWithFrame:CGRectMake(0, statusView.maxY, kScreenWidth, kScreenHeight - statusView.maxY - kTabBarHeight)];
    mainScrollView.backgroundColor = kGrayBackgroundColor;
    [self.view addSubview:mainScrollView];
    
    UIImageView *headImgView = [[UIImageView alloc] initWithFrame:CGRectMake(0, 0, kScreenWidth, 156 * kScreenHeightProportion)];
    headImgView.image = [UIImage imageNamed:@"home_banner"];
    [mainScrollView addSubview:headImgView];
    
    UIView *announcementView = [[UIView alloc] initWithFrame:CGRectMake(0, headImgView.maxY, kScreenWidth, 26 * kScreenHeightProportion)];
    announcementView.backgroundColor = [UIColor whiteColor];
    [mainScrollView addSubview:announcementView];
    
    UIImageView *annImgView = [[UIImageView alloc] initWithFrame:CGRectMake(8 * kScreenWidthProportion, 0, 12 * kScreenWidthProportion, 13 * kScreenHeightProportion)];
    annImgView.image = [UIImage imageNamed:@"home_notice"];
    annImgView.centerY = announcementView.height / 2.0;
    [announcementView addSubview:annImgView];
    
    //公告
    announcementLabel = [[AutoScrollLabel alloc] initWithFrame:CGRectMake(annImgView.maxX + 5 * kScreenWidthProportion, 0, kScreenWidth - annImgView.maxX - 15 * kScreenWidthProportion, announcementView.height)];
    announcementLabel.textColor = kGrayLabelColor;
    announcementLabel.font = FONT(13 * kFontProportion);
    announcementLabel.backgroundColor = [UIColor whiteColor];
    [announcementView addSubview:announcementLabel];
    
    picScrollView = [SDCycleScrollView cycleScrollViewWithFrame:CGRectMake(0, announcementView.maxY + 1 * kScreenHeightProportion, kScreenWidth, 94 * kScreenHeightProportion) imageNamesGroup:nil];
    picScrollView.delegate = self;
    picScrollView.bannerImageViewContentMode = UIViewContentModeScaleAspectFill;
    picScrollView.placeholderImage = [UIImage imageNamed:@"home_advertisment1"];
    picScrollView.backgroundColor = [UIColor whiteColor];
    [mainScrollView addSubview:picScrollView];
    
    //新手推荐
    UILabel *newRecoLabel = [[UILabel alloc] initWithFrame:CGRectMake(10 * kScreenWidthProportion, picScrollView.maxY, kScreenWidth, 50 * kScreenHeightProportion)];
    newRecoLabel.text = @"新手推荐";
    newRecoLabel.font = FONT(15 * kFontProportion);
    [mainScrollView addSubview:newRecoLabel];
    
    UICollectionViewFlowLayout *layout = [UICollectionViewFlowLayout new];
    layout.minimumInteritemSpacing = 0 * kScreenWidthProportion;
    layout.minimumLineSpacing = 0;
    layout.itemSize = CGSizeMake((kScreenWidth - 0 * kScreenWidthProportion) / 2, 64 * kScreenHeightProportion);
    layout.scrollDirection = UICollectionViewScrollDirectionHorizontal;
    
    newCollectionView = [[UICollectionView alloc] initWithFrame:CGRectMake(0 * kScreenWidthProportion, newRecoLabel.maxY, kScreenWidth - 0 * kScreenWidthProportion, 64 * kScreenHeightProportion) collectionViewLayout:layout];
    newCollectionView.dataSource = self;
    newCollectionView.delegate = self;
    newCollectionView.backgroundColor = kGrayBackgroundColor;
    newCollectionView.showsHorizontalScrollIndicator = NO;
    [mainScrollView addSubview:newCollectionView];
    [newCollectionView registerClass:[NewRecoCollectionViewCell class] forCellWithReuseIdentifier:@"freeCell"];
    
    //热门推荐
    UILabel *hotRecoLabel = [[UILabel alloc] initWithFrame:CGRectMake(10 * kScreenWidthProportion, newCollectionView.maxY + 18 * kScreenHeightProportion, kScreenWidth / 2.0, 16 * kScreenHeightProportion)];
    hotRecoLabel.text = @"热门推荐";
    hotRecoLabel.font = FONT(15 * kFontProportion);
    [mainScrollView addSubview:hotRecoLabel];
    
    UILabel *hotMoreLabel = [[UILabel alloc] initWithFrame:CGRectMake(hotRecoLabel.maxX, 0, kScreenWidth - hotRecoLabel.maxX - 26 * kScreenWidthProportion, 16 * kScreenHeightProportion)];
    hotMoreLabel.text = @"查看全部";
    hotMoreLabel.textAlignment = NSTextAlignmentRight;
    hotMoreLabel.font = FONT(13 * kFontProportion);
    hotMoreLabel.centerY = hotRecoLabel.centerY;
    hotMoreLabel.textColor = kGrayLabelColor;
    [mainScrollView addSubview:hotMoreLabel];
    
    UIImageView *hotRightImgView = [[UIImageView alloc] initWithFrame:CGRectMake(hotMoreLabel.maxX + 3 * kScreenWidthProportion, 0, 5 * kScreenWidthProportion, 11 * kScreenHeightProportion)];
    hotRightImgView.image = [UIImage imageNamed:@"gray_back"];
    hotRightImgView.centerY = hotMoreLabel.centerY;
    [mainScrollView addSubview:hotRightImgView];
    
    UIButton *hotMoreButton = [[UIButton alloc] initWithFrame:CGRectMake(hotMoreLabel.minX, hotMoreLabel.minY, kScreenWidth - hotRecoLabel.maxX, 16 * kScreenHeightProportion)];
    [hotMoreButton addTarget:self action:@selector(hotMoreButtonAction) forControlEvents:UIControlEventTouchUpInside];
    [mainScrollView addSubview:hotMoreButton];
    
    UIView *footerView = [[UIView alloc] initWithFrame:CGRectMake(0, 0, kScreenWidth, 10 * kScreenHeightProportion)];
    
    recommendTableView = [[UITableView alloc] initWithFrame:CGRectMake(0, hotRecoLabel.maxY, kScreenWidth, 122  * 4 * kScreenHeightProportion)];
    recommendTableView.separatorStyle = UITableViewCellSeparatorStyleNone;
    recommendTableView.backgroundColor = kGrayBackgroundColor;
    recommendTableView.delegate = self;
    recommendTableView.dataSource = self;
    recommendTableView.tableFooterView = footerView;
    recommendTableView.scrollEnabled = NO;
    [mainScrollView addSubview:recommendTableView];
    
    processImgView = [[UIImageView alloc] initWithFrame:CGRectMake(0, recommendTableView.maxY, kScreenWidth, 240 * kScreenHeightProportion)];
    processImgView.image = [UIImage imageNamed:@"home_process"];
    [mainScrollView addSubview:processImgView];
    
    //新手攻略
    raidersLabel = [[UILabel alloc] initWithFrame:CGRectMake(10 * kScreenWidthProportion, processImgView.maxY + 18 * kScreenHeightProportion, kScreenWidth / 2.0, 16 * kScreenHeightProportion)];
    raidersLabel.text = @"新手攻略";
    raidersLabel.font = FONT(15 * kFontProportion);
    [mainScrollView addSubview:raidersLabel];
    
    raidersButton = [[UIButton alloc] initWithFrame:CGRectMake(raidersLabel.maxX, raidersLabel.minY, kScreenWidth - raidersLabel.maxX, 16 * kScreenHeightProportion)];
    [raidersButton addTarget:self action:@selector(raidersButtonAction) forControlEvents:UIControlEventTouchUpInside];
    raidersButton.centerY = raidersLabel.centerY;
    [mainScrollView addSubview:raidersButton];
    
    UILabel *raidersMoreLabel = [[UILabel alloc] initWithFrame:CGRectMake(0, 0, raidersButton.width - 26 * kScreenWidthProportion, 16 * kScreenHeightProportion)];
    raidersMoreLabel.text = @"查看全部";
    raidersMoreLabel.textAlignment = NSTextAlignmentRight;
    raidersMoreLabel.font = FONT(13 * kFontProportion);
    raidersMoreLabel.centerY = raidersButton.height / 2.0;
    raidersMoreLabel.textColor = kGrayLabelColor;
    [raidersButton addSubview:raidersMoreLabel];
    
    UIImageView *raidersImgView = [[UIImageView alloc] initWithFrame:CGRectMake(raidersMoreLabel.maxX + 3 * kScreenWidthProportion, 0, 5 * kScreenWidthProportion, 11 * kScreenHeightProportion)];
    raidersImgView.image = [UIImage imageNamed:@"gray_back"];
    raidersImgView.centerY = raidersMoreLabel.centerY;
    [raidersButton addSubview:raidersImgView];
    
    UIView *headView = [[UIView alloc] initWithFrame:CGRectMake(0, 0, kScreenWidth, 1 * kScreenHeightProportion)];
    headView.backgroundColor = RGB(224, 225, 226);
    
    messageTableView = [[UITableView alloc] initWithFrame:CGRectMake(0, raidersLabel.maxY + 16 * kScreenHeightProportion, kScreenWidth, 86 * 2 * kScreenHeightProportion)];
    messageTableView.separatorStyle = UITableViewCellSeparatorStyleNone;
    messageTableView.backgroundColor = kGrayLineColor;
    messageTableView.delegate = self;
    messageTableView.dataSource = self;
    messageTableView.scrollEnabled = NO;
    messageTableView.tableHeaderView = headView;
    [mainScrollView addSubview:messageTableView];
    
    mainScrollView.contentSize = CGSizeMake(kScreenWidth, messageTableView.maxY);
}
#pragma mark - collectionview代理方法
- (NSInteger)collectionView:(UICollectionView *)collectionView numberOfItemsInSection:(NSInteger)section
{
    return newMutArray.count;
}

#pragma mark - cell显示的内容
- (UICollectionViewCell *)collectionView:(UICollectionView *)collectionView cellForItemAtIndexPath:(NSIndexPath *)indexPath
{
    NewRecoCollectionViewCell *cell = (NewRecoCollectionViewCell *)[collectionView dequeueReusableCellWithReuseIdentifier:@"freeCell" forIndexPath:indexPath];
    if (cell == nil) {
        
    }
    
    NSDictionary *dict = newMutArray[indexPath.row];
    cell.titleLabel.text = [NSString stringWithFormat:@"可签约额度:%@",dict[@"limit"]];
    cell.nameLabel.text = [NSString stringWithFormat:@"%@",dict[@"name"]];
    [cell.picImgView setImageWithURL:[NSURL URLWithString:[NSString stringWithFormat:@"%@%@",kBaseURL,dict[@"img"]]] placeholderImage:[UIImage imageNamed:@""]];
    
    CGFloat agreeGrayWidth = [cell.nameLabel getTitleTextWidth:cell.nameLabel.text font:FONT(14 * kFontProportion)];
    cell.nameLabel.width = agreeGrayWidth;
    cell.nameLabel.centerX = cell.width / 2.0;
    
    cell.picImgView.maxX = cell.nameLabel.minX - 3 * kScreenWidthProportion;
    
    return cell;
}
- (void)collectionView:(UICollectionView *)collectionView didSelectItemAtIndexPath:(NSIndexPath *)indexPath{
    [self showTabBarView:NO];
    NSDictionary *dict = newMutArray[indexPath.row];
    LoanApplyOneViewController *detailsVC = [[LoanApplyOneViewController alloc] init];
    detailsVC.productIdStr = [NSString stringWithFormat:@"%@",dict[@"product_id"]];
    [self.navigationController pushViewController:detailsVC animated:YES];
}
#pragma mark - tableView代理方法
- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section{
    if (tableView == recommendTableView) {
        return listMutArray.count;
    }
    return mesMutArray.count;
}
- (CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath{
    if (tableView == recommendTableView) {
        return 122 * kScreenHeightProportion;
    }
    return 86 * kScreenHeightProportion;
}
- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath{
    if (tableView == recommendTableView) {
        static NSString *indefier = @"Cell";
        RecommendTableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:indefier];
        if (!cell) {
            cell = [[RecommendTableViewCell alloc] initWithStyle:UITableViewCellStyleDefault reuseIdentifier:indefier];
        }
        cell.selectionStyle = UITableViewCellSelectionStyleNone;
        
        NSDictionary *dict = listMutArray[indexPath.row];
        cell.nameLabel.text = [NSString stringWithFormat:@"%@",dict[@"name"]];
        [cell.picImgView setImageWithURL:[NSURL URLWithString:[NSString stringWithFormat:@"%@%@",kBaseURL,dict[@"img"]]] placeholderImage:[UIImage imageNamed:@""]];
        cell.timeLabel.text = [NSString stringWithFormat:@"期限：%@",[NSString stringWithFormat:@"%@",dict[@"deadline"]]];
        cell.moneyLabel.text = [NSString stringWithFormat:@"%@",dict[@"limit"]];
        cell.rateLabel.text = [NSString stringWithFormat:@"日费率：%@",dict[@"rate"]];
        
        [cell.applyButton addTarget:self action:@selector(applyButtonAction:) forControlEvents:UIControlEventTouchUpInside];
        cell.applyButton.tag = indexPath.row + kTagStart;
        
        return cell;
    }
    
    static NSString *indefier = @"Cell";
    NewbieRaidersTableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:indefier];
    if (!cell) {
        cell = [[NewbieRaidersTableViewCell alloc] initWithStyle:UITableViewCellStyleDefault reuseIdentifier:indefier];
    }
    cell.selectionStyle = UITableViewCellSelectionStyleNone;
    cell.backgroundColor = kGrayBackgroundColor;
    
    NSDictionary *dict = mesMutArray[indexPath.row];
    cell.titleLabel.text = [NSString stringWithFormat:@"%@",dict[@"title"]];
    cell.timeLabel.text = [[NSString stringWithFormat:@"%@",dict[@"pubtime"]] substringWithRange:NSMakeRange(0, 10)];
    [cell.picImgView setImageWithURL:[NSURL URLWithString:[NSString stringWithFormat:@"%@%@",kBaseURL,dict[@"img"]]] placeholderImage:[UIImage imageNamed:@"borrow_banner"]];
    cell.lineView.backgroundColor = RGB(224, 225, 226);
    
    return cell;
}
- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath{
    if (tableView == messageTableView) {
        [self showTabBarView:NO];
        NSDictionary *dict = mesMutArray[indexPath.row];
        ArticleViewController *arVC = [[ArticleViewController alloc] init];
        arVC.articleIdStr = [NSString stringWithFormat:@"%@",dict[@"article_id"]];
        arVC.titleStr = @"新手攻略";
        [self.navigationController pushViewController:arVC animated:YES];
    }
}
- (void)applyButtonAction:(UIButton *)sender{
    [self showTabBarView:NO];
    NSDictionary *dict = listMutArray[sender.tag - kTagStart];
    LoanApplyOneViewController *detailsVC = [[LoanApplyOneViewController alloc] init];
    detailsVC.productIdStr = [NSString stringWithFormat:@"%@",dict[@"product_id"]];
    [self.navigationController pushViewController:detailsVC animated:YES];
}
#pragma mark - 热门推荐更多
- (void)hotMoreButtonAction{
    TabBarController *tabVC = (TabBarController *)self.tabBarController;
    [tabVC setSelect:1];
    [self.navigationController popToRootViewControllerAnimated:YES];
}
#pragma mark - 新手攻略
- (void)raidersButtonAction{
    [self showTabBarView:NO];
    [self.navigationController pushViewController:[NewbieRaidersViewController new] animated:YES];
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

@end
