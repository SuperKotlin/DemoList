//
//  NewRecoCollectionViewCell.m
//  qixintong-ios
//
//  Created by buwen zhou on 2018/4/26.
//  Copyright © 2018年 dmooo. All rights reserved.
//

#import "NewRecoCollectionViewCell.h"

@implementation NewRecoCollectionViewCell

- (instancetype)initWithFrame:(CGRect)frame
{
    self = [super initWithFrame:frame];
    if (self) {
        CGFloat width = (kScreenWidth - 0 * kScreenWidthProportion) / 2.0;
        
        UIView *mainView = [[UIView alloc] initWithFrame:CGRectMake(5 * kScreenWidthProportion, 0, width - 10 * kScreenWidthProportion, 64 * kScreenHeightProportion)];
        [mainView setCornerRadius:8.f * kScreenHeightProportion];
        [mainView setBorder:1.f color:RGB(224, 224, 224)];
        mainView.backgroundColor = [UIColor whiteColor];
        [self.contentView addSubview:mainView];
        
        self.titleLabel = [[UILabel alloc] initWithFrame:CGRectMake(0, 10 * kScreenHeightProportion, mainView.width, 12 * kScreenHeightProportion)];
        self.titleLabel.font = FONT(12 * kFontProportion);
        self.titleLabel.textColor = kGrayLabelColor;
        self.titleLabel.textAlignment = NSTextAlignmentCenter;
        [mainView addSubview:self.titleLabel];
        
        self.picImgView = [[UIImageView alloc] initWithFrame:CGRectMake(10 * kScreenWidthProportion, self.titleLabel.maxY + 8 * kScreenHeightProportion, 15 * kScreenWidthProportion, 15 * kScreenHeightProportion)];
        [mainView addSubview:self.picImgView];
        
        self.nameLabel = [[UILabel alloc] initWithFrame:CGRectMake(self.picImgView.maxX + 3 * kScreenWidthProportion, 0, mainView.width - self.picImgView.maxX - 25 * kScreenWidthProportion, 15 * kScreenHeightProportion)];
        self.nameLabel.font = FONT(14 * kFontProportion);
        self.nameLabel.centerY = self.picImgView.centerY;
        self.nameLabel.centerX = mainView.width / 2.0;
        [mainView addSubview:self.nameLabel];
        
        UIImageView *rightImgView = [[UIImageView alloc] initWithFrame:CGRectMake(self.nameLabel.maxX, 0, 5 * kScreenWidthProportion, 11 * kScreenHeightProportion)];
        rightImgView.image = [UIImage imageNamed:@"gray_back"];
        rightImgView.centerY = self.nameLabel.centerY;
        [mainView addSubview:rightImgView];
    }
    return self;
}

@end
