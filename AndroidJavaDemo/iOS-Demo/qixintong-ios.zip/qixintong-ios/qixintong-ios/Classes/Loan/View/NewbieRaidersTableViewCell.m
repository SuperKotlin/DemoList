//
//  NewbieRaidersTableViewCell.m
//  qixintong-ios
//
//  Created by buwen zhou on 2018/4/24.
//  Copyright © 2018年 dmooo. All rights reserved.
//

#import "NewbieRaidersTableViewCell.h"

@implementation NewbieRaidersTableViewCell

- (void)awakeFromNib {
    [super awakeFromNib];
    // Initialization code
}
- (instancetype)initWithStyle:(UITableViewCellStyle)style reuseIdentifier:(NSString *)reuseIdentifier{
    self = [super initWithStyle:style reuseIdentifier:reuseIdentifier];
    if (self) {
        self.titleLabel = [[UILabel alloc] initWithFrame:CGRectMake(11 * kScreenWidthProportion, 23 * kScreenHeightProportion, kScreenWidth - 130 * kScreenWidthProportion, 13 * kScreenHeightProportion)];
        self.titleLabel.font = FONT_BOLD(13 * kFontProportion);
        [self.contentView addSubview:self.titleLabel];
        
        self.timeLabel = [[UILabel alloc] initWithFrame:CGRectMake(self.titleLabel.minX, self.titleLabel.maxY + 12 * kScreenHeightProportion, 74 * kScreenWidthProportion, 13 * kScreenHeightProportion)];
        self.timeLabel.font = FONT(12 * kFontProportion);
        self.timeLabel.textColor = kGrayLabelColor;
        [self.contentView addSubview:self.timeLabel];
        
        self.picImgView = [[UIImageView alloc] initWithFrame:CGRectMake(kScreenWidth - 118 * kScreenWidthProportion, 0, 104 * kScreenWidthProportion, 60 * kScreenHeightProportion)];
        self.picImgView.centerY = 43 * kScreenHeightProportion;
        [self.contentView addSubview:self.picImgView];
        
        self.lineView = [[UIView alloc] initWithFrame:CGRectMake(0, 85 * kScreenHeightProportion, kScreenWidth, 1 * kScreenHeightProportion)];
        self.lineView.backgroundColor = kGrayBackgroundColor;
        [self.contentView addSubview:self.lineView];
    }
    return self;
    
}

- (void)setSelected:(BOOL)selected animated:(BOOL)animated {
    [super setSelected:selected animated:animated];

    // Configure the view for the selected state
}

@end
