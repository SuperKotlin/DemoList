//
//  NewRecoCollectionViewCell.h
//  qixintong-ios
//
//  Created by buwen zhou on 2018/4/26.
//  Copyright © 2018年 dmooo. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface NewRecoCollectionViewCell : UICollectionViewCell
@property (nonatomic,strong) UILabel *titleLabel;
@property (nonatomic,strong) UIImageView *picImgView;
@property (nonatomic,strong) UILabel *nameLabel;

@end
