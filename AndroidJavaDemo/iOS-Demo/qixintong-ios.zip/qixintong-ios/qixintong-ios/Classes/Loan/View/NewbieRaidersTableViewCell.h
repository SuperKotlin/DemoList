//
//  NewbieRaidersTableViewCell.h
//  qixintong-ios
//
//  Created by buwen zhou on 2018/4/24.
//  Copyright © 2018年 dmooo. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface NewbieRaidersTableViewCell : UITableViewCell
@property (nonatomic,strong) UILabel *titleLabel;
@property (nonatomic,strong) UILabel *timeLabel;
@property (nonatomic,strong) UIImageView *picImgView;
@property (nonatomic,strong) UIView *lineView;

@end
