//
//  RecommendTableViewCell.m
//  qixintong-ios
//
//  Created by buwen zhou on 2018/4/25.
//  Copyright © 2018年 dmooo. All rights reserved.
//

#import "RecommendTableViewCell.h"

@implementation RecommendTableViewCell

- (void)awakeFromNib {
    [super awakeFromNib];
    // Initialization code
}
- (instancetype)initWithStyle:(UITableViewCellStyle)style reuseIdentifier:(NSString *)reuseIdentifier{
    self = [super initWithStyle:style reuseIdentifier:reuseIdentifier];
    if (self) {
        self.contentView.backgroundColor = kGrayBackgroundColor;
        UIView *mainView = [[UIView alloc] initWithFrame:CGRectMake(12 * kScreenWidthProportion, 10 * kScreenHeightProportion, kScreenWidth - 24 * kScreenWidthProportion, 112 * kScreenHeightProportion)];
        [mainView setCornerRadius:8.f * kScreenHeightProportion];
        mainView.backgroundColor = [UIColor whiteColor];
        [mainView setBorder:1.f color:RGB(224, 224, 224)];
        [self.contentView addSubview:mainView];
        
        self.picImgView = [[UIImageView alloc] initWithFrame:CGRectMake(8 * kScreenWidthProportion, 10 * kScreenHeightProportion, 18 * kScreenWidthProportion, 18 * kScreenWidthProportion)];
        [mainView addSubview:self.picImgView];
        
        self.nameLabel = [[UILabel alloc] initWithFrame:CGRectMake(self.picImgView.maxX + 3 * kScreenWidthProportion, 11 * kScreenHeightProportion,kScreenWidth - self.picImgView.maxX - 3 * kScreenWidthProportion, 12 * kScreenHeightProportion)];
        self.nameLabel.font = FONT(13 * kFontProportion);
        self.nameLabel.centerY = self.picImgView.centerY;
        [mainView addSubview:self.nameLabel];
        
        UILabel *eduLabel = [[UILabel alloc] initWithFrame:CGRectMake(self.picImgView.minX, self.nameLabel.maxY + 10 * kScreenHeightProportion, 120 * kScreenWidthProportion, 13 * kScreenHeightProportion)];
        eduLabel.text = @"可签约额度(元)";
        eduLabel.textColor = kGrayLabelColor;
        eduLabel.font = FONT(12 * kFontProportion);
        [mainView addSubview:eduLabel];
        
        self.timeLabel = [[UILabel alloc] initWithFrame:CGRectMake(eduLabel.maxX, 0, kScreenWidth - eduLabel.maxX - 8 * kScreenWidthProportion, 11 * kScreenHeightProportion)];
        self.timeLabel.textColor = kGrayLabelColor;
        self.timeLabel.font = FONT(11 * kFontProportion);
        self.timeLabel.maxX = mainView.width - 5 * kScreenWidthProportion;
        self.timeLabel.centerY = eduLabel.centerY;
        self.timeLabel.textAlignment = NSTextAlignmentRight;
        [mainView addSubview:self.timeLabel];
        
        self.moneyLabel = [[UILabel alloc] initWithFrame:CGRectMake(eduLabel.minX, eduLabel.maxY + 9 * kScreenHeightProportion, 176 * kScreenWidthProportion, 16 * kScreenHeightProportion)];
        self.moneyLabel.font = FONT(16 * kFontProportion);
        self.moneyLabel.textColor = [UIColor redColor];
        [mainView addSubview:self.moneyLabel];
        
        self.rateLabel = [[UILabel alloc] initWithFrame:CGRectMake(self.moneyLabel.minX, self.moneyLabel.maxY + 10 * kScreenHeightProportion, self.moneyLabel.width, 12 * kScreenHeightProportion)];
        self.rateLabel.font = FONT(12 * kFontProportion);
        self.rateLabel.textColor = kGrayLabelColor;
        [mainView addSubview:self.rateLabel];
        
        self.applyButton = [[UIButton alloc] initWithFrame:CGRectMake(mainView.width - 90 * kScreenWidthProportion, 64 * kScreenHeightProportion, 80 * kScreenWidthProportion, 28 * kScreenHeightProportion)];
        [self.applyButton setTitle:@"立即申请" forState:UIControlStateNormal];
        self.applyButton.titleLabel.font = FONT(13 * kFontProportion);
        [self.applyButton setTitleColor:RGB(59, 149, 255) forState:UIControlStateNormal];
        [self.applyButton setBorder:1.f color:RGB(59, 149, 255)];
        [self.applyButton setCornerRadius:14.f * kScreenHeightProportion];
        [mainView addSubview:self.applyButton];
        
    }
    return self;
}
- (void)setSelected:(BOOL)selected animated:(BOOL)animated {
    [super setSelected:selected animated:animated];

    // Configure the view for the selected state
}

@end
