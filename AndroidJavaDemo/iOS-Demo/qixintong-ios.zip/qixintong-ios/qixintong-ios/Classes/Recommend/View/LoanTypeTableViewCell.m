//
//  LoanTypeTableViewCell.m
//  qixintong-ios
//
//  Created by buwen zhou on 2018/4/25.
//  Copyright © 2018年 dmooo. All rights reserved.
//

#import "LoanTypeTableViewCell.h"

@implementation LoanTypeTableViewCell

- (void)awakeFromNib {
    [super awakeFromNib];
    // Initialization code
}
- (instancetype)initWithStyle:(UITableViewCellStyle)style reuseIdentifier:(NSString *)reuseIdentifier{
    self = [super initWithStyle:style reuseIdentifier:reuseIdentifier];
    if (self) {
        self.titleLabel = [[UILabel alloc] initWithFrame:CGRectMake(0, 0, kScreenWidth - 50 * kScreenWidthProportion, 40 * kScreenHeightProportion)];
        self.titleLabel.font = FONT(14 * kFontProportion);
        self.titleLabel.textAlignment = NSTextAlignmentCenter;
        [self.contentView addSubview:self.titleLabel];
        
        UIView *lineView = [[UIView alloc] initWithFrame:CGRectMake(0 * kScreenWidthProportion, 39 * kScreenHeightProportion, kScreenWidth - 0 * kScreenWidthProportion, 1 * kScreenHeightProportion)];
        lineView.backgroundColor = kGrayBackgroundColor;
        [self.contentView addSubview:lineView];
    }
    return self;
}
- (void)setSelected:(BOOL)selected animated:(BOOL)animated {
    [super setSelected:selected animated:animated];

    // Configure the view for the selected state
}

@end
