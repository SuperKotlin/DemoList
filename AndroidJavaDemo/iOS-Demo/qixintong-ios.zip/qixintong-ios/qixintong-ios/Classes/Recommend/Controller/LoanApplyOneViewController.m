//
//  LoanApplyOneViewController.m
//  qixintong-ios
//
//  Created by buwen zhou on 2018/4/25.
//  Copyright © 2018年 dmooo. All rights reserved.
//

#import "LoanApplyOneViewController.h"
#import "DataChoosePopView.h"
#import "LoanTypeTableViewCell.h"

@interface LoanApplyOneViewController ()<UITableViewDelegate,UITableViewDataSource>{
    UITextField *companyTextField;
    UITextField *timeTextField;
    UITextField *typeTextField;
    UITextField *moneyTextField;
    UITextField *cardTextField;
    //弹框
    UIButton *popButton;
    //账户类型
    NSString *accountTypeStr;
    //列表
    UITableView *myScoresTableView;
    //列表数据
    NSMutableArray *listMutArray;
}

@end

@implementation LoanApplyOneViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    [self initUI];
    [self initPopView];
    [self initTypeData];
}
- (void)initUI
{
    self.view.backgroundColor = RGB(239, 239, 239);
    [self customNavigationBar:@"转贷申请"];
    
    UIView *setView = [[UIView alloc] initWithFrame:CGRectMake(6 * kScreenWidthProportion, kHeaderHeight + 13 * kScreenHeightProportion, kScreenWidth - 12 * kScreenHeightProportion, 48 * 5 * kScreenHeightProportion)];
    [setView setCornerRadius:8.f * kScreenHeightProportion];
    setView.backgroundColor = [UIColor whiteColor];
    [setView setBorder:1.f color:RGB(224, 224, 224)];
    [self.view addSubview:setView];
    
    NSArray *titleArray = @[@"企业全称",@"到期时间",@"贷款种类",@"金    额",@"银    行"];
    for (int i = 0; i < 5; i ++) {
        UILabel *titleLabel = [[UILabel alloc] initWithFrame:CGRectMake(8 * kScreenWidthProportion,48 * kScreenHeightProportion * i, 100 * kScreenWidthProportion, 48 * kScreenHeightProportion)];
        titleLabel.font = FONT(12 * kFontProportion);
        titleLabel.text = titleArray[i];
        [setView addSubview:titleLabel];
        
        UIView *lineView = [[UIView alloc] initWithFrame:CGRectMake(8 * kScreenWidthProportion, titleLabel.maxY - 1 * kScreenHeightProportion, setView.width - 16 * kScreenWidthProportion, 1 * kScreenHeightProportion)];
        lineView.backgroundColor = kGrayBackgroundColor;
        [setView addSubview:lineView];
    }
    
    companyTextField = [[UITextField alloc] initWithFrame:CGRectMake(108 * kScreenWidthProportion, 0, setView.width - 116 * kScreenWidthProportion, 48 * kScreenHeightProportion)];
    companyTextField.font = FONT(13 * kFontProportion);
    companyTextField.placeholder = @"请输入企业名称";
    companyTextField.textAlignment = NSTextAlignmentRight;
    [setView addSubview:companyTextField];
    
    UIButton *timeButton = [[UIButton alloc] initWithFrame:CGRectMake(companyTextField.minX, companyTextField.maxY, companyTextField.width, companyTextField.height)];
    [timeButton addTarget:self action:@selector(timeButtonAction) forControlEvents:UIControlEventTouchUpInside];
    [setView addSubview:timeButton];
    
    timeTextField = [[UITextField alloc] initWithFrame:CGRectMake(0, 0, companyTextField.width, companyTextField.height)];
    timeTextField.font = FONT(13 * kFontProportion);
    timeTextField.placeholder = @"请选择到期时间";
    timeTextField.textAlignment = NSTextAlignmentRight;
    [timeButton addSubview:timeTextField];
    timeTextField.userInteractionEnabled = NO;
    
    typeTextField = [[UITextField alloc] initWithFrame:CGRectMake(companyTextField.minX, timeButton.maxY, companyTextField.width - 17 * kScreenWidthProportion, companyTextField.height)];
    typeTextField.font = FONT(13 * kFontProportion);
    typeTextField.textAlignment = NSTextAlignmentRight;
    typeTextField.placeholder = @"请选择种类";
    [setView addSubview:typeTextField];
    
    UIImageView *downImgView = [[UIImageView alloc] initWithFrame:CGRectMake(typeTextField.maxX + 4 * kScreenWidthProportion, 0, 11 * kScreenWidthProportion, 7 * kScreenHeightProportion)];
    downImgView.image = [UIImage imageNamed:@"apply_return"];
    downImgView.centerY = typeTextField.centerY;
    [setView addSubview:downImgView];
    
    UIButton *typeButton = [[UIButton alloc] initWithFrame:CGRectMake(companyTextField.minX, timeButton.maxY, companyTextField.width, companyTextField.height)];
    [typeButton addTarget:self action:@selector(typeButtonAction) forControlEvents:UIControlEventTouchUpInside];
    [setView addSubview:typeButton];
    
    moneyTextField = [[UITextField alloc] initWithFrame:CGRectMake(108 * kScreenWidthProportion, typeButton.maxY, companyTextField.width, companyTextField.height)];
    moneyTextField.font = FONT(13 * kFontProportion);
    moneyTextField.placeholder = @"请输入金额";
    moneyTextField.textAlignment = NSTextAlignmentRight;
    moneyTextField.keyboardType = UIKeyboardTypeDecimalPad;
    [setView addSubview:moneyTextField];
    
    cardTextField = [[UITextField alloc] initWithFrame:CGRectMake(108 * kScreenWidthProportion, moneyTextField.maxY, companyTextField.width, companyTextField.height)];
    cardTextField.font = FONT(13 * kFontProportion);
    cardTextField.placeholder = @"请输入银行名称";
    cardTextField.textAlignment = NSTextAlignmentRight;
    [setView addSubview:cardTextField];
    
    UIButton *loginButton = [[UIButton alloc] initWithFrame:CGRectMake(50 * kScreenWidthProportion, setView.maxY + 35 * kScreenHeightProportion, kScreenWidth - 100 * kScreenWidthProportion, 34 * kScreenHeightProportion)];
    [loginButton setTitle:@"提交" forState:UIControlStateNormal];
    [loginButton setTitleColor:[UIColor whiteColor] forState:UIControlStateNormal];
    loginButton.titleLabel.font = FONT(16 * kFontProportion);
    loginButton.backgroundColor = kDefaultColor;
    [loginButton setCornerRadius:15.f * kScreenHeightProportion];
    [loginButton addTarget:self action:@selector(loginButtonAction) forControlEvents:UIControlEventTouchUpInside];
    [self.view addSubview:loginButton];
    
}
- (void)initTypeData{
//    listMutArray = [NSMutableArray array];
//    [MBProgressHUD showHUDAddedTo:self.view animated:YES];
//    [self defaultRequestwithURL:kGetAccountTypeURL withParameters:nil withMethod:kPOST withBlock:^(NSDictionary *dict, NSError *error) {
//        [MBProgressHUD hideHUDForView:self.view animated:YES];
//        if ([[NSString stringWithFormat:@"%@",[dict objectForKey:@"code"]] isEqualToString:@"0"]) {
//
//            dataDict = [[dict objectForKey:@"data"] objectForKey:@"list"];
//            [listMutArray addObjectsFromArray:[dataDict allValues]];
//            [myScoresTableView reloadData];
//
//        }else if ([[NSString stringWithFormat:@"%@",[dict objectForKey:@"code"]] isEqualToString:@"104"]){
//            [self.navigationController pushViewController:[LoginOrRegisterViewController new] animated:YES];
//        }else{
//            [self showHUDTextOnly:dict[kMessage]];
//        }
//    }];
    
    listMutArray = [NSMutableArray array];
    [listMutArray addObjectsFromArray:@[@"流动性贷款1",@"流动性贷款2"]];
    [myScoresTableView reloadData];
}
- (void)typeButtonAction{
    [self.view endEditing:YES];
    popButton.hidden = NO;
}
#pragma mark - 弹框关闭
- (void)cancelButtonAction{
    popButton.hidden = YES;
}
#pragma mark - 账户类型弹框
- (void)initPopView{
    accountTypeStr = @"";
    
    popButton = [[UIButton alloc] initWithFrame:CGRectMake(0, kHeaderHeight, kScreenWidth, kScreenHeight - kHeaderHeight)];
    popButton.backgroundColor = RGBA(0, 0, 0, 0.5);
    [self.view addSubview:popButton];
    [popButton addTarget:self action:@selector(cancelButtonAction) forControlEvents:UIControlEventTouchUpInside];
    popButton.hidden = YES;
    
    UIView *mainView = [[UIView alloc] initWithFrame:CGRectMake(25 * kScreenWidthProportion, 30 * kScreenHeightProportion, kScreenWidth - 50 * kScreenWidthProportion, 80 * kScreenHeightProportion)];
    [mainView setCornerRadius:5.f * kScreenHeightProportion];
    mainView.backgroundColor = [UIColor whiteColor];
    mainView.centerY = popButton.height / 2.0 - kHeaderHeight;
    [popButton addSubview:mainView];
    
    //下面是列表
    myScoresTableView = [[UITableView alloc] initWithFrame:CGRectMake(0, 0, kScreenWidth, mainView.height)];
    myScoresTableView.separatorStyle = UITableViewCellSeparatorStyleNone;
    myScoresTableView.backgroundColor = [UIColor whiteColor];
    myScoresTableView.delegate = self;
    myScoresTableView.dataSource = self;
    [mainView addSubview:myScoresTableView];
}
#pragma mark - tableView代理方法
- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section{
    return listMutArray.count;
}
- (CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath{
    return 40 * kScreenHeightProportion;
}
- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath{
    static NSString *indefier = @"Cell";
    LoanTypeTableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:indefier];
    if (!cell) {
        cell = [[LoanTypeTableViewCell alloc] initWithStyle:UITableViewCellStyleDefault reuseIdentifier:indefier];
    }
    cell.selectionStyle = UITableViewCellSelectionStyleNone;
    cell.titleLabel.text = [NSString stringWithFormat:@"%@",listMutArray[indexPath.row]];
    
    return cell;
}

- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath{
    typeTextField.text = [NSString stringWithFormat:@"%@",listMutArray[indexPath.row]];
    popButton.hidden = YES;
    accountTypeStr = [NSString stringWithFormat:@"%@",listMutArray[indexPath.row]];
}
- (void)timeButtonAction{
    [DataChoosePopView initWithBlock:^(NSString *date) {
        timeTextField.text = date;
    }];
}

#pragma mark - 确认
- (void)loginButtonAction{
    [self.view endEditing:YES];
    
    if ([companyTextField.text isEqualToString:@""]) {
        [self showHUDTextOnly:@"请输入企业名称"];
        return;
    }
    
    if ([moneyTextField.text isEqualToString:@""]) {
        [self showHUDTextOnly:@"请输入金额"];
        return;
    }
    
    if ([accountTypeStr isEqualToString:@""]) {
        [self showHUDTextOnly:@"请选择贷款种类"];
        return;
    }
    
    NSDictionary *parameters = @{
                                 @"token":[[NSUserDefaults standardUserDefaults] objectForKey:kToken],
                                 @"product_id":self.productIdStr,
                                 @"company":companyTextField.text,
                                 @"expiration_date":timeTextField.text,
                                 @"type":accountTypeStr,
                                 @"money":moneyTextField.text,
                                 @"bank":cardTextField.text
                                 };
    [self defaultRequestwithURL:kProductApplyURL withParameters:parameters withMethod:kPOST withBlock:^(NSDictionary *dict, NSError *error) {
        if ([[NSString stringWithFormat:@"%@",[dict objectForKey:@"code"]] isEqualToString:@"0"]) {
            [self showHUDTextOnly:dict[kMessage]];
            [self.navigationController popViewControllerAnimated:YES];
        }else if ([[NSString stringWithFormat:@"%@",[dict objectForKey:@"code"]] isEqualToString:@"104"]){
            [self.navigationController pushViewController:[LoginOrRegisterViewController new] animated:YES];
        }else{
            [self showHUDTextOnly:dict[kMessage]];
        }
    }];
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

@end
