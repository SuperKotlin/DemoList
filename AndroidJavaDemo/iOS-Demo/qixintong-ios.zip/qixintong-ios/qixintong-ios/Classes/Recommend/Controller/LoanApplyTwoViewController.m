//
//  LoanApplyTwoViewController.m
//  qixintong-ios
//
//  Created by buwen zhou on 2018/4/25.
//  Copyright © 2018年 dmooo. All rights reserved.
//

#import "LoanApplyTwoViewController.h"
#import <AVFoundation/AVCaptureDevice.h>
#import <AVFoundation/AVMediaFormat.h>
#import <Photos/Photos.h>

@interface LoanApplyTwoViewController ()<UINavigationControllerDelegate, UIImagePickerControllerDelegate>{
    UIButton *button1,*button2,*button3,*button4,*button5,*button6,*button7;
    UIImage *picImage1,*picImage2,*picImage3,*picImage4,*picImage5,*picImage6,*picImage7;
    NSString *typeStr;
}

@end

@implementation LoanApplyTwoViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    [self initUI];
}
- (void)initUI
{
    self.view.backgroundColor = RGB(239, 239, 239);
    [self customNavigationBar:@"转贷申请"];
    
    UIView *setView = [[UIView alloc] initWithFrame:CGRectMake(6 * kScreenWidthProportion, kHeaderHeight + 13 * kScreenHeightProportion, kScreenWidth - 12 * kScreenHeightProportion, 48 * 7 * kScreenHeightProportion)];
    [setView setCornerRadius:8.f * kScreenHeightProportion];
    setView.backgroundColor = [UIColor whiteColor];
    [setView setBorder:1.f color:RGB(224, 224, 224)];
    [self.view addSubview:setView];
    
    NSArray *titleArray = @[@"营业执照",@"组织机构代码证",@"税务登记证",@"法人身份证(正面)",@"法人身份证(反面)",@"不动产证",@"贷款卡"];
    for (int i = 0; i < 7; i ++) {
        UILabel *titleLabel = [[UILabel alloc] initWithFrame:CGRectMake(8 * kScreenWidthProportion,48 * kScreenHeightProportion * i, 100 * kScreenWidthProportion, 48 * kScreenHeightProportion)];
        titleLabel.font = FONT(12 * kFontProportion);
        titleLabel.text = titleArray[i];
        [setView addSubview:titleLabel];
        
        UIView *lineView = [[UIView alloc] initWithFrame:CGRectMake(8 * kScreenWidthProportion, titleLabel.maxY - 1 * kScreenHeightProportion, setView.width - 16 * kScreenWidthProportion, 1 * kScreenHeightProportion)];
        lineView.backgroundColor = kGrayBackgroundColor;
        [setView addSubview:lineView];
    }
    
    //接下来是7个按钮
    button1 = [[UIButton alloc] initWithFrame:CGRectMake(0, 0, 36 * kScreenWidthProportion, 26 * kScreenHeightProportion)];
    [button1 setImage:[UIImage imageNamed:@"apply_picture"] forState:UIControlStateNormal];
    button1.centerY = kHeaderHeight + 13 * kScreenHeightProportion + 48 * kScreenHeightProportion / 2.0;
    button1.maxX = setView.width - 12 * kScreenWidthProportion;
    [button1 addTarget:self action:@selector(buttonAction1) forControlEvents:UIControlEventTouchUpInside];
    [self.view addSubview:button1];
    
    button2 = [[UIButton alloc] initWithFrame:CGRectMake(0, 0, 36 * kScreenWidthProportion, 26 * kScreenHeightProportion)];
    [button2 setImage:[UIImage imageNamed:@"apply_picture"] forState:UIControlStateNormal];
    button2.centerY = kHeaderHeight + 13 * kScreenHeightProportion + 48 * kScreenHeightProportion * (1 + 0.5);
    button2.maxX = setView.width - 12 * kScreenWidthProportion;
    [button2 addTarget:self action:@selector(buttonAction2) forControlEvents:UIControlEventTouchUpInside];
    [self.view addSubview:button2];
    
    button3 = [[UIButton alloc] initWithFrame:CGRectMake(0, 0, 36 * kScreenWidthProportion, 26 * kScreenHeightProportion)];
    [button3 setImage:[UIImage imageNamed:@"apply_picture"] forState:UIControlStateNormal];
    button3.centerY = kHeaderHeight + 13 * kScreenHeightProportion + 48 * kScreenHeightProportion * (2 + 0.5);
    button3.maxX = setView.width - 12 * kScreenWidthProportion;
    [button3 addTarget:self action:@selector(buttonAction3) forControlEvents:UIControlEventTouchUpInside];
    [self.view addSubview:button3];
    
    button4 = [[UIButton alloc] initWithFrame:CGRectMake(0, 0, 36 * kScreenWidthProportion, 26 * kScreenHeightProportion)];
    [button4 setImage:[UIImage imageNamed:@"apply_picture"] forState:UIControlStateNormal];
    button4.centerY = kHeaderHeight + 13 * kScreenHeightProportion + 48 * kScreenHeightProportion * (3 + 0.5);
    button4.maxX = setView.width - 12 * kScreenWidthProportion;
    [button4 addTarget:self action:@selector(buttonAction4) forControlEvents:UIControlEventTouchUpInside];
    [self.view addSubview:button4];
    
    button5 = [[UIButton alloc] initWithFrame:CGRectMake(0, 0, 36 * kScreenWidthProportion, 26 * kScreenHeightProportion)];
    [button5 setImage:[UIImage imageNamed:@"apply_picture"] forState:UIControlStateNormal];
    button5.centerY = kHeaderHeight + 13 * kScreenHeightProportion + 48 * kScreenHeightProportion * (4 + 0.5);
    button5.maxX = setView.width - 12 * kScreenWidthProportion;
    [button5 addTarget:self action:@selector(buttonAction5) forControlEvents:UIControlEventTouchUpInside];
    [self.view addSubview:button5];
    
    button6 = [[UIButton alloc] initWithFrame:CGRectMake(0, 0, 36 * kScreenWidthProportion, 26 * kScreenHeightProportion)];
    [button6 setImage:[UIImage imageNamed:@"apply_picture"] forState:UIControlStateNormal];
    button6.centerY = kHeaderHeight + 13 * kScreenHeightProportion + 48 * kScreenHeightProportion * (5 + 0.5);
    button6.maxX = setView.width - 12 * kScreenWidthProportion;
    [button6 addTarget:self action:@selector(buttonAction6) forControlEvents:UIControlEventTouchUpInside];
    [self.view addSubview:button6];
    
    button7 = [[UIButton alloc] initWithFrame:CGRectMake(0, 0, 36 * kScreenWidthProportion, 26 * kScreenHeightProportion)];
    [button7 setImage:[UIImage imageNamed:@"apply_picture"] forState:UIControlStateNormal];
    button7.centerY = kHeaderHeight + 13 * kScreenHeightProportion + 48 * kScreenHeightProportion * (6 + 0.5);
    button7.maxX = setView.width - 12 * kScreenWidthProportion;
    [button7 addTarget:self action:@selector(buttonAction7) forControlEvents:UIControlEventTouchUpInside];
    [self.view addSubview:button7];
    
    UIView *scrView = [[UIView alloc] initWithFrame:CGRectMake(0, setView.maxY + 11 * kScreenHeightProportion, kScreenWidth, 16 * kScreenHeightProportion)];
    [self.view addSubview:scrView];
    
    UIImageView *imgViews = [[UIImageView alloc] initWithFrame:CGRectMake(0, 0, 14 * kScreenWidthProportion, 15 * kScreenHeightProportion)];
    imgViews.image = [UIImage imageNamed:@"apply_tips"];
    [scrView addSubview:imgViews];
    
    UILabel *jinduLabel = [[UILabel alloc] initWithFrame:CGRectMake(imgViews.maxX + 4 * kScreenWidthProportion, 0, kScreenWidth, imgViews.height)];
    jinduLabel.font = FONT(12 * kFontProportion);
    jinduLabel.textColor = kGrayLabelColor;
    jinduLabel.text = @"请上传高清图片，以免影响办理进度";
    [scrView addSubview:jinduLabel];
    
    CGFloat jinduWidth = [jinduLabel getTitleTextWidth:jinduLabel.text font:FONT(12 * kFontProportion)];
    jinduLabel.width = jinduWidth;
    
    scrView.width = jinduWidth + 18 * kScreenWidthProportion;
    scrView.centerX = self.view.centerX;
    
    UIButton *loginButton = [[UIButton alloc] initWithFrame:CGRectMake(50 * kScreenWidthProportion, scrView.maxY + 43 * kScreenHeightProportion, kScreenWidth - 100 * kScreenWidthProportion, 34 * kScreenHeightProportion)];
    [loginButton setTitle:@"提交" forState:UIControlStateNormal];
    [loginButton setTitleColor:[UIColor whiteColor] forState:UIControlStateNormal];
    loginButton.titleLabel.font = FONT(16 * kFontProportion);
    loginButton.backgroundColor = kDefaultColor;
    [loginButton setCornerRadius:15.f * kScreenHeightProportion];
    [loginButton addTarget:self action:@selector(loginButtonAction) forControlEvents:UIControlEventTouchUpInside];
    [self.view addSubview:loginButton];
    
}
- (void)buttonAction1{
    typeStr = @"1";
    [self photoSelect];
}
- (void)buttonAction2{
    typeStr = @"2";
    [self photoSelect];
}
- (void)buttonAction3{
    typeStr = @"3";
    [self photoSelect];
}
- (void)buttonAction4{
    typeStr = @"4";
    [self photoSelect];
}
- (void)buttonAction5{
    typeStr = @"5";
    [self photoSelect];
}
- (void)buttonAction6{
    typeStr = @"6";
    [self photoSelect];
}
- (void)buttonAction7{
    typeStr = @"7";
    [self photoSelect];
}
- (void)photoSelect{
    UIAlertController *alert = [UIAlertController
                                alertControllerWithTitle:nil
                                message:nil
                                preferredStyle:UIAlertControllerStyleActionSheet];
    
    [alert addAction:[UIAlertAction actionWithTitle:@"拍照" style:UIAlertActionStyleDefault handler:^(UIAlertAction *action) {
        AVAuthorizationStatus status = [AVCaptureDevice authorizationStatusForMediaType:AVMediaTypeVideo];
        if (status == AVAuthorizationStatusRestricted || status == AVAuthorizationStatusDenied){
            // 无权限
            UIAlertView * alart = [[UIAlertView alloc]initWithTitle:@"温馨提示" message:@"请您设置允许该应用访问您的相机\n设置>隐私>相机" delegate:self cancelButtonTitle:@"确定" otherButtonTitles:nil, nil];
            [alart show];
            return;
        }
        
        [AVCaptureDevice requestAccessForMediaType:AVMediaTypeVideo completionHandler:^(BOOL granted) {//相机权限
            if (granted) {
                NSLog(@"Authorized");
                // Hide the keyboard
                [self takePhoto];
            }else{
                NSLog(@"Denied or Restricted");
            }
        }];
        
    }]];
    
    [alert addAction:[UIAlertAction actionWithTitle:@"取消" style:UIAlertActionStyleCancel handler:^(UIAlertAction *action) {}]];
    
    [alert addAction:[UIAlertAction actionWithTitle:@"从相册中选择" style:UIAlertActionStyleDefault handler:^(UIAlertAction *action) {
        //----第一次不会进来
        PHAuthorizationStatus status = [PHPhotoLibrary authorizationStatus];
        if (status == PHAuthorizationStatusRestricted || status == PHAuthorizationStatusDenied){
            // 无权限 做一个友好的提示
            UIAlertView * alart = [[UIAlertView alloc]initWithTitle:@"温馨提示" message:@"请您设置允许该应用访问您的相册\n设置>隐私>照片" delegate:self cancelButtonTitle:@"确定" otherButtonTitles:nil, nil];
            [alart show];
            return;
        }
        
        //----每次都会走进来
        [PHPhotoLibrary requestAuthorization:^(PHAuthorizationStatus status) {
            if (status == PHAuthorizationStatusAuthorized) {
                NSLog(@"Authorized");
                [self LocalPhoto];
            }else if (status == PHAuthorizationStatusDenied) {
                NSLog(@"用户拒绝当前应用访问相册,我们需要提醒用户打开访问开关");
            }else{
                NSLog(@"其他原因");
            }
        }];
        
    }]];
    
    [self presentViewController:alert animated:YES completion:nil];
}
//从相册选择
- (void)LocalPhoto{
    UIImagePickerController *picker = [[UIImagePickerController alloc] init];
    //资源类型为图片库
    picker.sourceType = UIImagePickerControllerSourceTypePhotoLibrary;
    picker.delegate = self;
    //设置选择后的图片可被编辑
    //    picker.allowsEditing = YES;
    //    [[XGetCurrentInfo getCurrentVC] presentViewController:picker animated:YES completion:nil];
    [[[[UIApplication sharedApplication]delegate]window].rootViewController presentViewController:picker animated:YES completion:nil];
}

//拍照
- (void)takePhoto{
    //资源类型为照相机
    UIImagePickerControllerSourceType sourceType = UIImagePickerControllerSourceTypeCamera;
    //判断是否有相机
    if ([UIImagePickerController isSourceTypeAvailable: UIImagePickerControllerSourceTypeCamera]){
        UIImagePickerController *picker = [[UIImagePickerController alloc] init];
        picker.delegate = self;
        //设置拍照后的图片可被编辑
        //        picker.allowsEditing = YES;
        //资源类型为照相机
        picker.sourceType = sourceType;
        //        [[XGetCurrentInfo getCurrentVC] presentViewController:picker animated:YES completion:^{}];
        [[[[UIApplication sharedApplication]delegate]window].rootViewController presentViewController:picker animated:YES completion:nil];
    }else {
        //        NSLog(@"该设备无摄像头");
    }
}
#pragma Delegate method UIImagePickerControllerDelegate
//图像选取器的委托方法，选完图片后回调该方法
- (void)imagePickerController:(UIImagePickerController *)picker didFinishPickingImage:(UIImage *)image editingInfo:(NSDictionary *)editingInfo{
    [MBProgressHUD showHUDAddedTo:self.view animated:YES];
    NSDictionary *parameters = @{
                                 @"token":[[NSUserDefaults standardUserDefaults] objectForKey:kToken]
                                 };
    [self startMultiPartUploadTaskWithURL:kEditUserAvatarURL imagesArray:@[image] parameterOfimages:@"user_avatar" parametersDict:parameters compressionRatio:0.5 succeedBlock:^(NSDictionary *dict) {
        [MBProgressHUD hideHUDForView:self.view animated:YES];
        NSLog(@"qwer %@",dict);
        if ([[NSString stringWithFormat:@"%@",[dict objectForKey:@"code"]] isEqualToString:@"0"])  {
            if ([typeStr isEqualToString:@"1"]) {
                [button1 setImage:image forState:UIControlStateNormal];
                picImage1 = image;
            }else if ([typeStr isEqualToString:@"2"]) {
                [button2 setImage:image forState:UIControlStateNormal];
                picImage2 = image;
            }else if ([typeStr isEqualToString:@"3"]) {
                [button3 setImage:image forState:UIControlStateNormal];
                picImage3 = image;
            }else if ([typeStr isEqualToString:@"4"]) {
                [button4 setImage:image forState:UIControlStateNormal];
                picImage4 = image;
            }else if ([typeStr isEqualToString:@"5"]) {
                [button5 setImage:image forState:UIControlStateNormal];
                picImage5 = image;
            }else if ([typeStr isEqualToString:@"6"]) {
                [button6 setImage:image forState:UIControlStateNormal];
                picImage6 = image;
            }else if ([typeStr isEqualToString:@"7"]) {
                [button7 setImage:image forState:UIControlStateNormal];
                picImage7 = image;
            }
            
            [self showHUDTextOnly:dict[kMessage]];
        }else if ([[NSString stringWithFormat:@"%@",[dict objectForKey:@"code"]] isEqualToString:@"104"]){
            [self.navigationController pushViewController:[LoginOrRegisterViewController new] animated:YES];
        }else{
            [self showHUDTextOnly:dict[kMessage]];
        }
        
    } failedBlock:^(NSError *error) {
        
    }];
    
    //关闭相册界面
    [picker dismissViewControllerAnimated:YES completion:nil];
}
#pragma mark - 确认
- (void)loginButtonAction{
    [self.view endEditing:YES];
    
    if (picImage1 == nil) {
        [self showHUDTextOnly:@"请先上传营业执照"];
        return;
    }
    
    if (picImage2 == nil) {
        [self showHUDTextOnly:@"请先上传组织机构代码证"];
        return;
    }
    
    if (picImage3 == nil) {
        [self showHUDTextOnly:@"请先上传税务登记证"];
        return;
    }
    
    if (picImage4 == nil) {
        [self showHUDTextOnly:@"请先上传法人身份证(正面)"];
        return;
    }
    
    if (picImage5 == nil) {
        [self showHUDTextOnly:@"请先上传法人身份证(反面)"];
        return;
    }
    
    if (picImage6 == nil) {
        [self showHUDTextOnly:@"请先上传不动产证"];
        return;
    }
    
    if (picImage7 == nil) {
        [self showHUDTextOnly:@"请先上传贷款卡"];
        return;
    }
    
    NSDictionary *parameters = @{
                                 @"token":[[NSUserDefaults standardUserDefaults] objectForKey:kToken],
                                 @"product_apply_id":self.productApplyIdStr
                                 };
    NSLog(@"parameters==%@",parameters);
    
    
    
    NSLog(@"picImage1==%@",picImage1);
    NSLog(@"picImage2==%@",picImage2);
    NSLog(@"picImage3==%@",picImage3);
    NSLog(@"picImage4==%@",picImage4);
    NSLog(@"picImage5==%@",picImage5);
    NSLog(@"picImage6==%@",picImage6);
    NSLog(@"picImage7==%@",picImage7);
    
    
    
    [MBProgressHUD showHUDAddedTo:self.view animated:YES];

    AFHTTPSessionManager *manager = [AFHTTPSessionManager manager];
    manager.responseSerializer.acceptableContentTypes = [NSSet setWithObject:@"text/html"];
    [manager POST:kProductReApplyURL parameters:parameters constructingBodyWithBlock:^(id<AFMultipartFormData>  _Nonnull formData) {
        NSDate *date = [NSDate date];
        NSDateFormatter *formatter = [[NSDateFormatter alloc]init];
        [formatter setDateFormat:@"YYYYMMddhhmmssSSS"];
        NSString *dateString = [formatter stringFromDate:date];
        NSString *fileName = [NSString stringWithFormat:@"%@.jpeg",dateString];
        NSData *imageData1 = UIImageJPEGRepresentation(picImage1, 0.5f);
        NSData *imageData2 = UIImageJPEGRepresentation(picImage2, 0.5f);
        NSData *imageData3 = UIImageJPEGRepresentation(picImage3, 0.5f);
        NSData *imageData4 = UIImageJPEGRepresentation(picImage4, 0.5f);
        NSData *imageData5 = UIImageJPEGRepresentation(picImage5, 0.5f);
        NSData *imageData6 = UIImageJPEGRepresentation(picImage6, 0.5f);
        NSData *imageData7 = UIImageJPEGRepresentation(picImage7, 0.5f);

        [formData appendPartWithFileData:imageData1 name:@"business_license" fileName:fileName mimeType:@"image/jpg/png/jpeg"];
        [formData appendPartWithFileData:imageData2 name:@"organization_code_certificate" fileName:fileName mimeType:@"image/jpg/png/jpeg"];
        [formData appendPartWithFileData:imageData3 name:@"tax_registration_certificate" fileName:fileName mimeType:@"image/jpg/png/jpeg"];
        [formData appendPartWithFileData:imageData4 name:@"corporate_id_card" fileName:fileName mimeType:@"image/jpg/png/jpeg"];
        [formData appendPartWithFileData:imageData5 name:@"corporate_id_card2" fileName:fileName mimeType:@"image/jpg/png/jpeg"];
        [formData appendPartWithFileData:imageData6 name:@"real_estate_certificate" fileName:fileName mimeType:@"image/jpg/png/jpeg"];
        [formData appendPartWithFileData:imageData7 name:@"bank_card" fileName:fileName mimeType:@"image/jpg/png/jpeg"];

    } progress:^(NSProgress * _Nonnull uploadProgress) {

    } success:^(NSURLSessionDataTask * _Nonnull task, id  _Nullable responseObject) {
        [MBProgressHUD hideHUDForView:self.view animated:YES];
        NSLog(@"responseObject===%@",responseObject);
        if ([responseObject[@"code"] intValue] == 0){
            [self showHUDTextOnly:responseObject[kMessage]];
            [self.navigationController popViewControllerAnimated:YES];
        }else if ([[NSString stringWithFormat:@"%@",[responseObject objectForKey:@"code"]] isEqualToString:@"104"]){
            [self.navigationController pushViewController:[LoginOrRegisterViewController new] animated:YES];
        }else{
            [self showHUDTextOnly:responseObject[kMessage]];
        }
    } failure:^(NSURLSessionDataTask * _Nullable task, NSError * _Nonnull error) {
        [MBProgressHUD hideHUDForView:self.view animated:YES];
        NSLog(@"%@",error);
    }];
}
- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

@end
