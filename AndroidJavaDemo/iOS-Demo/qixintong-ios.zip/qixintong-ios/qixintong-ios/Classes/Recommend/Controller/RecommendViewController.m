//
//  RecommendViewController.m
//  qixintong-ios
//
//  Created by buwen zhou on 2018/4/10.
//  Copyright © 2018年 dmooo. All rights reserved.
//

#import "RecommendViewController.h"
#import "RecommendTableViewCell.h"
#import "LoanApplyOneViewController.h"

@interface RecommendViewController ()<UITableViewDelegate,UITableViewDataSource>{
    //列表
    UITableView *recommendTableView;
    //列表数据
    NSMutableArray *listMutArray;
}

@end

@implementation RecommendViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    [self initUI];
    [self initData];
}
- (void)initData{
    __block int page = 1;
    listMutArray = [NSMutableArray array];
    [MBProgressHUD showHUDAddedTo:self.view animated:YES];
    NSDictionary *parameters = @{
                                 @"is_top":@"",
                                 @"is_new":@"",
                                 @"p":[NSString stringWithFormat:@"%d",page],
                                 @"per":@"10"
                                 };
    [self defaultRequestwithURL:kGetProductListURL withParameters:parameters withMethod:kPOST withBlock:^(NSDictionary *dict, NSError *error) {
        [MBProgressHUD hideHUDForView:self.view animated:YES];
        if ([[NSString stringWithFormat:@"%@",[dict objectForKey:@"code"]] isEqualToString:@"0"]) {
            [listMutArray addObjectsFromArray:[[dict objectForKey:@"data"] objectForKey:@"list"]];
            [recommendTableView reloadData];
            
            page ++;
        }else if ([[NSString stringWithFormat:@"%@",[dict objectForKey:@"code"]] isEqualToString:@"104"]){
            [self.navigationController pushViewController:[LoginOrRegisterViewController new] animated:YES];
        }else{
            [self showHUDTextOnly:dict[kMessage]];
        }
    }];
    
    recommendTableView.mj_header = [MJRefreshNormalHeader headerWithRefreshingBlock:^{
        page = 1;
        listMutArray = [NSMutableArray array];
        [MBProgressHUD showHUDAddedTo:self.view animated:YES];
        NSDictionary *parameters = @{
                                     @"is_top":@"",
                                     @"is_new":@"",
                                     @"p":[NSString stringWithFormat:@"%d",page],
                                     @"per":@"10"
                                     };
        [self defaultRequestwithURL:kGetProductListURL withParameters:parameters withMethod:kPOST withBlock:^(NSDictionary *dict, NSError *error) {
            [MBProgressHUD hideHUDForView:self.view animated:YES];
            if ([[NSString stringWithFormat:@"%@",[dict objectForKey:@"code"]] isEqualToString:@"0"]) {
                [listMutArray addObjectsFromArray:[[dict objectForKey:@"data"] objectForKey:@"list"]];
                [recommendTableView reloadData];
                page ++;
            }else if ([[NSString stringWithFormat:@"%@",[dict objectForKey:@"code"]] isEqualToString:@"104"]){
                [self.navigationController pushViewController:[LoginOrRegisterViewController new] animated:YES];
            }else{
                [self showHUDTextOnly:dict[kMessage]];
            }
            [recommendTableView.mj_header endRefreshing];
        }];
    }];
    
    recommendTableView.mj_footer = [MJRefreshBackNormalFooter footerWithRefreshingBlock:^{
        [MBProgressHUD showHUDAddedTo:self.view animated:YES];
        NSDictionary *parameters = @{
                                     @"is_top":@"",
                                     @"is_new":@"",
                                     @"p":[NSString stringWithFormat:@"%d",page],
                                     @"per":@"10"
                                     };
        [self defaultRequestwithURL:kGetProductListURL withParameters:parameters withMethod:kPOST withBlock:^(NSDictionary *dict, NSError *error) {
            [MBProgressHUD hideHUDForView:self.view animated:YES];
            if ([[NSString stringWithFormat:@"%@",[dict objectForKey:@"code"]] isEqualToString:@"0"]) {
                [listMutArray addObjectsFromArray:[[dict objectForKey:@"data"] objectForKey:@"list"]];
                [recommendTableView reloadData];
                page ++;
            }else if ([[NSString stringWithFormat:@"%@",[dict objectForKey:@"code"]] isEqualToString:@"104"]){
                [self.navigationController pushViewController:[LoginOrRegisterViewController new] animated:YES];
            }else{
                [self showHUDTextOnly:dict[kMessage]];
            }
            [recommendTableView.mj_footer endRefreshing];
        }];
    }];
    
}
- (void)viewWillAppear:(BOOL)animated{
    [super viewWillAppear:YES];
    [self showTabBarView:YES];
}

- (void)initUI
{
    self.view.backgroundColor = RGB(239, 239, 239);
    [self customNavigationBarTitle:@"推荐"];
 
    UIImageView *headImgView = [[UIImageView alloc] initWithFrame:CGRectMake(0, 0, kScreenWidth, 100 * kScreenHeightProportion)];
    headImgView.image = [UIImage imageNamed:@"recommend_banner"];
    
    UIView *footerView = [[UIView alloc] initWithFrame:CGRectMake(0, 0, kScreenWidth, 10 * kScreenHeightProportion)];
    
    recommendTableView = [[UITableView alloc] initWithFrame:CGRectMake(0, kHeaderHeight, kScreenWidth, kScreenHeight - kHeaderHeight - kTabBarHeight)];
    recommendTableView.separatorStyle = UITableViewCellSeparatorStyleNone;
    recommendTableView.backgroundColor = kGrayBackgroundColor;
    recommendTableView.delegate = self;
    recommendTableView.dataSource = self;
    recommendTableView.tableHeaderView = headImgView;
    recommendTableView.tableFooterView = footerView;
    [self.view addSubview:recommendTableView];
}
#pragma mark - tableView代理方法
- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section{
    return listMutArray.count;
}
- (CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath{
    return 122 * kScreenHeightProportion;
}
- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath{
    static NSString *indefier = @"Cell";
    RecommendTableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:indefier];
    if (!cell) {
        cell = [[RecommendTableViewCell alloc] initWithStyle:UITableViewCellStyleDefault reuseIdentifier:indefier];
    }
    cell.selectionStyle = UITableViewCellSelectionStyleNone;
    
    NSDictionary *dict = listMutArray[indexPath.row];
    cell.nameLabel.text = [NSString stringWithFormat:@"%@",dict[@"name"]];
    [cell.picImgView setImageWithURL:[NSURL URLWithString:[NSString stringWithFormat:@"%@%@",kBaseURL,dict[@"img"]]] placeholderImage:[UIImage imageNamed:@""]];
    cell.timeLabel.text = [NSString stringWithFormat:@"期限：%@",[NSString stringWithFormat:@"%@",dict[@"deadline"]]];
    cell.moneyLabel.text = [NSString stringWithFormat:@"%@",dict[@"limit"]];
    cell.rateLabel.text = [NSString stringWithFormat:@"日费率：%@",dict[@"rate"]];
    
    [cell.applyButton addTarget:self action:@selector(applyButtonAction:) forControlEvents:UIControlEventTouchUpInside];
    cell.applyButton.tag = indexPath.row + kTagStart;
    
    return cell;
}
- (void)applyButtonAction:(UIButton *)sender{
    [self showTabBarView:NO];
    NSDictionary *dict = listMutArray[sender.tag - kTagStart];
    LoanApplyOneViewController *detailsVC = [[LoanApplyOneViewController alloc] init];
    detailsVC.productIdStr = [NSString stringWithFormat:@"%@",dict[@"product_id"]];
    [self.navigationController pushViewController:detailsVC animated:YES];
}

- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath{
    
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

@end
