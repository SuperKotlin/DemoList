//
//  ForgotTwoViewController.m
//  qixintong-ios
//
//  Created by buwen zhou on 2018/4/24.
//  Copyright © 2018年 dmooo. All rights reserved.
//

#import "ForgotTwoViewController.h"
#import "ForgotThreeViewController.h"

@interface ForgotTwoViewController (){
    UITextField *codeTextField;
}

@end

@implementation ForgotTwoViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    [self initUI];
}
- (void)initUI
{
    self.view.backgroundColor = kGrayBackgroundColor;
    self.navigationController.navigationBarHidden = YES;
    [self customNavigationBar:@"注册"];
    
    NSString *phStr;
    phStr = [NSString stringWithFormat:@"%@ %@ %@",[self.phoneStr substringToIndex:3],[self.phoneStr substringWithRange:NSMakeRange(3, 4)],[self.phoneStr substringWithRange:NSMakeRange(7, 4)]];
    
    UILabel *titleLabel = [[UILabel alloc] initWithFrame:CGRectMake(0, kHeaderHeight + 34 * kScreenHeightProportion, kScreenWidth, 18 * kScreenHeightProportion)];
    titleLabel.font = FONT(16 * kFontProportion);
    titleLabel.text = [NSString stringWithFormat:@"已发送验证码至%@",phStr];
    titleLabel.textAlignment = NSTextAlignmentCenter;
    [self.view addSubview:titleLabel];
    
    codeTextField = [[UITextField alloc] initWithFrame:CGRectMake(60 * kScreenWidthProportion, titleLabel.maxY + 17 * kScreenHeightProportion, kScreenWidth - 120 * kScreenWidthProportion, 36 * kScreenHeightProportion)];
    codeTextField.placeholder = @"请输入验证码";
    codeTextField.font = FONT(14 * kFontProportion);
    codeTextField.textAlignment = NSTextAlignmentCenter;
    [self.view addSubview:codeTextField];
    
    UIView *lineView = [[UIView alloc] initWithFrame:CGRectMake(codeTextField.minX, codeTextField.maxY, codeTextField.width, 1 * kScreenHeightProportion)];
    lineView.backgroundColor = kDefaultColor;
    [self.view addSubview:lineView];
    
    UIButton *codeButton = [[UIButton alloc] initWithFrame:CGRectMake(0, lineView.maxY + 16 * kScreenHeightProportion, 100 * kScreenWidthProportion, 12 * kScreenHeightProportion)];
    codeButton.centerX = self.view.centerX;
    [codeButton setTitle:@"" forState:UIControlStateNormal];
    [codeButton setTitleColor:kGrayLabelColor forState:UIControlStateNormal];
    codeButton.titleLabel.font = FONT(14 * kFontProportion);
    [codeButton addTarget:self action:@selector(codeButtonAction:) forControlEvents:UIControlEventTouchUpInside];
    [self.view addSubview:codeButton];
    
    [self timeFire:codeButton];
    
    UIButton *loginButton = [[UIButton alloc] initWithFrame:CGRectMake(55 * kScreenWidthProportion, codeButton.maxY + 50 * kScreenHeightProportion, kScreenWidth - 110 * kScreenWidthProportion, 30 * kScreenHeightProportion)];
    [loginButton setTitle:@"下一步" forState:UIControlStateNormal];
    [loginButton setTitleColor:[UIColor whiteColor] forState:UIControlStateNormal];
    loginButton.titleLabel.font = FONT(16 * kFontProportion);
    loginButton.backgroundColor = kDefaultColor;
    [loginButton setCornerRadius:15.f * kScreenHeightProportion];
    [loginButton addTarget:self action:@selector(loginButtonAction) forControlEvents:UIControlEventTouchUpInside];
    [self.view addSubview:loginButton];
    
}
#pragma mark - 验证码
- (void)codeButtonAction:(UIButton *)sender{
    [self.view endEditing:YES];
    
    NSDictionary *parameters = @{
                                 @"phone":self.phoneStr
                                 };
    [self defaultRequestwithURL:kSendUserFindpwdURL withParameters:parameters withMethod:kPOST withBlock:^(NSDictionary *dict, NSError *error) {
        if ([[NSString stringWithFormat:@"%@",[dict objectForKey:@"code"]] isEqualToString:@"0"]) {
            [self showHUDTextOnly:[NSString stringWithFormat:@"%@",dict[kMessage]]];
            [self timeFire:sender];
        }else{
            [self showHUDTextOnly:[NSString stringWithFormat:@"%@",dict[kMessage]]];
        }
    }];
}
- (void)loginButtonAction{
    [self.view endEditing:YES];
    
    if ([codeTextField.text isEqualToString:@""]) {
        [self showHUDTextOnly:@"请输入验证码"];
        return;
    }
    
    NSDictionary *parameters = @{
                                 @"phone":self.phoneStr,
                                 @"code":codeTextField.text
                                 };
    [self defaultRequestwithURL:kCheckCodeURL withParameters:parameters withMethod:kPOST withBlock:^(NSDictionary *dict, NSError *error) {
        if ([[NSString stringWithFormat:@"%@",[dict objectForKey:@"code"]] isEqualToString:@"0"]) {
            ForgotThreeViewController *reVC = [[ForgotThreeViewController alloc] init];
            reVC.codeStr = codeTextField.text;
            reVC.phoneStr = self.phoneStr;
            [self.navigationController pushViewController:reVC animated:YES];
        }else{
            [self showHUDTextOnly:[NSString stringWithFormat:@"%@",dict[kMessage]]];
        }
    }];
}


- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

@end
