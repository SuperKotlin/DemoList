//
//  LoginOrRegisterViewController.m
//  qixintong-ios
//
//  Created by buwen zhou on 2018/4/24.
//  Copyright © 2018年 dmooo. All rights reserved.
//

#import "LoginOrRegisterViewController.h"
#import "RegisterViewController.h"

@interface LoginOrRegisterViewController (){
    //手机号
    UITextField *phoneTextField;
}

@end

@implementation LoginOrRegisterViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    [self initUI];
}
- (void)viewWillAppear:(BOOL)animated{
    [super viewWillAppear:YES];
    [self showTabBarView:NO];
}
- (void)initUI
{
    self.view.backgroundColor = kGrayBackgroundColor;
    self.navigationController.navigationBarHidden = YES;
    //    [self customNavigationBar:@"注册/登录"];
    [self customNavigationBarTitle:@"注册/登录"];
    
    UILabel *titleLabel = [[UILabel alloc] initWithFrame:CGRectMake(0, kHeaderHeight + 34 * kScreenHeightProportion, kScreenWidth, 18 * kScreenHeightProportion)];
    titleLabel.font = FONT(16 * kFontProportion);
    titleLabel.text = @"请输入手机号";
    titleLabel.textAlignment = NSTextAlignmentCenter;
    [self.view addSubview:titleLabel];
    
    phoneTextField = [[UITextField alloc] initWithFrame:CGRectMake(52 * kScreenWidthProportion, titleLabel.maxY + 17 * kScreenHeightProportion, kScreenWidth - 104 * kScreenWidthProportion, 36 * kScreenHeightProportion)];
    phoneTextField.placeholder = @"填写真实有效的手机号码";
    phoneTextField.keyboardType = UIKeyboardTypePhonePad;
    phoneTextField.font = FONT(14 * kFontProportion);
    phoneTextField.textAlignment = NSTextAlignmentCenter;
    [self.view addSubview:phoneTextField];
    
    UIView *lineView = [[UIView alloc] initWithFrame:CGRectMake(phoneTextField.minX, phoneTextField.maxY, phoneTextField.width, 1 * kScreenHeightProportion)];
    lineView.backgroundColor = RGB(230, 230, 230);
    [self.view addSubview:lineView];
    
    UIButton *loginButton = [[UIButton alloc] initWithFrame:CGRectMake(55 * kScreenWidthProportion, lineView.maxY + 76 * kScreenHeightProportion, kScreenWidth - 110 * kScreenWidthProportion, 30 * kScreenHeightProportion)];
    [loginButton setTitle:@"下一步" forState:UIControlStateNormal];
    [loginButton setTitleColor:[UIColor whiteColor] forState:UIControlStateNormal];
    loginButton.titleLabel.font = FONT(16 * kFontProportion);
    loginButton.backgroundColor = kDefaultColor;
    [loginButton setCornerRadius:15.f * kScreenHeightProportion];
    [loginButton addTarget:self action:@selector(loginButtonAction) forControlEvents:UIControlEventTouchUpInside];
    [self.view addSubview:loginButton];
    
    //第三方
    UILabel *loginLabel = [[UILabel alloc] initWithFrame:CGRectMake(0, kScreenHeight - 120 * kScreenHeightProportion, 110 * kScreenWidthProportion, 13 * kScreenHeightProportion)];
    loginLabel.text = @"第三方账号登录";
    loginLabel.textColor = RGB(58, 58, 58);
    loginLabel.font = FONT(12 * kFontProportion);
    loginLabel.textAlignment = NSTextAlignmentCenter;
    loginLabel.centerX = self.view.centerX;
    [self.view addSubview:loginLabel];
    
    UIView *lineView2 = [[UIView alloc] initWithFrame:CGRectMake(0, 0, 82 * kScreenWidthProportion, 1 * kScreenHeightProportion)];
    lineView2.backgroundColor = RGB(151, 151, 151);
    lineView2.centerY = loginLabel.centerY;
    lineView2.maxX = loginLabel.minX;
    [self.view addSubview:lineView2];
    
    UIView *lineView1 = [[UIView alloc] initWithFrame:CGRectMake(loginLabel.maxX, 0, 82 * kScreenWidthProportion, 1 * kScreenHeightProportion)];
    lineView1.backgroundColor = RGB(151, 151, 151);
    lineView1.centerY = loginLabel.centerY;
    [self.view addSubview:lineView1];
    
    UIButton *wechatButton = [[UIButton alloc] initWithFrame:CGRectMake(0, loginLabel.maxY, 60 * kScreenWidthProportion, 60 * kScreenWidthProportion)];
    [wechatButton setCornerRadius:19.f];
    [wechatButton setImage:[UIImage imageNamed:@"login_wechat"] forState:UIControlStateNormal];
    [wechatButton addTarget:self action:@selector(wechatButtonAction) forControlEvents:UIControlEventTouchUpInside];
    wechatButton.centerX = self.view.centerX;
    [self.view addSubview:wechatButton];
    
//    phoneTextField.text = @"15855537219";
}

- (void)loginButtonAction{
    [self.view endEditing:YES];
    if ([phoneTextField.text isEqualToString:@""]) {
        [self showHUDTextOnly:@"请输入手机号"];
        return;
    }
    
    if (![phoneTextField.text valiMobile]) {
        [self showHUDTextOnly:@"请输入正确的手机号码"];
        return;
    }
    
    NSDictionary *parameters = @{
                                 @"phone":phoneTextField.text
                                 };
    [MBProgressHUD showHUDAddedTo:self.view animated:YES];
    [self defaultRequestwithURL:kIsRegisterURL withParameters:parameters withMethod:kPOST withBlock:^(NSDictionary *dict, NSError *error) {
        [MBProgressHUD hideHUDForView:self.view animated:YES];
        if ([[NSString stringWithFormat:@"%@",[dict objectForKey:@"code"]] isEqualToString:@"0"]) {
            //是否注册，Y已注册、N未注册
            NSString *registr = [NSString stringWithFormat:@"%@",[dict[@"data"] objectForKey:@"is_register"]];
            if ([registr isEqualToString:@"Y"]) {
                LoginViewController *loginVC = [[LoginViewController alloc] init];
                loginVC.typeStr = self.typeStr;
                loginVC.phoneStr = phoneTextField.text;
                [self.navigationController pushViewController:loginVC animated:YES];
            }else{
                NSDictionary *parameters = @{
                                             @"phone":phoneTextField.text
                                             };
                [self defaultRequestwithURL:kSendUserRegisterURL withParameters:parameters withMethod:kPOST withBlock:^(NSDictionary *dict, NSError *error) {
                    if ([[NSString stringWithFormat:@"%@",[dict objectForKey:@"code"]] isEqualToString:@"0"]) {
                        RegisterViewController *registerVC = [[RegisterViewController alloc] init];
                        registerVC.phoneStr = phoneTextField.text;
                        [self.navigationController pushViewController:registerVC animated:YES];
                    }else{
                        [self showHUDTextOnly:[NSString stringWithFormat:@"%@",dict[kMessage]]];
                    }
                }];
            }
        }else{
            [self showHUDTextOnly:[NSString stringWithFormat:@"%@",dict[kMessage]]];
        }
    }];
}
- (void)wechatButtonAction{
    [self showHUDTextOnly:@"暂时无法使用"];
//    if(![WXApi isWXAppInstalled]) {
//        [self showHUDTextOnly:@"您的手机还未安装微信"];
//        return;
//    }
//
//    SendAuthReq *req = [[SendAuthReq alloc] init];
//    req.scope = @"snsapi_userinfo";
//    req.state = @"weikeweixin";
//    [WXApi sendReq:req];
}
#pragma mark - 第三方登录
- (void)loginOauth:(NSString *)openid type:(NSString *)type nickname:(NSString *)nickname avatar:(NSString *)avatar sex:(NSString *)sex{
    NSDictionary *parameters = @{
                                 @"openid":openid, //第三方社交平台ID
                                 @"type":type, //微信：wx  QQ：qq 新浪微博：sina
                                 @"nickname":nickname, //昵称
                                 @"avatar":avatar, //头像
                                 @"sex":sex // 性别，1男 2女 3保密
                                 };
    NSLog(@"parameters==%@",parameters);
    
    [self defaultRequestwithURL:kLoginOauthURL withParameters:parameters withMethod:kPOST withBlock:^(NSDictionary *dict, NSError *error) {
        if ([[NSString stringWithFormat:@"%@",[dict objectForKey:@"code"]] isEqualToString:@"0"]) {
            //是否注册，Y已注册、N未注册
            NSString *registr = [NSString stringWithFormat:@"%@",[dict[@"data"] objectForKey:@"is_register"]];
            if ([registr isEqualToString:@"Y"]) {
                LoginViewController *loginVC = [[LoginViewController alloc] init];
                loginVC.typeStr = self.typeStr;
                loginVC.phoneStr = phoneTextField.text;
                [self.navigationController pushViewController:loginVC animated:YES];
            }else{
                NSDictionary *parameters = @{
                                             @"phone":phoneTextField.text
                                             };
                [self defaultRequestwithURL:kSendUserRegisterURL withParameters:parameters withMethod:kPOST withBlock:^(NSDictionary *dict, NSError *error) {
                    if ([[NSString stringWithFormat:@"%@",[dict objectForKey:@"code"]] isEqualToString:@"0"]) {
                        RegisterViewController *registerVC = [[RegisterViewController alloc] init];
                        registerVC.phoneStr = phoneTextField.text;
                        [self.navigationController pushViewController:registerVC animated:YES];
                    }else{
                        [self showHUDTextOnly:[NSString stringWithFormat:@"%@",dict[kMessage]]];
                    }
                }];
            }
        }else{
            [self showHUDTextOnly:dict[kMessage]];
        }
    }];
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

@end
