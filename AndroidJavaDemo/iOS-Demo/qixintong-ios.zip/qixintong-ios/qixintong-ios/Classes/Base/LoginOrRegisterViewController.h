//
//  LoginOrRegisterViewController.h
//  qixintong-ios
//
//  Created by buwen zhou on 2018/4/24.
//  Copyright © 2018年 dmooo. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface LoginOrRegisterViewController : UIViewController
@property (nonatomic,strong) NSString *typeStr;

@end
