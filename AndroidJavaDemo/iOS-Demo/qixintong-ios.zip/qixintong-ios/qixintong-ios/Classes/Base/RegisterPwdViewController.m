//
//  RegisterPwdViewController.m
//  qixintong-ios
//
//  Created by buwen zhou on 2018/4/17.
//  Copyright © 2018年 dmooo. All rights reserved.
//

#import "RegisterPwdViewController.h"
#import "UserProtocolViewController.h"
#import "LoginViewController.h"

@interface RegisterPwdViewController (){
    UITextField *pwdTextField;
    //是否同意协议
    NSString *isAgreeStr;
}

@end

@implementation RegisterPwdViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    [self initUI];
}
- (void)initUI
{
    self.view.backgroundColor = kGrayBackgroundColor;
    self.navigationController.navigationBarHidden = YES;
    [self customNavigationBar:@"注册"];
    
    UILabel *titleLabel = [[UILabel alloc] initWithFrame:CGRectMake(0, kHeaderHeight + 34 * kScreenHeightProportion, kScreenWidth, 15 * kScreenHeightProportion)];
    titleLabel.font = FONT(16 * kFontProportion);
    titleLabel.text = @"请设置密码";
    titleLabel.textAlignment = NSTextAlignmentCenter;
    [self.view addSubview:titleLabel];
    
    pwdTextField = [[UITextField alloc] initWithFrame:CGRectMake(60 * kScreenWidthProportion, titleLabel.maxY + 26 * kScreenHeightProportion, kScreenWidth - 120 * kScreenWidthProportion, 26 * kScreenHeightProportion)];
    pwdTextField.placeholder = @"请输入密码";
    pwdTextField.font = FONT(14 * kFontProportion);
    pwdTextField.textAlignment = NSTextAlignmentCenter;
    pwdTextField.secureTextEntry = YES;
    [self.view addSubview:pwdTextField];
    
    UIView *lineView = [[UIView alloc] initWithFrame:CGRectMake(pwdTextField.minX, pwdTextField.maxY, pwdTextField.width, 1 * kScreenHeightProportion)];
    lineView.backgroundColor = RGB(223, 224, 225);
    [self.view addSubview:lineView];
    
    UIButton *loginButton = [[UIButton alloc] initWithFrame:CGRectMake(55 * kScreenWidthProportion, lineView.maxY + 180 * kScreenHeightProportion, kScreenWidth - 110 * kScreenWidthProportion, 30 * kScreenHeightProportion)];
    [loginButton setTitle:@"下一步" forState:UIControlStateNormal];
    [loginButton setTitleColor:[UIColor whiteColor] forState:UIControlStateNormal];
    loginButton.titleLabel.font = FONT(16 * kFontProportion);
    loginButton.backgroundColor = kDefaultColor;
    [loginButton setCornerRadius:15.f * kScreenHeightProportion];
    [loginButton addTarget:self action:@selector(loginButtonAction) forControlEvents:UIControlEventTouchUpInside];
    [self.view addSubview:loginButton];
    
    UIView *agreeView = [[UIView alloc] initWithFrame:CGRectMake(0, loginButton.maxY + 15 * kScreenHeightProportion, 100, 16 * kScreenHeightProportion)];
    [self.view addSubview:agreeView];
    
    UIButton *checkButton = [[UIButton alloc] initWithFrame:CGRectMake(0 * kScreenWidthProportion, 0, 16 * kScreenWidthProportion, 16 * kScreenWidthProportion)];
    checkButton.selected = YES;
    [checkButton setImage:[UIImage imageNamed:@"login_check"] forState:UIControlStateNormal];
    [checkButton addTarget:self action:@selector(checkButtonAction:) forControlEvents:UIControlEventTouchUpInside];
    [agreeView addSubview:checkButton];
    isAgreeStr = @"1"; //默认是同意的
    
    UILabel *agreeGrayLabel = [[UILabel alloc] initWithFrame:CGRectMake(checkButton.maxX + 3 * kScreenWidthProportion, 0, 70 * kScreenWidthProportion, 13 * kScreenHeightProportion)];
    agreeGrayLabel.font = FONT(13 * kFontProportion);
    agreeGrayLabel.textColor = kGrayLabelColor;
    agreeGrayLabel.text = @"我已阅读并同意";
    agreeGrayLabel.centerY = checkButton.centerY;
    [agreeView addSubview:agreeGrayLabel];
    
    CGFloat agreeGrayWidth = [agreeGrayLabel getTitleTextWidth:agreeGrayLabel.text font:FONT(13 * kFontProportion)];
    agreeGrayLabel.width = agreeGrayWidth;
    
    UILabel *delegateLabel = [[UILabel alloc] initWithFrame:CGRectMake(agreeGrayLabel.maxX + 3 * kScreenWidthProportion, agreeGrayLabel.minY, 100 * kScreenWidthProportion, 13 * kScreenHeightProportion)];
    delegateLabel.textColor = [UIColor redColor];
    delegateLabel.font = FONT(13 * kFontProportion);
    delegateLabel.text = @"用户协议";
    delegateLabel.centerY = agreeGrayLabel.centerY;
    [agreeView addSubview:delegateLabel];
    
    CGFloat delegateWidth = [delegateLabel getTitleTextWidth:delegateLabel.text font:FONT(13 * kFontProportion)];
    delegateLabel.width = delegateWidth;
    
    UITapGestureRecognizer *labelTapGestureRecognizer = [[UITapGestureRecognizer alloc]initWithTarget:self action:@selector(labelTouchUpInside:)];
    [delegateLabel addGestureRecognizer:labelTapGestureRecognizer];
    
    agreeView.width = agreeGrayWidth + delegateWidth + 22 * kScreenWidthProportion;
    agreeView.centerX = self.view.centerX;
    
}
- (void)labelTouchUpInside:(UITapGestureRecognizer *)recognizer{
    [self.navigationController pushViewController:[UserProtocolViewController new] animated:YES];
}
- (void)checkButtonAction:(UIButton *)sender{
    if (sender.selected) {
        [sender setImage:[UIImage imageNamed:@"login_oncheck"] forState:UIControlStateNormal];
        isAgreeStr = @"0";
    }else{
        [sender setImage:[UIImage imageNamed:@"login_check"] forState:UIControlStateNormal];
        isAgreeStr = @"1";
    }
    sender.selected = !sender.selected;
}
- (void)loginButtonAction{
    [self.view endEditing:YES];
    
    if ([pwdTextField.text isEqualToString:@""]) {
        [self showHUDTextOnly:@"请输入密码"];
        return;
    }
    
    if ([isAgreeStr isEqualToString:@"0"]) {
        [self showHUDTextOnly:@"请先同意用户协议"];
        return;
    }
    
    NSDictionary *parameters = @{
                                 @"phone":self.phoneStr,
                                 @"pwd1":pwdTextField.text,
                                 @"pwd2":pwdTextField.text,
                                 @"code":self.codeStr,
                                 @"referrer_phone":@""
                                 };
    NSLog(@"parameters==%@",parameters);
    [self defaultRequestwithURL:kRegisterURL withParameters:parameters withMethod:kPOST withBlock:^(NSDictionary *dict, NSError *error) {
        if ([[NSString stringWithFormat:@"%@",[dict objectForKey:@"code"]] isEqualToString:@"0"]) {
            [self.navigationController pushViewController:[LoginViewController new] animated:YES];
        }else{
            [self showHUDTextOnly:[NSString stringWithFormat:@"%@",dict[kMessage]]];
        }
    }];
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

@end
