//
//  RegisterPwdViewController.h
//  qixintong-ios
//
//  Created by buwen zhou on 2018/4/17.
//  Copyright © 2018年 dmooo. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface RegisterPwdViewController : UIViewController
@property (nonatomic,strong) NSString *phoneStr;
@property (nonatomic,strong) NSString *codeStr;

@end
