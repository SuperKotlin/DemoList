//
//  LoginViewController.m
//  qixintong-ios
//
//  Created by buwen zhou on 2018/4/10.
//  Copyright © 2018年 dmooo. All rights reserved.
//

#import "LoginViewController.h"
#import "ForgotOneViewController.h"
#import "ForgotOneViewController.h"

@interface LoginViewController (){
    //手机号
    UITextField *pwdTextField;
}

@end

@implementation LoginViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    [self initUI];
}
- (void)initUI
{
    self.view.backgroundColor = kGrayBackgroundColor;
    self.navigationController.navigationBarHidden = YES;
    [self customNavigationBar:@"登录"];
    
    UILabel *titleLabel = [[UILabel alloc] initWithFrame:CGRectMake(0, kHeaderHeight + 34 * kScreenHeightProportion, kScreenWidth, 15 * kScreenHeightProportion)];
    titleLabel.font = FONT(16 * kFontProportion);
    titleLabel.text = @"请输入密码";
    titleLabel.textAlignment = NSTextAlignmentCenter;
    [self.view addSubview:titleLabel];
    
    pwdTextField = [[UITextField alloc] initWithFrame:CGRectMake(60 * kScreenWidthProportion, titleLabel.maxY + 26 * kScreenHeightProportion, kScreenWidth - 120 * kScreenWidthProportion, 26 * kScreenHeightProportion)];
    pwdTextField.placeholder = @"";
    pwdTextField.font = FONT(14 * kFontProportion);
    pwdTextField.textAlignment = NSTextAlignmentCenter;
    pwdTextField.secureTextEntry = YES;
    [self.view addSubview:pwdTextField];
    
    UIView *lineView = [[UIView alloc] initWithFrame:CGRectMake(pwdTextField.minX, pwdTextField.maxY, pwdTextField.width, 1 * kScreenHeightProportion)];
    lineView.backgroundColor = RGB(223, 224, 225);
    [self.view addSubview:lineView];
    
    UILabel *regotLabel = [[UILabel alloc] initWithFrame:CGRectMake(0, lineView.maxY + 8 * kScreenHeightProportion, 120 * kScreenWidth, 20 * kScreenHeightProportion)];
    regotLabel.text = @"忘记密码？";
    regotLabel.textAlignment = NSTextAlignmentRight;
    regotLabel.maxX = lineView.maxX;
    regotLabel.font = FONT(13 * kFontProportion);
    regotLabel.textColor = [UIColor redColor];
    regotLabel.userInteractionEnabled = YES;
    [self.view addSubview:regotLabel];
    
    UITapGestureRecognizer *labelTapGestureRecognizer = [[UITapGestureRecognizer alloc]initWithTarget:self action:@selector(labelTouchUpInside:)];
    [regotLabel addGestureRecognizer:labelTapGestureRecognizer];
    
    UIButton *loginButton = [[UIButton alloc] initWithFrame:CGRectMake(55 * kScreenWidthProportion, regotLabel.maxY + 45 * kScreenHeightProportion, kScreenWidth - 110 * kScreenWidthProportion, 30 * kScreenHeightProportion)];
    [loginButton setTitle:@"确认" forState:UIControlStateNormal];
    [loginButton setTitleColor:[UIColor whiteColor] forState:UIControlStateNormal];
    loginButton.titleLabel.font = FONT(16 * kFontProportion);
    loginButton.backgroundColor = kDefaultColor;
    [loginButton setCornerRadius:15.f * kScreenHeightProportion];
    [loginButton addTarget:self action:@selector(loginButtonAction) forControlEvents:UIControlEventTouchUpInside];
    [self.view addSubview:loginButton];

}
- (void)labelTouchUpInside:(UITapGestureRecognizer *)recognizer{
    [self.navigationController pushViewController:[ForgotOneViewController new] animated:YES];
}
- (void)loginButtonAction{
    [self.view endEditing:YES];
    if ([pwdTextField.text isEqualToString:@""]) {
        [self showHUDTextOnly:@"请输入密码"];
        return;
    }
    
    NSDictionary *parameters = @{
                                 @"account":self.phoneStr,
                                 @"pwd":pwdTextField.text
                                 };
    [MBProgressHUD showHUDAddedTo:self.view animated:YES];
    [self defaultRequestwithURL:kLoginURL withParameters:parameters withMethod:kPOST withBlock:^(NSDictionary *dict, NSError *error) {
        [MBProgressHUD hideHUDForView:self.view animated:YES];
        if ([[NSString stringWithFormat:@"%@",[dict objectForKey:@"code"]] isEqualToString:@"0"]) {
            [[NSUserDefaults standardUserDefaults] setObject:dict[kToken] forKey:kToken];
            [[NSUserDefaults standardUserDefaults] synchronize];
            
            if ([self.typeStr isEqualToString:@"1"]) {
                TabBarController *tabbar = (TabBarController *)self.tabBarController;
                [tabbar setSelect:0];
                [self.navigationController popToRootViewControllerAnimated:YES];
            }else{
                int index = (int)[[self.navigationController viewControllers] indexOfObject:self];
                NSLog(@"index===%d",index);
                [self.navigationController popToViewController:[self.navigationController.viewControllers objectAtIndex:(index - 2)] animated:YES];
            }
        }else{
            [self showHUDTextOnly:[NSString stringWithFormat:@"%@",dict[kMessage]]];
        }
    }];
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

@end
