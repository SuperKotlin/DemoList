//
//  ForgotThreeViewController.m
//  qixintong-ios
//
//  Created by buwen zhou on 2018/4/24.
//  Copyright © 2018年 dmooo. All rights reserved.
//

#import "ForgotThreeViewController.h"
#import "ForgotFourViewController.h"

@interface ForgotThreeViewController (){
    //手机号
    UITextField *pwdTextField;
}

@end

@implementation ForgotThreeViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    [self initUI];
}
- (void)initUI
{
    self.view.backgroundColor = kGrayBackgroundColor;
    self.navigationController.navigationBarHidden = YES;
    [self customNavigationBar:@"忘记密码"];
    
    UILabel *titleLabel = [[UILabel alloc] initWithFrame:CGRectMake(0, kHeaderHeight + 34 * kScreenHeightProportion, kScreenWidth, 15 * kScreenHeightProportion)];
    titleLabel.font = FONT(16 * kFontProportion);
    titleLabel.text = @"请设置新密码";
    titleLabel.textAlignment = NSTextAlignmentCenter;
    [self.view addSubview:titleLabel];
    
    pwdTextField = [[UITextField alloc] initWithFrame:CGRectMake(60 * kScreenWidthProportion, titleLabel.maxY + 26 * kScreenHeightProportion, kScreenWidth - 120 * kScreenWidthProportion, 26 * kScreenHeightProportion)];
    pwdTextField.placeholder = @"";
    pwdTextField.font = FONT(14 * kFontProportion);
    pwdTextField.textAlignment = NSTextAlignmentCenter;
    pwdTextField.secureTextEntry = YES;
    [self.view addSubview:pwdTextField];
    
    UIView *lineView = [[UIView alloc] initWithFrame:CGRectMake(pwdTextField.minX, pwdTextField.maxY, pwdTextField.width, 1 * kScreenHeightProportion)];
    lineView.backgroundColor = RGB(223, 224, 225);
    [self.view addSubview:lineView];
    
    UIButton *loginButton = [[UIButton alloc] initWithFrame:CGRectMake(55 * kScreenWidthProportion, lineView.maxY + 74 * kScreenHeightProportion, kScreenWidth - 110 * kScreenWidthProportion, 30 * kScreenHeightProportion)];
    [loginButton setTitle:@"下一步" forState:UIControlStateNormal];
    [loginButton setTitleColor:[UIColor whiteColor] forState:UIControlStateNormal];
    loginButton.titleLabel.font = FONT(16 * kFontProportion);
    loginButton.backgroundColor = kDefaultColor;
    [loginButton setCornerRadius:15.f * kScreenHeightProportion];
    [loginButton addTarget:self action:@selector(loginButtonAction) forControlEvents:UIControlEventTouchUpInside];
    [self.view addSubview:loginButton];
    
}
- (void)loginButtonAction{
    [self.view endEditing:YES];
    if ([pwdTextField.text isEqualToString:@""]) {
        [self showHUDTextOnly:@"请输入新密码"];
        return;
    }
    
    ForgotFourViewController *forgotVC = [[ForgotFourViewController alloc] init];
    forgotVC.pwdStr = pwdTextField.text;
    forgotVC.codeStr = self.codeStr;
    forgotVC.phoneStr = self.phoneStr;
    [self.navigationController pushViewController:forgotVC animated:YES];
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

@end
