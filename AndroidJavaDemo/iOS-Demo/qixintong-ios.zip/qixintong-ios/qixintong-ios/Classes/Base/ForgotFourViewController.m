//
//  ForgotFourViewController.m
//  qixintong-ios
//
//  Created by buwen zhou on 2018/4/24.
//  Copyright © 2018年 dmooo. All rights reserved.
//

#import "ForgotFourViewController.h"

@interface ForgotFourViewController (){
    //手机号
    UITextField *pwdTextField;
}

@end

@implementation ForgotFourViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    [self initUI];
}
- (void)initUI
{
    self.view.backgroundColor = kGrayBackgroundColor;
    self.navigationController.navigationBarHidden = YES;
    [self customNavigationBar:@"忘记密码"];
    
    UILabel *titleLabel = [[UILabel alloc] initWithFrame:CGRectMake(0, kHeaderHeight + 34 * kScreenHeightProportion, kScreenWidth, 15 * kScreenHeightProportion)];
    titleLabel.font = FONT(16 * kFontProportion);
    titleLabel.text = @"确认新密码";
    titleLabel.textAlignment = NSTextAlignmentCenter;
    [self.view addSubview:titleLabel];
    
    pwdTextField = [[UITextField alloc] initWithFrame:CGRectMake(60 * kScreenWidthProportion, titleLabel.maxY + 26 * kScreenHeightProportion, kScreenWidth - 120 * kScreenWidthProportion, 26 * kScreenHeightProportion)];
    pwdTextField.placeholder = @"";
    pwdTextField.font = FONT(14 * kFontProportion);
    pwdTextField.textAlignment = NSTextAlignmentCenter;
    pwdTextField.secureTextEntry = YES;
    [self.view addSubview:pwdTextField];
    
    UIView *lineView = [[UIView alloc] initWithFrame:CGRectMake(pwdTextField.minX, pwdTextField.maxY, pwdTextField.width, 1 * kScreenHeightProportion)];
    lineView.backgroundColor = RGB(223, 224, 225);
    [self.view addSubview:lineView];
    
    UIButton *loginButton = [[UIButton alloc] initWithFrame:CGRectMake(55 * kScreenWidthProportion, lineView.maxY + 74 * kScreenHeightProportion, kScreenWidth - 110 * kScreenWidthProportion, 30 * kScreenHeightProportion)];
    [loginButton setTitle:@"确认" forState:UIControlStateNormal];
    [loginButton setTitleColor:[UIColor whiteColor] forState:UIControlStateNormal];
    loginButton.titleLabel.font = FONT(16 * kFontProportion);
    loginButton.backgroundColor = kDefaultColor;
    [loginButton setCornerRadius:15.f * kScreenHeightProportion];
    [loginButton addTarget:self action:@selector(loginButtonAction) forControlEvents:UIControlEventTouchUpInside];
    [self.view addSubview:loginButton];
    
}
- (void)loginButtonAction{
    [self.view endEditing:YES];
    if ([pwdTextField.text isEqualToString:@""]) {
        [self showHUDTextOnly:@"请输入确认密码"];
        return;
    }
    
    if (![pwdTextField.text isEqualToString:self.pwdStr]) {
        [self showHUDTextOnly:@"两次密码不一致"];
        return;
    }
    
    NSDictionary *parameters = @{
                                 @"phone":self.phoneStr,
                                 @"code":self.codeStr,
                                 @"pwd":pwdTextField.text
                                 };
    [MBProgressHUD showHUDAddedTo:self.view animated:YES];
    [self defaultRequestwithURL:kFindPwdByPhoneURL withParameters:parameters withMethod:kPOST withBlock:^(NSDictionary *dict, NSError *error) {
        [MBProgressHUD hideHUDForView:self.view animated:YES];
        if ([[NSString stringWithFormat:@"%@",[dict objectForKey:@"code"]] isEqualToString:@"0"]) {
            LoginOrRegisterViewController *loginVC = [[LoginOrRegisterViewController alloc] init];
            loginVC.typeStr = @"1";
            [self.navigationController pushViewController:loginVC animated:YES];
        }else{
            [self showHUDTextOnly:[NSString stringWithFormat:@"%@",dict[kMessage]]];
        }
    }];
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

@end
