//
//  AppDelegate.m
//  qixintong-ios
//
//  Created by buwen zhou on 2018/4/10.
//  Copyright © 2018年 dmooo. All rights reserved.
//

#import "AppDelegate.h"
#import "IQKeyboardManager.h"
#import "TabBarController.h"
#import "LZTabBarController.h"
#import "NewbieRaidersViewController.h"

@interface AppDelegate ()

@end

@implementation AppDelegate


- (BOOL)application:(UIApplication *)application didFinishLaunchingWithOptions:(NSDictionary *)launchOptions {
    // Override point for customization after application launch.
    //启用IQKeyboard
    IQKeyboardManager *manager = [IQKeyboardManager sharedManager];
    manager.enable = YES;
    manager.shouldResignOnTouchOutside = YES;
    manager.shouldToolbarUsesTextFieldTintColor = YES;
    manager.enableAutoToolbar = NO;
    
    //设置状态栏颜色
    [[UIApplication sharedApplication] setStatusBarStyle:UIStatusBarStyleLightContent animated:NO];
    
    [UITableView appearance].separatorStyle = UITableViewCellSeparatorStyleNone;
    [UITableViewCell appearance].selectionStyle = UITableViewCellSelectionStyleNone;
    [UITextField appearance].clearButtonMode = UITextFieldViewModeWhileEditing;
    
    self.window = [[UIWindow alloc]initWithFrame:[UIScreen mainScreen].bounds];
    self.window.backgroundColor = [UIColor whiteColor];
    self.window.rootViewController = [[UINavigationController alloc]initWithRootViewController:[TabBarController new]];
    //    self.window.rootViewController = [[UINavigationController alloc]initWithRootViewController:[NSClassFromString(@"GoodsDetailViewController") new]];
    [self.window makeKeyAndVisible];
    
    
//    LZTabBarController *tab = [LZTabBarController createTabBarController:^LZTabBarConfig *(LZTabBarConfig *config) {
//
//        NSArray *classNameArray = @[@"LoanViewController",@"RecommendViewController",@"PersonalCenterViewController"];
//
//        NSMutableArray *tabArray = [NSMutableArray arrayWithCapacity:classNameArray.count];
//
//        //初始化导航控制器
//        for (int i = 0; i < classNameArray.count; i++) {
//            UINavigationController *navCtrl = [[UINavigationController alloc] initWithRootViewController:[NSClassFromString(classNameArray[i]) new]];
//            [tabArray addObject:navCtrl];
//        }
//        //将导航控制器给标签控制器
//        config.viewControllers = tabArray;
//
//        config.normalImages = @[@"bottom_lend", @"bottom_recommend",@"bottom_mine"];
//
//        config.titles = @[@"借款",@"推荐",@"我"];
//
//        config.selectedImages = @[@"bottom_redmoney", @"bottom_redrecommend", @"bottom_redmine"];
//
//        config.isNavigation = NO;
//
//        return config;
//    }];
//
//    // 为了能够使用hidesBottomBarWhenPushed, 不直接把tabBar设置为window的跟视图, 而是设置为导航的rootvc, 然后把导航设置为window的跟视图
//    // 这样, 在子视图上就不用再添加导航了, 即设置: config.isNavigation = NO;
//    UINavigationController *nav = [[UINavigationController alloc]initWithRootViewController:tab];
//
//    nav.hidesBottomBarWhenPushed = YES;
//    self.window.rootViewController = nav;
    
    return YES;
}

- (void)applicationWillResignActive:(UIApplication *)application {
    // Sent when the application is about to move from active to inactive state. This can occur for certain types of temporary interruptions (such as an incoming phone call or SMS message) or when the user quits the application and it begins the transition to the background state.
    // Use this method to pause ongoing tasks, disable timers, and invalidate graphics rendering callbacks. Games should use this method to pause the game.
}


- (void)applicationDidEnterBackground:(UIApplication *)application {
    // Use this method to release shared resources, save user data, invalidate timers, and store enough application state information to restore your application to its current state in case it is terminated later.
    // If your application supports background execution, this method is called instead of applicationWillTerminate: when the user quits.
}


- (void)applicationWillEnterForeground:(UIApplication *)application {
    // Called as part of the transition from the background to the active state; here you can undo many of the changes made on entering the background.
}


- (void)applicationDidBecomeActive:(UIApplication *)application {
    // Restart any tasks that were paused (or not yet started) while the application was inactive. If the application was previously in the background, optionally refresh the user interface.
}


- (void)applicationWillTerminate:(UIApplication *)application {
    // Called when the application is about to terminate. Save data if appropriate. See also applicationDidEnterBackground:.
}


@end
