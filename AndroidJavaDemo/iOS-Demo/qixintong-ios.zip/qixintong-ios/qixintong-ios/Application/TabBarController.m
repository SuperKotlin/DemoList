//
//  TabBarController.m
//  pd505-huozhu-ios
//
//  Created by Kerwin on 2017/2/6.
//  Copyright © 2017年 yayuanzi. All rights reserved.
//

#import "TabBarController.h"

@interface TabBarController ()
{
    UIScrollView *myGuidePageScrollView;
}
@end

@implementation TabBarController

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view.

    self.automaticallyAdjustsScrollViewInsets = NO;

    [self initViewController];
    [self initTabBarView];
    
}
-(void)viewWillAppear:(BOOL)animated
{
    [super viewWillAppear:animated];

    [self.navigationController setNavigationBarHidden:YES];
    [self.tabBarController setHidesBottomBarWhenPushed:YES];
    [self.tabBar setHidden:YES];

//    [self initGuidePage];
    
}

- (void)initViewController
{
    NSArray *classNameArray = @[@"LoanViewController",@"RecommendViewController",@"PersonalCenterViewController"];

    NSMutableArray *tabArray = [NSMutableArray arrayWithCapacity:classNameArray.count];

    //初始化导航控制器
    for (int i = 0; i < classNameArray.count; i++) {
        UINavigationController *navCtrl = [[UINavigationController alloc] initWithRootViewController:[NSClassFromString(classNameArray[i]) new]];
        [tabArray addObject:navCtrl];
    }
    //将导航控制器给标签控制器
    self.viewControllers = tabArray;
}

- (void)initTabBarView
{
    self.tabBarView = [[UIView alloc] initWithFrame:CGRectMake(0, kScreenHeight - kTabBarHeight, kScreenWidth, kTabBarHeight)];
    self.tabBarView.backgroundColor = [UIColor whiteColor];
    [self.view addSubview:self.tabBarView];

    NSArray *imgageArray = @[@"tab_rank_light", @"tab_rgs_light",@"tab_user_light"];
    NSArray *selectedImageArray = @[@"tab_rank_full", @"tab_rgs_full", @"tab_user_full"];
    for (int i = 0; i<imgageArray.count; i++)
    {
        UIButton *button = [UIButton buttonWithType:UIButtonTypeCustom];
        [button setImage:[UIImage imageNamed:imgageArray[i]] forState:UIControlStateNormal];
        [button setImage:[UIImage imageNamed:selectedImageArray[i]] forState:UIControlStateSelected];
        button.frame  = CGRectMake(kScreenWidth / 3 * i, 0, kScreenWidth / 3, kTabBarHeight);
        button.tag = kTagStart + i;
        [button addTarget:self action:@selector(btnAction:) forControlEvents:UIControlEventTouchUpInside];
        [self.tabBarView addSubview:button];

        if (i == 0)
        {
            button.selected = YES;
        }
    }
    
    UIView *lineView = [UIView viewWithFrame:CGRectMake(0, 0, kScreenWidth, 1) backgroundColor:kGrayLineColor];
    [self.tabBarView addSubview:lineView];
}

//自定义tabbar点击事件
-(void)btnAction:(UIButton *)sender
{
    self.selectedIndex = sender.tag - kTagStart;
    sender.selected = YES;

    for (UIButton *btn in sender.superview.subviews)
    {
        if ([btn isKindOfClass:[UIButton class]])
        {
            if (btn != sender) {
                btn.selected = NO;
            }
        }
    }
}

#pragma mark -- 初始化引导页
-(void)initGuidePage
{
    if(![[NSUserDefaults standardUserDefaults] boolForKey:@"isFirstLaunch"])
    {
        NSLog(@"第一次启动APP");
        [[NSUserDefaults standardUserDefaults] setBool:YES forKey:@"isFirstLaunch"];

        //用于首页显示隐藏指引页
        [[NSUserDefaults standardUserDefaults] setBool:NO forKey:@"homeFirst"];
        [[NSUserDefaults standardUserDefaults] synchronize];

        myGuidePageScrollView = [[UIScrollView alloc]initWithFrame:CGRectMake(0, 0, kScreenWidth, kScreenHeight)];
        myGuidePageScrollView.pagingEnabled = YES;
        myGuidePageScrollView.showsHorizontalScrollIndicator = NO;
        myGuidePageScrollView.contentSize = CGSizeMake(kScreenWidth * 5, kScreenHeight);
        myGuidePageScrollView.bounces = NO;
        [self.view addSubview:myGuidePageScrollView];

        for (int i = 0; i < 5; i++) {
            UIImageView *myGuidePageImageView = [UIImageView imageViewWithFrame:CGRectMake(kScreenWidth * i, 0, kScreenWidth, kScreenHeight) imageName:[NSString stringWithFormat:@"guide_page%d",i + 1]];
            [myGuidePageScrollView addSubview:myGuidePageImageView];
        }

        UIButton *startButton = [UIButton buttonWithFrame:CGRectMake(kScreenWidth * 4, kScreenHeight - 46 * kScreenHeightProportion, kScreenWidth, 46 * kScreenHeightProportion) type:UIButtonTypeCustom title:@"开始使用" titleColor:[UIColor whiteColor] imageName:nil action:@selector(startButtonAction) target:self];
        startButton.titleLabel.font = FONT(16 * kFontProportion);
        startButton.backgroundColor = kDefaultColor;
        [myGuidePageScrollView addSubview:startButton];
    }
}

- (void)startButtonAction
{
    myGuidePageScrollView.hidden = YES;
}

-(void)showTabBar:(BOOL)show
{
    CGRect frame = self.tabBarView.frame;
    if (show){
        frame.origin.y = kScreenHeight - kTabBarHeight;
    }else
    {
        frame.origin.y = kScreenHeight;
    }
    [UIView animateWithDuration:0.2 animations:^{
        self.tabBarView.frame = frame;
    }];
}

-(void)setSelect:(NSInteger)selectIndex
{
    self.selectedIndex = selectIndex;

    for (id obj in self.tabBarView.subviews)  {
        if ([obj isKindOfClass:[UIButton class]]) {
            UIButton* theButton = (UIButton*)obj;
            theButton.selected = NO;
            if (theButton.tag == selectIndex + kTagStart) {
                theButton.selected = YES;
            }
        }
    }
}


- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

/*
 #pragma mark - Navigation

 // In a storyboard-based application, you will often want to do a little preparation before navigation
 - (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
 // Get the new view controller using [segue destinationViewController].
 // Pass the selected object to the new view controller.
 }
 */

@end

