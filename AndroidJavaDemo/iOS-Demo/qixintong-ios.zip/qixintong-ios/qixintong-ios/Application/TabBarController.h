//
//  TabBarController.h
//  pd505-huozhu-ios
//
//  Created by Kerwin on 2017/2/6.
//  Copyright © 2017年 yayuanzi. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface TabBarController : UITabBarController

@property (nonatomic,strong) UIView *tabBarView;
@property (assign, nonatomic) NSUInteger mySelectIndex;

- (void)showTabBar:(BOOL)show;
- (void)setSelect:(NSInteger)selectIndex;

@end
